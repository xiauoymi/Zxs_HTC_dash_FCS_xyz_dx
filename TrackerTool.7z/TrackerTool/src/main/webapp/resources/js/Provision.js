var provision = {
	downlaodPulseAllData : function(urll) {
		var formatedPulseAllListArray = [];
		$.ajax({
			async : false,
			contentType : "application/json",
			url : urll,
			 type:'POST', 
            
			dataType : "json",
			cache: false,
			success : function(pulseAllJsonData) {
				$('#ExceptionIssue').hide();
				$.each(pulseAllJsonData, function(index, aPulse) {
					formatedPulseAllListArray.push(aPulse);
				});
			},
			 error:function(errorResponse,xhr){ 
					if(errorResponse.status==403)
						{
						commonAlert("Alert !", "Session expired");
						}else{
							if("undefined"==(errorResponse.responseText).trim()){
								commonAlert("Alert !", "Bad Request. Please relogin again.");
							}else{
							$('#ExceptionIssue').html(errorResponse.responseText);
							$('#ExceptionIssue').show();
							}
						}
	       	 }
			
		});
		
		return formatedPulseAllListArray;
	},

	drawPulseAllChart : function(formatedPulseAllJsonData, title) {
		$.jqplot.config.enablePlugins = true;
		var s1 = [];
		var tic;
		var pontlable;
		var maxvalue = 0;
		var numberOfTicks = 4;
		var fndMax = 0;
		var interval;
		var values = new Array();
		for (i = 0; i < formatedPulseAllJsonData.length; i++) {
			if (i == formatedPulseAllJsonData.length - 1)
				s1 = formatedPulseAllJsonData[i];
			else {
			 if(i==0){
				values.push(formatedPulseAllJsonData[i]);
				maxvalue = Math.max.apply(Math, formatedPulseAllJsonData[i]);
				if (fndMax <= maxvalue) {
					fndMax = maxvalue;
				}
			}else
				pontlable=formatedPulseAllJsonData[i];
		}
	}	
		
		var originalvalue = fndMax;
		fndMax -= fndMax % (100);
		var diff = originalvalue - fndMax;
		if(originalvalue<=100){
			if(diff<=5){
				fndMax+=5
			}else
				fndMax += diff+10;
		
	   }else{
			  fndMax +=diff+150 ;
	     }
		
		
		tic = fndMax / (numberOfTicks);
		numberOfTicks++;
		
	plot1 = jQuery.jqplot('provisionchart', values, {
			seriesColors : [ "#90B2FF", "#FFC290", "#8FFD8F" ],
			title : title,
			animate : !$.jqplot.use_excanvas,
			seriesDefaults : {
				renderer : $.jqplot.BarRenderer,
				rendererOptions : {
					// varyBarColor: true,
					smooth : true,
					animation : {
						show : true
					},
				},
				pointLabels : {
					show : true,
					labels:pontlable,
					edgeTolerance: -50
					/*location : 'inside',*/
					//xpadding : 	-50,					
					//ypadding : 15,
				}
			},
			axesDefaults : {
				tickRenderer : $.jqplot.CanvasAxisTickRenderer,
				tickOptions : {
					angle : -60,
					fontSize : '10px',
				},
				rendererOptions : {
					baselineWidth : 1.5,
					drawBaseline : true
				}
			},
			grid : {
				drawBorder : false,
				drawGridlines : false,
				background : 'rgba(0,0,0,0)',
				shadow : false
			},
			axes : {
				xaxis : {
					renderer : $.jqplot.CategoryAxisRenderer,
					drawMajorGridlines : false,
					ticks : s1
				},
				yaxis : {
					min : 0,
					//tickInterval : tic,
					//numberTicks : 4,
					//Max : fndMax,
					drawBaseline : true,
					rendererOptions : {
						drawBaseline : true,
						border : 5
					},
					tickOptions : {
						formatString : '%d',
						showGridline : false,
					}
				}
			},
			highlighter : {
				show : true,
				showTooltip : true
			},
			cursor : {
				style : 'default',
				show : true
			}
		});

		var spanStart = '<span class="chart-tooltip-wrapper">';
		$('#provisionchart').bind(
				'jqplotDataHighlight',
				function(ev, seriesIndex, pointIndex, data) {
					var chart_left = $('#provisionchart').offset().left;
					var chart_top = $('#provisionchart').offset().top;
					var x = ev.pageX;
					var y = ev.pageY;
					var left = x;
					var top = y;
					var chartTooltipHTML = spanStart;
					// for stacked chart
					top = chart_top;
					var sum = 0;
					for (var i = 0; i < seriesIndex + 1; i++)
						sum += plot1.series[i].data[pointIndex][1];
					top += plot1.axes.yaxis.u2p(sum); // (data[1]);
					chartTooltipHTML += '<span class="chart-tooltip-content">'
							+ s1[pointIndex]
							+ '</span><span class="chart-tooltip-value">'
							+ data[1] + '</span> </span>' // data[1] has count
															// of movements
					;
					var ct = $('#chartTooltip');
					ct.css({
						left : left,
						top : top
					}).html(chartTooltipHTML).show();
				});
		$('#provisionchart').bind('jqplotDataUnhighlight',
				function(ev, seriesIndex, pointIndex, data) {
					$('#chartTooltip').empty().hide();
				});
	}
};