package com.htc.utility;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import com.htc.authentication.dto.LoginDetailDTO;


public class QueryBuilder {

	
	
}
