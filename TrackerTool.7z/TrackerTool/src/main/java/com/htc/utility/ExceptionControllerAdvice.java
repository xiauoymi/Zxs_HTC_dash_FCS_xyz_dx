package com.htc.utility;

import javax.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class ExceptionControllerAdvice {

	@ExceptionHandler(Throwable.class)
	public ModelAndView exception(Exception e, HttpServletRequest request) {

		if (isAjaxRequest(request)) {

			ModelAndView mav = new ModelAndView("common/AjaxException");
			mav.addObject("name", e.getClass().getSimpleName());
			if (request.getSession().getAttribute(
					DashboardConstants.SESSION_STATUS_NAME) == null) {
				mav.addObject("message", "Session Exipred , Please login Again");
			} else {
				mav.addObject("message", e.getMessage());
			}
			return mav;
		} else {

			ModelAndView mav = new ModelAndView("common/exception");

			mav.addObject("name", e.getClass().getSimpleName());
			if ("HttpRequestMethodNotSupportedException".equalsIgnoreCase(e
					.getClass().getSimpleName())) {
				mav.addObject("message", "Unauthorized access");
			} else {
				mav.addObject("message", e.getMessage());
			}
			return mav;
		}
	}

	private boolean isAjaxRequest(HttpServletRequest request) {
		return "XMLHttpRequest".equals(request.getHeader("X-Requested-With"));
	}
}
