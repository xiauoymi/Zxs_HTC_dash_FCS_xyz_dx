package com.htc.security;

import com.htc.utility.DashboardConstants;
public class CaptchaUtil {
	public static String generateCaptchaTextMethod(int captchaLength){
		String strSaltChar = DashboardConstants.CAPTCHASALTCHAR;
		StringBuffer stringBuffCaptcha = new StringBuffer();
		java.util.Random random = new java.util.Random();
		while (stringBuffCaptcha.length() < captchaLength){
			int index = (int) (random.nextFloat() * strSaltChar.length());
			stringBuffCaptcha.append(strSaltChar.substring(index, index+1));
		}
		return stringBuffCaptcha.toString();
	}
}