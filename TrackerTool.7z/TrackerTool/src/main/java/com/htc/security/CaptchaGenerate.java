package com.htc.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import javax.servlet.http.*;
import java.io.*;

import com.htc.security.CaptchaUtil;
import com.htc.utility.DashboardConstants;

public class CaptchaGenerate extends HttpServlet {

	private static final long serialVersionUID = 1L;
	public static final String FILE_TYPE = "jpeg";

	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession(true);
		int count = (Integer) session.getAttribute("CAPTCHECOUNT");

		if (count >= 5) {

			response.setHeader("Cache-Control", "no-cache");
			response.setDateHeader("Expires", 0);
			response.setHeader("Pragma", "no-cache");
			response.setDateHeader("Max-Age", 0);

			String strCaptcha = "";
			strCaptcha = CaptchaUtil.generateCaptchaTextMethod(6);

			try {
				int width = 100;
				int height = 40;

				Color bg = new Color(31, 132, 189);
				Color fg = new Color(255, 255, 255);

				Font font = new Font("Arial", Font.BOLD, 20);
				BufferedImage cpimg = new BufferedImage(width, height,
						BufferedImage.OPAQUE);
				Graphics graphics = cpimg.createGraphics();

				graphics.setFont(font);
				graphics.setColor(bg);
				graphics.fillRect(0, 0, width, height);
				graphics.setColor(fg);
				graphics.drawString(strCaptcha, 10, 25);

				session.setAttribute(DashboardConstants.CAPTCHA, strCaptcha);
				OutputStream outputStream = response.getOutputStream();
				ImageIO.write(cpimg, FILE_TYPE, outputStream);
				outputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
}
