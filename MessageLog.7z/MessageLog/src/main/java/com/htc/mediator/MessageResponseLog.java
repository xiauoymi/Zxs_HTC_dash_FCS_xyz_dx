package com.htc.mediator;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.synapse.MessageContext;
import org.apache.synapse.mediators.AbstractMediator;

import com.caretech.mediator.datamapping.processor.JSONProcessor;
import com.htc.mediator.constants.Constants;
import com.htc.mediator.service.MediatorService;
import com.htc.mediator.service.impl.MediatorServiceImpl;
import com.htc.mediator.utils.Utilities;
/**
 * @author thilak
 *
 */
public class MessageResponseLog extends AbstractMediator  {
	Logger log = Logger.getLogger(MessageResponseLog.class.getName());
	MediatorService mediatorService = new MediatorServiceImpl();
	/**
	 * @param MessageContext
	 * @return 
	 */
	public boolean mediate(MessageContext context) {
		Map<String, Object>  responseParam = new HashMap<String, Object>();
		JSONProcessor jSONProcessor = new JSONProcessor();
		String jsonResponse =  null;
		try {
			String serviceName= (String) context.getProperty("Service Name");
			log.info("Log mediator call starts for the message response Service->"+serviceName+" : "+Utilities.getCurrentDateTime());
			if(Constants.SERVICENAME_TICKET_HANDLER.equals(serviceName)){
				responseParam = mediatorService.responseCreateTicketOR(context);	
				jsonResponse = jSONProcessor.getInputMapAsJson(responseParam);
				jsonResponse = jsonResponse.replace("\\n", "\\r\\n");
				context.setProperty("jsonResponse",jsonResponse);
			}else if(Constants.SERVICENAME_CREATE_TICKET_IR.equals(serviceName)){
				mediatorService.responseCreateTicketIR(context);
			}else if(Constants.SERVICENAME_UPLOAD_ATTACHMENT.equals(serviceName)){
				responseParam = mediatorService.responseUploadAttachment(context);
				jsonResponse = jSONProcessor.getInputMapAsJson(responseParam);
				jsonResponse = jsonResponse.replace("\\n", "\\r\\n");
				context.setProperty("jsonResponse",jsonResponse);
			}else if(Constants.SERVICENAME_UPDATE_TICKET_IR.equals(serviceName)){
				mediatorService.responseUpdateTicketIR(context);
			}else if(Constants.SERVICENAME_UPDATE_TICKET_OR.equals(serviceName)){
				responseParam = mediatorService.responseCreateTicketOR(context);	
				jsonResponse = jSONProcessor.getInputMapAsJson(responseParam);
				jsonResponse = jsonResponse.replace("\\n", "\\r\\n");
				context.setProperty("jsonResponse",jsonResponse);
			}
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage());
			e.printStackTrace();
		}
		log.info("Log mediator call ends : "+Utilities.getCurrentDateTime());
		return true;
	}
}

