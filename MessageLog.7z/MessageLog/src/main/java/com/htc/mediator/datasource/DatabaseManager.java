package com.htc.mediator.datasource;

import java.sql.Connection;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DatabaseManager {
	
	private  Connection connect;
	
	public  Connection getConnection() {
		 
		 Hashtable<String, String> environment = new Hashtable<String, String>();
		 environment.put("java.naming.factory.initial", "org.wso2.carbon.tomcat.jndi.CarbonJavaURLContextFactory");
		 Context initContext;
		try {
			initContext = new InitialContext(environment);
			 DataSource ds = (DataSource)initContext.lookup("jdbc/WSO2MYSQL");
			 connect = ds.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		} 
		 return connect;
	}

}
