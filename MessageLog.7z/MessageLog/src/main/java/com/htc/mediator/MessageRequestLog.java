package com.htc.mediator;




import java.net.Inet4Address;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.synapse.MessageContext;
import org.apache.synapse.mediators.AbstractMediator;

import com.caretech.mediator.datamapping.processor.JSONProcessor;
import com.htc.mediator.constants.Constants;
import com.htc.mediator.service.MediatorService;
import com.htc.mediator.service.impl.MediatorServiceImpl;
import com.htc.mediator.utils.Utilities;

/**
 * @author thilak
 *
 */
public class MessageRequestLog extends AbstractMediator {

	Logger log = Logger.getLogger(MessageRequestLog.class.getName());
	MediatorService mediatorService = new MediatorServiceImpl();
	
	/**
	 * @param MessageContext
	 * @return 
	 */
	public boolean mediate(MessageContext context) { 
		JSONProcessor jSONProcessor = new JSONProcessor();
		try {
			String serviceName= (String) context.getProperty("Service Name");
			log.info("Log mediator call starts for the Service->"+serviceName+" : "+Utilities.getCurrentDateTime());
			Inet4Address IP=(Inet4Address) Inet4Address.getLocalHost();
			log.info("Econnector IP ADRESS  ="+IP.getHostAddress());
			Map<String, Object>  requestParam = new HashMap<String, Object>();
			if(Constants.SERVICENAME_TICKET_HANDLER.equals(serviceName)) {
				requestParam = mediatorService.requestCreateTicketOR(context);	
				context.setProperty("URL", requestParam.get("URL"));
				context.setProperty("Username", requestParam.get("userName"));
				context.setProperty("Password", requestParam.get("password"));
				context.setProperty("RequestParam", requestParam.get("requestParm"));
				context.setProperty("ticketNumber",requestParam.get("ticketNumber"));
				
			}else if(Constants.SERVICENAME_CREATE_TICKET_IR.equals(serviceName)){
				 String response = mediatorService.requestCreateTicketIR(context);
				 context.setProperty("jsonValue",response);
				 
			}else if(Constants.SERVICENAME_UPLOAD_ATTACHMENT.equals(serviceName)){
				requestParam =  mediatorService.requestUploadAttachment(context);
				String status = (String) requestParam.get("status");
				String jsonValue = jSONProcessor.getInputMapAsJson(requestParam);
				if(status != null ){
					context.setProperty("jsonValue", jsonValue);
					context.setProperty("status","failure");
				}
				else{
					context.setProperty("status","success");
					context.setProperty("URL", requestParam.get("URL"));
					context.setProperty("Username", requestParam.get("userName"));
					context.setProperty("Password", requestParam.get("password"));
					context.setProperty("RequestParam", requestParam.get("requestParm"));
					}
				
			}else if(Constants.SERVICENAME_UPDATE_TICKET_IR.equals(serviceName)){
				 String response = mediatorService.requestUpdateTicketIR(context);
				 context.setProperty("jsonValue",response);
				 
			}else if(Constants.SERVICENAME_UPDATE_TICKET_OR.equals(serviceName)){				
				requestParam = mediatorService.requestUpdateTicketOR(context);
				String status = (String) requestParam.get("status");
				String jsonValue = jSONProcessor.getInputMapAsJson(requestParam);
				if(status.equals("Failure")){
					context.setProperty("jsonValue", jsonValue);
					context.setProperty("status","failure");
				}
				else{
				context.setProperty("status","success");
				context.setProperty("URL", requestParam.get("URL"));
				context.setProperty("Username", requestParam.get("userName"));
				context.setProperty("Password", requestParam.get("password"));
				context.setProperty("RequestParam", requestParam.get("requestParm"));
				}
			}
			else if(Constants.SERVICENAME_CREATE_DATA_SYNC.equals(serviceName)){
				 String response = mediatorService.requestCreateDataSync(context);
				 context.setProperty("jsonValue",response);
			}
			else if(Constants.SERVICENAME_UPDATE_DATA_SYNC.equals(serviceName)){
				 String response = mediatorService.requestUpdateDataSync(context);
				 context.setProperty("jsonValue",response);
				 
			}
			
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage());
			e.printStackTrace();		
		}
		log.info("Log mediator call ends : "+Utilities.getCurrentDateTime());
		return true;
	}


}
