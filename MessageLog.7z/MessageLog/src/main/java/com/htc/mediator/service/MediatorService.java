package com.htc.mediator.service;

import java.util.Map;

import org.apache.synapse.MessageContext;

public interface MediatorService {
 
	public Map<String, Object> requestCreateTicketOR(MessageContext context);
	
	public String requestCreateTicketIR(MessageContext context);
	
	public String requestCreateDataSync(MessageContext context);
	
	public Map<String, Object> requestUploadAttachment(MessageContext context);
	
	public String requestUpdateTicketIR(MessageContext context);
	
	public String requestUpdateDataSync(MessageContext context);
	
	public Map<String, Object> requestUpdateTicketOR(MessageContext context);
	
	public Map<String, Object> responseCreateTicketOR(MessageContext context);
	
	public void responseCreateTicketIR(MessageContext context);
	
	public Map<String, Object> responseUploadAttachment(MessageContext context);
	
	public void responseUpdateTicketIR(MessageContext context);
	
	public Map<String, Object> responseUpdateTicketOR(MessageContext context);
	
	public void failureStatus(MessageContext context);
	
	public String destinationService(String serviceName);
	
	public String clientName(String clientId);
}
