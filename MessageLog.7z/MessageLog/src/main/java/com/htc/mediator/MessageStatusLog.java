package com.htc.mediator;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.synapse.MessageContext;
import org.apache.synapse.mediators.AbstractMediator;

import com.htc.mediator.service.MediatorService;
import com.htc.mediator.service.impl.MediatorServiceImpl;
import com.htc.mediator.utils.Utilities;

/**
 * @author thilak
 *
 */
public class MessageStatusLog extends AbstractMediator{
	Logger log = Logger.getLogger(MessageStatusLog.class.getName());
	MediatorService mediatorService = new MediatorServiceImpl();
	public boolean mediate(MessageContext context) {
		try {
			log.info("-----------FailOver Sequence----------"+Utilities.getCurrentDateTime());
			mediatorService.failureStatus(context);	
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage());
			e.printStackTrace();
		}
		return true;
	}
}
