package com.htc.mediator.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.htc.mediator.constants.Constants;
import com.htc.mediator.dao.MediatorDAO;
import com.htc.mediator.datasource.DatabaseManager;
/**
 * @author thilak
 *
 */
public class MediatorDAOImpl implements MediatorDAO {
	
	Logger log = Logger.getLogger(MediatorDAOImpl.class.getName());
	DatabaseManager datasource = new DatabaseManager();
	

	/**
	 * @param requestParameters
	 * @throws Exception
	 */

	public void requestCreateTicketORLog(HashMap<String , Object> databaseParams) {
		System.out.println("database parammm****************"+databaseParams);
		Connection connection = null;
		PreparedStatement summary=null;
		PreparedStatement detail= null;
		ResultSet resultSet = null;
		try {
			connection = datasource.getConnection();
			int transactionId = 0 ;
			summary = connection.prepareStatement(Constants.CREATE_TICKET_OR_REQUEST_SUMMARY_QUERY, Statement.RETURN_GENERATED_KEYS);
			summary.setString(1, (String) databaseParams.get(Constants.PARAM_SOURCE));
			summary.setString(2, (String) databaseParams.get(Constants.PARAM_REQUEST_MESSAGE_ID));
			summary.setTimestamp(3, (Timestamp) databaseParams.get(Constants.PARAM_INTIME_TO_ESB));
			summary.setTimestamp(4, (Timestamp) databaseParams.get(Constants.PARAM_INTIME_TO_SNOW));
			summary.setString(5, (String) databaseParams.get(Constants.PARAM_DESTINATION));
			summary.setString(6, (String) databaseParams.get(Constants.PARAM_REMEDY_TICKET_NUMBER));
			summary.setString(7, (String) databaseParams.get(Constants.PARAM_CLIENT_NAME));
			summary.setString(8, Constants.STATUS_FAILED);
			summary.setString(9, (String) databaseParams.get(Constants.PARAM_SERVER_IP));
			summary.executeUpdate();
			
			resultSet = summary.getGeneratedKeys();
			while(resultSet.next()){
				transactionId = resultSet.getInt(1);
			}
			detail = connection.prepareStatement(Constants.CREATE_TICKET_OR_REQUEST_DETAIL_QUERY);
			detail.setInt(1, transactionId);
			detail.setString(2, (String) databaseParams.get(Constants.PARAM_REQUEST_PARAMETER));			
			detail.executeUpdate();
			
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage());
			e.printStackTrace();
		}finally{
			try { if (resultSet != null && !resultSet.isClosed()) resultSet.close(); } catch (Exception e) {};
		    try { if (summary != null && !summary.isClosed()) summary.close(); } catch (Exception e) {};
		    try { if (detail != null && !detail.isClosed()) detail.close(); } catch (Exception e) {};
		    try { if (connection != null && !connection.isClosed()) connection.close(); } catch (Exception e) {};
		}
	}
	
	/**
	 * @param requestParameters
	 * @throws Exception
	 */

	public void requestCreateTicketIRLog(HashMap<String , Object> databaseParams) {
		Connection connection = null;
		PreparedStatement summary=null;
		PreparedStatement detail= null;
		ResultSet resultSet = null;
		try {
		
			connection = datasource.getConnection();
			int transactionId = 0 ;
			summary = connection.prepareStatement(Constants.CREATE_TICKET_IR_REQUEST_SUMMARY_QUERY, Statement.RETURN_GENERATED_KEYS);
			summary.setString(1, (String) databaseParams.get(Constants.PARAM_SOURCE));
			summary.setString(2, (String) databaseParams.get(Constants.PARAM_REQUEST_MESSAGE_ID));
			summary.setTimestamp(3, (Timestamp) databaseParams.get(Constants.PARAM_INTIME_TO_ESB));
			summary.setTimestamp(4, (Timestamp) databaseParams.get(Constants.PARAM_INTIME_TO_SNOW));
			summary.setString(5, (String) databaseParams.get(Constants.PARAM_DESTINATION));
			summary.setString(6, (String) databaseParams.get(Constants.PARAM_SNOW_TICKET_NUMBER));
			summary.setString(7, (String) databaseParams.get(Constants.PARAM_CLIENT_NAME));
			summary.setString(8, Constants.STATUS_FAILED);
			summary.setString(9, (String) databaseParams.get(Constants.PARAM_SERVER_IP));
			summary.executeUpdate();
			resultSet = summary.getGeneratedKeys();
			while(resultSet.next()){
				transactionId = resultSet.getInt(1);
			}
			detail = connection.prepareStatement(Constants.CREATE_TICKET_IR_REQUEST_DETAIL_QUERY);
			detail.setInt(1, transactionId);
			detail.setString(2, (String) databaseParams.get(Constants.PARAM_REQUEST_PARAMETER));			
			detail.executeUpdate();
			
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage());
			e.printStackTrace();
		}finally{
			try { if (resultSet != null && !resultSet.isClosed()) resultSet.close(); } catch (Exception e) {};
		    try { if (summary != null && !summary.isClosed()) summary.close(); } catch (Exception e) {};
		    try { if (detail != null && !detail.isClosed()) detail.close(); } catch (Exception e) {};
		    try { if (connection != null && !connection.isClosed()) connection.close(); } catch (Exception e) {};
		}
	}
		
	/**
	 * @param databaseParameters
	 * @throws Exception
	 */	
	
	public void requestUploadAttachmentLog(HashMap<String, Object> databaseParams) {
		Connection connection = null;
		PreparedStatement summary=null;
		PreparedStatement detail= null;
		ResultSet resultSet = null;
		try {
			
			connection = datasource.getConnection();
			int transactionId = 0 ;
			String status =  (String) databaseParams.get(Constants.STATUS);
			String message =  (String) databaseParams.get(Constants.MESSAGE);
			if(status != null ){
				summary = connection.prepareStatement(Constants.CREATE_TICKET_OR_FAILED_RESPONSE_SUMMARY_QUERY, Statement.RETURN_GENERATED_KEYS);
				summary.setString(1, (String) databaseParams.get(Constants.PARAM_SOURCE));
				summary.setString(2, (String) databaseParams.get(Constants.PARAM_REQUEST_MESSAGE_ID));
				summary.setTimestamp(3, (Timestamp) databaseParams.get(Constants.PARAM_INTIME_TO_ESB));
				summary.setTimestamp(4, (Timestamp) databaseParams.get(Constants.PARAM_INTIME_TO_SNOW));
				summary.setString(5, (String) databaseParams.get(Constants.PARAM_DESTINATION));
				summary.setString(6, (String) databaseParams.get(Constants.PARAM_CLIENT_NAME));
				summary.setString(7, status);	
				summary.setString(8, (String) databaseParams.get(Constants.PARAM_REMEDY_TICKET_NUMBER));
				summary.setString(9, (String) databaseParams.get(Constants.PARAM_SNOW_TICKET_NUMBER));
				summary.executeUpdate();			
				resultSet = summary.getGeneratedKeys();
				while(resultSet.next()){
					transactionId = resultSet.getInt(1);
				}
				detail = connection.prepareStatement(Constants.CREATE_TICKET_OR_FAILED_RESPONSE_DETAIL_QUERY);
				detail.setInt(1, transactionId);
				detail.setString(2,message);	
				detail.setString(3,(String)databaseParams.get(Constants.PARAM_REQUEST_PARAMETER));
				detail.executeUpdate();
			
			}
			else{
			summary = connection.prepareStatement(Constants.UPLOAD_ATTACHMENT_REQUEST_SUMMARY_QUERY, Statement.RETURN_GENERATED_KEYS);
			summary.setString(1, (String) databaseParams.get(Constants.PARAM_SOURCE));
			summary.setString(2, (String) databaseParams.get(Constants.PARAM_REQUEST_MESSAGE_ID));
			summary.setTimestamp(3, (Timestamp) databaseParams.get(Constants.PARAM_INTIME_TO_ESB));
			summary.setTimestamp(4, (Timestamp) databaseParams.get(Constants.PARAM_INTIME_TO_SNOW));
			summary.setString(5, (String) databaseParams.get(Constants.PARAM_DESTINATION));
			summary.setString(6, (String) databaseParams.get(Constants.PARAM_REMEDY_TICKET_NUMBER));
			summary.setString(7, (String) databaseParams.get(Constants.PARAM_SNOW_TICKET_NUMBER));
			summary.setString(8, (String) databaseParams.get(Constants.PARAM_CLIENT_NAME));
			summary.setString(9, Constants.STATUS_FAILED);
			summary.setString(10, (String) databaseParams.get(Constants.PARAM_SERVER_IP));
			summary.executeUpdate();
			
			resultSet = summary.getGeneratedKeys();
			while(resultSet.next()){
				transactionId = resultSet.getInt(1);
			}
			detail = connection.prepareStatement(Constants.UPLOAD_ATTACHMENT_REQUEST_DETAIL_QUERY);
			detail.setInt(1, transactionId);
			detail.setString(2, (String) databaseParams.get(Constants.PARAM_REQUEST_PARAMETER));			
			detail.executeUpdate();
			}
			
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage());
			e.printStackTrace();
		}finally{
			try { if (resultSet != null && !resultSet.isClosed()) resultSet.close(); } catch (Exception e) {};
		    try { if (summary != null && !summary.isClosed()) summary.close(); } catch (Exception e) {};
		    try { if (detail != null && !detail.isClosed()) detail.close(); } catch (Exception e) {};
		    try { if (connection != null && !connection.isClosed()) connection.close(); } catch (Exception e) {};
		}
		
	}

	/**
	 * @param databaseParameters
	 * @throws Exception
	 */
	
	public void requestUpdateTicketIRLog(HashMap<String, Object> databaseParams) {
		Connection connection = null;
		PreparedStatement summary=null;
		PreparedStatement detail= null;
		ResultSet resultSet = null;
		try {
			System.out.println("status while save"+databaseParams.get(Constants.PARAM_STATUS));
			connection = datasource.getConnection();
			int transactionId = 0 ;
			summary = connection.prepareStatement(Constants.UPDATE_TICKET_IR_REQUEST_SUMMARY_QUERY, Statement.RETURN_GENERATED_KEYS);
			summary.setString(1, (String) databaseParams.get(Constants.PARAM_SOURCE));
			summary.setString(2, (String) databaseParams.get(Constants.PARAM_REQUEST_MESSAGE_ID));
			summary.setTimestamp(3, (Timestamp) databaseParams.get(Constants.PARAM_INTIME_TO_ESB));
			summary.setTimestamp(4, (Timestamp) databaseParams.get(Constants.PARAM_SNOW_OUT_TIME));
			summary.setString(5, (String) databaseParams.get(Constants.PARAM_DESTINATION));
			summary.setString(6, (String) databaseParams.get(Constants.PARAM_SNOW_TICKET_NUMBER));
			summary.setString(7, (String) databaseParams.get(Constants.PARAM_REMEDY_TICKET_NUMBER));
			summary.setString(8, (String) databaseParams.get(Constants.PARAM_CLIENT_NAME));
			summary.setString(9, (String) databaseParams.get(Constants.PARAM_STATUS));
			summary.setString(10, (String) databaseParams.get(Constants.PARAM_SERVER_IP));
			summary.setString(11, (String) databaseParams.get(Constants.PARAM_REQUEST_MESSAGE_ID));
			summary.setTimestamp(12, (Timestamp) databaseParams.get(Constants.PARAM_ESB_OUT_TIME));
			summary.setTimestamp(13, (Timestamp) databaseParams.get(Constants.PARAM_INTIME_TO_SNOW));
			summary.executeUpdate();
			resultSet = summary.getGeneratedKeys();
			while(resultSet.next()){
				transactionId = resultSet.getInt(1);
			}
			detail = connection.prepareStatement(Constants.UPDATE_TICKET_IR_REQUEST_DETAIL_QUERY);
			detail.setInt(1, transactionId);
			detail.setString(2, (String) databaseParams.get(Constants.PARAM_REQUEST_PARAMETER));
			detail.setString(3, (String) databaseParams.get(Constants.RESPONSE));
			detail.executeUpdate();
			System.out.println("status while save"+databaseParams.get(Constants.PARAM_STATUS));
			
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage());
			e.printStackTrace();
		}finally{
			try { if (resultSet != null && !resultSet.isClosed()) resultSet.close(); } catch (Exception e) {};
		    try { if (summary != null && !summary.isClosed()) summary.close(); } catch (Exception e) {};
		    try { if (detail != null && !detail.isClosed()) detail.close(); } catch (Exception e) {};
		    try { if (connection != null && !connection.isClosed()) connection.close(); } catch (Exception e) {};
		}
		
	}

	/**
	 * @param databaseParameters
	 * @throws Exception
	 */
	
	public void requestUpdateTicketORLog(HashMap<String, Object> databaseParams) {
		Connection connection = null;
		PreparedStatement summary=null;
		PreparedStatement detail= null;
		ResultSet resultSet = null;
		try {
			connection = datasource.getConnection();
			int transactionId = 0 ;
			String status =  (String) databaseParams.get(Constants.STATUS);
			if(status == "Failure"){
				summary = connection.prepareStatement(Constants.CREATE_TICKET_OR_FAILED_RESPONSE_SUMMARY_QUERY, Statement.RETURN_GENERATED_KEYS);
				summary.setString(1, (String) databaseParams.get(Constants.PARAM_SOURCE));
				summary.setString(2, (String) databaseParams.get(Constants.PARAM_REQUEST_MESSAGE_ID));
				summary.setTimestamp(3, (Timestamp) databaseParams.get(Constants.PARAM_INTIME_TO_ESB));
				summary.setTimestamp(4, (Timestamp) databaseParams.get(Constants.PARAM_INTIME_TO_SNOW));
				summary.setString(5, (String) databaseParams.get(Constants.PARAM_DESTINATION));
				summary.setString(6, (String) databaseParams.get(Constants.PARAM_CLIENT_NAME));
				summary.setString(7, Constants.STATUS_FAILED);	
				summary.setString(8, (String) databaseParams.get(Constants.PARAM_REMEDY_TICKET_NUMBER));
				summary.setString(9, (String) databaseParams.get(Constants.PARAM_SNOW_TICKET_NUMBER));
				summary.executeUpdate();			
				resultSet = summary.getGeneratedKeys();
				while(resultSet.next()){
					transactionId = resultSet.getInt(1);
				}
				detail = connection.prepareStatement(Constants.CREATE_TICKET_OR_FAILED_RESPONSE_DETAIL_QUERY);
				detail.setInt(1, transactionId);
				detail.setString(2,"Error while connecting to ServiceNow API");	
				detail.setString(3,(String)databaseParams.get(Constants.PARAM_REQUEST_PARAMETER));
				detail.executeUpdate();
			}
			else{
			summary = connection.prepareStatement(Constants.UPDATE_TICKET_OR_REQUEST_SUMMARY_QUERY, Statement.RETURN_GENERATED_KEYS);
			summary.setString(1, (String) databaseParams.get(Constants.PARAM_SOURCE));
			summary.setString(2, (String) databaseParams.get(Constants.PARAM_REQUEST_MESSAGE_ID));
			summary.setTimestamp(3, (Timestamp) databaseParams.get(Constants.PARAM_INTIME_TO_ESB));
			summary.setTimestamp(4, (Timestamp) databaseParams.get(Constants.PARAM_INTIME_TO_SNOW));
			summary.setString(5, (String) databaseParams.get(Constants.PARAM_DESTINATION));
			summary.setString(6, (String) databaseParams.get(Constants.PARAM_CLIENT_NAME));
			summary.setString(7, Constants.STATUS_FAILED);
			summary.setString(8, (String) databaseParams.get(Constants.PARAM_REMEDY_TICKET_NUMBER));
			summary.setString(9, (String) databaseParams.get(Constants.PARAM_SERVER_IP));
			summary.executeUpdate();			
			resultSet = summary.getGeneratedKeys();
			while(resultSet.next()){
				transactionId = resultSet.getInt(1);
			}
			detail = connection.prepareStatement(Constants.UPDATE_TICKET_OR_REQUEST_DETAIL_QUERY);
			detail.setInt(1, transactionId);
			detail.setString(2, (String) databaseParams.get(Constants.PARAM_REQUEST_PARAMETER));			
			detail.executeUpdate();
			}
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage());
			e.printStackTrace();
		}finally{
			try { if (resultSet != null && !resultSet.isClosed()) resultSet.close(); } catch (Exception e) {};
		    try { if (summary != null && !summary.isClosed()) summary.close(); } catch (Exception e) {};
		    try { if (detail != null && !detail.isClosed()) detail.close(); } catch (Exception e) {};
		    try { if (connection != null && !connection.isClosed()) connection.close(); } catch (Exception e) {};
		}
		
	}

	/**
	 * @param databaseParameters
	 * @throws Exception
	 */
	
	public void responseCreateTicketORLog(HashMap<String , Object> databaseParams) {
		Connection connection = null;
		PreparedStatement summary=null;
		PreparedStatement detail= null;
		try {
			connection = datasource.getConnection();
			summary = connection.prepareStatement(Constants.CREATE_TICKET_OR_RESPONSE_SUMMARY_QUERY);
			summary.setString(1, (String) databaseParams.get(Constants.PARAM_RESPONSE_MESSAGE_ID));
			summary.setTimestamp(2, (Timestamp) databaseParams.get(Constants.PARAM_OUTTIME_FROM_SNOW));
			summary.setTimestamp(3,  (Timestamp) databaseParams.get(Constants.PARAM_OUTTIME_FROM_ESB));
			summary.setString(4, (String) databaseParams.get(Constants.PARAM_SNOW_TICKET_NUMBER));
		    summary.setString(5, (String) databaseParams.get(Constants.PARAM_STATUS));
			summary.setString(6, (String) databaseParams.get(Constants.PARAM_REQUEST_MESSAGE_ID));		
			summary.executeUpdate();			
			detail = connection.prepareStatement(Constants.CREATE_TICKET_OR_RESPONSE_DETAIL_QUERY);			
			detail.setString(1, (String) databaseParams.get(Constants.PARAM_RESPONSE_PARAMETER));
			detail.setString(2, (String) databaseParams.get(Constants.PARAM_REQUEST_MESSAGE_ID));
			detail.executeUpdate();			
			
			
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage());
			e.printStackTrace();
		}finally{
		    try { if (summary != null && !summary.isClosed()) summary.close(); } catch (Exception e) {};
		    try { if (detail != null && !detail.isClosed()) detail.close(); } catch (Exception e) {};
		    try { if (connection != null && !connection.isClosed()) connection.close(); } catch (Exception e) {};
		}
	}
	
	/**
	 * @param databaseParameters
	 * @throws Exception
	 */
	
	public void responseCreateTicketIRLog(HashMap<String , Object> databaseParams) {
		Connection connection = null;
		PreparedStatement summary=null;
		PreparedStatement detail= null;
		try {
			connection = datasource.getConnection();		     
		 	summary = connection.prepareStatement(Constants.CREATE_TICKET_IR_RESPONSE_SUMMARY_QUERY);
		    summary.setString(1,(String) databaseParams.get(Constants.PARAM_RESPONSE_MESSAGE_ID) );		   
		    summary.setTimestamp(2, (Timestamp) databaseParams.get(Constants.PARAM_OUTTIME_FROM_SNOW));
		    summary.setTimestamp(3, (Timestamp) databaseParams.get(Constants.PARAM_OUTTIME_FROM_ESB));
		    summary.setString(4, (String) databaseParams.get(Constants.PARAM_REMEDY_TICKET_NUMBER));
		    summary.setString(5,(String) databaseParams.get(Constants.PARAM_STATUS));
		    summary.setString(6,(String) databaseParams.get(Constants.PARAM_REQUEST_MESSAGE_ID));		      	
		    summary.executeUpdate();		       
		    detail = connection.prepareStatement(Constants.CREATE_TICKET_IR_RESPONSE_DETAIL_QUERY);			
			detail.setString(1, (String) databaseParams.get(Constants.PARAM_RESPONSE_PARAMETER));
			detail.setString(2, (String) databaseParams.get(Constants.PARAM_REQUEST_MESSAGE_ID));
			detail.executeUpdate();	       
			
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage());
		    e.printStackTrace();
		}finally{
		    try { if (summary != null && !summary.isClosed()) summary.close(); } catch (Exception e) {};
		    try { if (detail != null && !detail.isClosed()) detail.close(); } catch (Exception e) {};
		    try { if (connection != null && !connection.isClosed()) connection.close(); } catch (Exception e) {};
		}
	}
	
	/**
	 * @param databaseParameters
	 * @throws Exception
	 */
	
	public void responseUploadAttachmentLog(HashMap<String, Object> databaseParams) {
		Connection connection = null;
		PreparedStatement summary=null;
		PreparedStatement detail= null;
		try {
			connection = datasource.getConnection();		     
		 	summary = connection.prepareStatement(Constants.UPLOAD_ATTACHMENT_RESPONSE_SUMMARY_QUERY);
		    summary.setString(1,(String) databaseParams.get(Constants.PARAM_RESPONSE_MESSAGE_ID) );		   
		    summary.setTimestamp(2, (Timestamp) databaseParams.get(Constants.PARAM_OUTTIME_FROM_SNOW));
		    summary.setTimestamp(3, (Timestamp) databaseParams.get(Constants.PARAM_OUTTIME_FROM_ESB));
		    summary.setString(4,(String) databaseParams.get(Constants.PARAM_STATUS));
		    summary.setString(5,(String) databaseParams.get(Constants.PARAM_REQUEST_MESSAGE_ID));		      	
		    summary.executeUpdate();		       
		    detail = connection.prepareStatement(Constants.UPLOAD_ATTACHMENT_RESPONSE_DETAIL_QUERY);			
			detail.setString(1, (String) databaseParams.get(Constants.PARAM_RESPONSE_PARAMETER));
			detail.setString(2, (String) databaseParams.get(Constants.PARAM_REQUEST_MESSAGE_ID));
			detail.executeUpdate();			       

		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage());
		    e.printStackTrace();
		}finally{
		    try { if (summary != null && !summary.isClosed()) summary.close(); } catch (Exception e) {};
		    try { if (detail != null && !detail.isClosed()) detail.close(); } catch (Exception e) {};
		    try { if (connection != null && !connection.isClosed()) connection.close(); } catch (Exception e) {};
		}
		
	}

	/**
	 * @param databaseParameters
	 * @throws Exception
	 */
	
	public void responseUpdateTicketIRLog(HashMap<String, Object> databaseParams) {
		Connection connection = null;
		PreparedStatement summary=null;
		PreparedStatement detail= null;
		try {
			connection = datasource.getConnection();		     
		 	summary = connection.prepareStatement(Constants.UPDATE_TICKET_IR_RESPONSE_SUMMARY_QUERY);
		    summary.setString(1,(String) databaseParams.get(Constants.PARAM_RESPONSE_MESSAGE_ID) );		   
		    summary.setTimestamp(2, (Timestamp) databaseParams.get(Constants.PARAM_OUTTIME_FROM_SNOW));
		    summary.setTimestamp(3, (Timestamp) databaseParams.get(Constants.PARAM_OUTTIME_FROM_ESB));
		    summary.setString(4,(String) databaseParams.get(Constants.PARAM_STATUS));
		    summary.setString(5,(String) databaseParams.get(Constants.PARAM_REQUEST_MESSAGE_ID));		      	
		    summary.executeUpdate();		       
		    detail = connection.prepareStatement(Constants.UPDATE_TICKET_IR_RESPONSE_DETAIL_QUERY);			
			detail.setString(1, (String) databaseParams.get(Constants.PARAM_RESPONSE_PARAMETER));
			detail.setString(2, (String) databaseParams.get(Constants.PARAM_REQUEST_MESSAGE_ID));
			detail.executeUpdate();	       
			
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage());
		    e.printStackTrace();
		}finally{
		    try { if (summary != null && !summary.isClosed()) summary.close(); } catch (Exception e) {};
		    try { if (detail != null && !detail.isClosed()) detail.close(); } catch (Exception e) {};
		    try { if (connection != null && !connection.isClosed()) connection.close(); } catch (Exception e) {};
		}
		
	}

	/**
	 * @param databaseParameters
	 * @throws Exception
	 */
	
	public void responseUpdateTicketORLog(HashMap<String, Object> databaseParams) {
		Connection connection = null;
		PreparedStatement summary=null;
		PreparedStatement detail= null;
		try {
			connection = datasource.getConnection();		     
		 	summary = connection.prepareStatement(Constants.UPDATE_TICKET_OR_RESPONSE_SUMMARY_QUERY);
		    summary.setString(1,(String) databaseParams.get(Constants.PARAM_RESPONSE_MESSAGE_ID) );		   
		    summary.setTimestamp(2, (Timestamp) databaseParams.get(Constants.PARAM_OUTTIME_FROM_SNOW));
		    summary.setTimestamp(3, (Timestamp) databaseParams.get(Constants.PARAM_OUTTIME_FROM_ESB));
		    summary.setString(4, (String) databaseParams.get(Constants.PARAM_SNOW_TICKET_NUMBER));
		    summary.setString(5,(String) databaseParams.get(Constants.PARAM_STATUS));
		    summary.setString(6,(String) databaseParams.get(Constants.PARAM_REQUEST_MESSAGE_ID));		      	
		    summary.executeUpdate();		       
		    detail = connection.prepareStatement(Constants.UPDATE_TICKET_OR_RESPONSE_DETAIL_QUERY);			
			detail.setString(1, (String) databaseParams.get(Constants.PARAM_RESPONSE_PARAMETER));
			detail.setString(2, (String) databaseParams.get(Constants.PARAM_REQUEST_MESSAGE_ID));
			detail.executeUpdate();		       
			
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage());
		    e.printStackTrace();
		}finally{
		    try { if (summary != null && !summary.isClosed()) summary.close(); } catch (Exception e) {};
		    try { if (detail != null && !detail.isClosed()) detail.close(); } catch (Exception e) {};
		    try { if (connection != null && !connection.isClosed()) connection.close(); } catch (Exception e) {};
		}
		
	}
	
	/**
	 * @param databaseParameters
	 * @throws Exception
	 */
	public void updateStatus(HashMap<String, Object> databaseParams){
		Connection connection = null;
		PreparedStatement summary=null;
		PreparedStatement detail= null;		
		try {
			connection = datasource.getConnection();
		    summary = connection.prepareStatement(Constants.UPDATE_STATUS_SUMMARY_QUERY);
		    summary.setString(1,Constants.STATUS_FAILED );		   		   
		    summary.setString(2,(String) databaseParams.get(Constants.PARAM_REQUEST_MESSAGE_ID) );
		    summary.executeUpdate();	      
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage());
			e.printStackTrace();
		}finally{
		    try { if (summary != null && !summary.isClosed()) summary.close(); } catch (Exception e) {};
		    try { if (detail != null && !detail.isClosed()) detail.close(); } catch (Exception e) {};
		    try { if (connection != null && !connection.isClosed()) connection.close(); } catch (Exception e) {};
		}	      
	}

	
	
	public String destinationService(String serviceName, String clientName){
		Connection connection = null;
		ResultSet resultSet = null;
		PreparedStatement urlStatement=null;
		String url = "";
		try {
			connection = datasource.getConnection();
		    urlStatement = connection.prepareStatement(Constants.DESTINATION_SERVICE_QUERY);
		    urlStatement.setString(1,serviceName );
		    urlStatement.setString(2,clientName);	
		    resultSet = urlStatement.executeQuery();
			while(resultSet.next()){
				url = resultSet.getString(1);
			}
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage());
			e.printStackTrace();
		}finally{
			try { if (urlStatement != null && !urlStatement.isClosed()) urlStatement.close(); } catch (Exception e) {};
			try { if (resultSet != null && !resultSet.isClosed()) resultSet.close(); } catch (Exception e) {};
		    try { if (connection != null && !connection.isClosed()) connection.close(); } catch (Exception e) {};
		}
		return url;
	}
	
	public String clientName(String clientId){
		Connection connection = null;
		PreparedStatement clientStatement=null;
		ResultSet resultSet = null;
		String clientName="";
		try {
			connection = datasource.getConnection();
		    clientStatement = connection.prepareStatement(Constants.CLIENT_NAME_QUERY);
		    clientStatement.setString(1,clientId);		   		   
		    resultSet = clientStatement.executeQuery();
			while(resultSet.next()){
				clientName = resultSet.getString(1);
			}
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage());
			e.printStackTrace();
		}finally{
			try { if (resultSet != null && !resultSet.isClosed()) resultSet.close(); } catch (Exception e) {};
		    try { if (clientStatement != null && !clientStatement.isClosed()) clientStatement.close(); } catch (Exception e) {};
		    try { if (connection != null && !connection.isClosed()) connection.close(); } catch (Exception e) {};
		}	
		return clientName;
	}

	public void requestCreateDataSyncLog(HashMap<String, Object> databaseParams) {
		Connection connection = null;
		PreparedStatement summary=null;
		PreparedStatement detail= null;
		ResultSet resultSet = null;
		try {
		
			connection = datasource.getConnection();
			//int transactionId = 0 ;
			summary = connection.prepareStatement(Constants.CREATE_DATA_SYNC_QUERY, Statement.RETURN_GENERATED_KEYS);
	      /*summary.setTimestamp(3, (Timestamp) databaseParams.get(Constants.PARAM_INTIME_TO_ESB));
			summary.setTimestamp(4, (Timestamp) databaseParams.get(Constants.PARAM_INTIME_TO_SNOW));
			summary.setString(5, (String) databaseParams.get(Constants.PARAM_DESTINATION));
			summary.setTimestamp(9, (Timestamp) databaseParams.get(Constants.PARAM_ESB_OUT_TIME));
			summary.setTimestamp(10, (Timestamp) databaseParams.get(Constants.PARAM_SNOW_OUT_TIME));
			summary.setString(1, (String) databaseParams.get(Constants.PARAM_SOURCE));*/
			summary.setString(1, (String) databaseParams.get(Constants.PARAM_REQUEST_MESSAGE_ID));
			summary.setString(2, (String) databaseParams.get(Constants.PARAM_CLIENT_NAME));
			summary.setString(3, (String) databaseParams.get(Constants.PARAM_STATUS));
			summary.setString(4, (String) databaseParams.get(Constants.PARAM_SERVER_IP));
			summary.setString(5, (String) databaseParams.get(Constants.PARAM_REQUEST_PARAMETER));
			summary.setString(6, (String) databaseParams.get(Constants.RESPONSE));
			summary.setString(7, (String) databaseParams.get(Constants.MODE));
			summary.setTimestamp(8, (Timestamp) databaseParams.get(Constants.PARAM_INTIME_TO_ESB));
			summary.setTimestamp(9, (Timestamp) databaseParams.get(Constants.PARAM_INTIME_TO_SNOW));
			summary.setTimestamp(10, (Timestamp) databaseParams.get(Constants.PARAM_OUTTIME_FROM_ESB));
			summary.setTimestamp(11, (Timestamp) databaseParams.get(Constants.PARAM_OUTTIME_FROM_SNOW));
			summary.setString(12, (String) databaseParams.get(Constants.PARAM_SOURCE));
			summary.setString(13, (String) databaseParams.get(Constants.PARAM_DESTINATION));
			summary.executeUpdate();
			resultSet = summary.getGeneratedKeys();
			
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage());
			e.printStackTrace();
		}finally{
			try { if (resultSet != null && !resultSet.isClosed()) resultSet.close(); } catch (Exception e) {};
		    try { if (summary != null && !summary.isClosed()) summary.close(); } catch (Exception e) {};
		    try { if (detail != null && !detail.isClosed()) detail.close(); } catch (Exception e) {};
		    try { if (connection != null && !connection.isClosed()) connection.close(); } catch (Exception e) {};
		}
		
	}

	@Override
	public void requestUpdateDataSyncLog(HashMap<String, Object> databaseParams) {
		Connection connection = null;
		PreparedStatement summary=null;
		PreparedStatement detail= null;
		ResultSet resultSet = null;
		try {
		
			connection = datasource.getConnection();
			//int transactionId = 0 ;
			summary = connection.prepareStatement(Constants.UPDATE_DATA_SYNC_QUERY, Statement.RETURN_GENERATED_KEYS);
		  /*summary.setString(1, (String) databaseParams.get(Constants.PARAM_SOURCE));
            summary.setTimestamp(9, (Timestamp) databaseParams.get(Constants.PARAM_ESB_OUT_TIME));
	    	summary.setTimestamp(10, (Timestamp) databaseParams.get(Constants.PARAM_SNOW_OUT_TIME));
        	summary.setTimestamp(3, (Timestamp) databaseParams.get(Constants.PARAM_INTIME_TO_ESB));
			summary.setTimestamp(4, (Timestamp) databaseParams.get(Constants.PARAM_INTIME_TO_SNOW));
			summary.setString(5, (String) databaseParams.get(Constants.PARAM_DESTINATION));*/
			summary.setString(1, (String) databaseParams.get(Constants.PARAM_REQUEST_MESSAGE_ID));
			summary.setString(2, (String) databaseParams.get(Constants.PARAM_CLIENT_NAME));
			summary.setString(3, (String) databaseParams.get(Constants.PARAM_STATUS));
			summary.setString(4, (String) databaseParams.get(Constants.PARAM_SERVER_IP));
			summary.setString(5, (String) databaseParams.get(Constants.PARAM_REQUEST_PARAMETER));
			summary.setString(6, (String) databaseParams.get(Constants.RESPONSE));
			summary.setString(7, (String) databaseParams.get(Constants.MODE));
			summary.setTimestamp(8, (Timestamp) databaseParams.get(Constants.DATE));
			summary.executeUpdate();
			resultSet = summary.getGeneratedKeys();
			
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage());
			e.printStackTrace();
		}finally{
			try { if (resultSet != null && !resultSet.isClosed()) resultSet.close(); } catch (Exception e) {};
		    try { if (summary != null && !summary.isClosed()) summary.close(); } catch (Exception e) {};
		    try { if (detail != null && !detail.isClosed()) detail.close(); } catch (Exception e) {};
		    try { if (connection != null && !connection.isClosed()) connection.close(); } catch (Exception e) {};
		}
		
	}

	@Override
	public String foundationDestinationService(String serviceName,
			String clientName) {
		Connection connection = null;
		ResultSet resultSet = null;
		PreparedStatement urlStatement=null;
		String url = "";
		try {
			connection = datasource.getConnection();
		    urlStatement = connection.prepareStatement(Constants.DESTINATION_SERVICE_QUERY);
		    urlStatement.setString(1,serviceName );
		    urlStatement.setString(2,clientName);	
		    resultSet = urlStatement.executeQuery();
			while(resultSet.next()){
				url = resultSet.getString(1);
			}
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage());
			e.printStackTrace();
		}finally{
			try { if (urlStatement != null && !urlStatement.isClosed()) urlStatement.close(); } catch (Exception e) {};
			try { if (resultSet != null && !resultSet.isClosed()) resultSet.close(); } catch (Exception e) {};
		    try { if (connection != null && !connection.isClosed()) connection.close(); } catch (Exception e) {};
		}
		return url;
	}
}
