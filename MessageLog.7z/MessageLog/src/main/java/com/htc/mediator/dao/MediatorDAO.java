package com.htc.mediator.dao;

import java.util.HashMap;

public interface MediatorDAO {
	
	public void requestCreateTicketORLog(HashMap<String , Object> databaseParams) ;
	
	public void requestCreateTicketIRLog(HashMap<String , Object> databaseParams) ;
	
	public void requestUploadAttachmentLog(HashMap<String , Object> databaseParams);
	
	public void requestUpdateTicketIRLog(HashMap<String , Object> databaseParams) ;
	
	public void requestUpdateDataSyncLog(HashMap<String , Object> databaseParams) ;
	
	public void requestCreateDataSyncLog(HashMap<String , Object> databaseParams) ;
	
	public void requestUpdateTicketORLog(HashMap<String , Object> databaseParams);
	
	public void responseCreateTicketORLog(HashMap<String , Object> databaseParams);
	
	public void responseCreateTicketIRLog(HashMap<String , Object> databaseParams);
	
	public void responseUploadAttachmentLog(HashMap<String , Object> databaseParams);
	
	public void responseUpdateTicketIRLog(HashMap<String , Object> databaseParams);
	
	public void responseUpdateTicketORLog(HashMap<String , Object> databaseParams);

	public void updateStatus(HashMap<String, Object> databaseParams);
	
	public String destinationService(String serviceName, String clientName);
	
	public String foundationDestinationService(String serviceName, String clientName);
	
	public String clientName(String clientId);
	
}
