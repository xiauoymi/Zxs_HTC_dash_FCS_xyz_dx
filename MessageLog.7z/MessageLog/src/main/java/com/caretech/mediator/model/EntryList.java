package com.caretech.mediator.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

/**
 * @author gopinathn
 *
 */
@JsonInclude(Include.NON_NULL)
@JsonTypeName(value="EntryList")
@XmlRootElement
@XStreamAlias("EntryList")
public class EntryList {
	
	@XStreamAsAttribute
	private String Count;
	
	@XStreamAsAttribute
	private String Limit;
	
	@XStreamAsAttribute
	private String Qualification;
	
	@XStreamAsAttribute
	private String SortItems;
	
	@XStreamAsAttribute
	private String Structure;

	@XStreamImplicit
	private List<Entry> Entry = new ArrayList<Entry>();

	@JsonProperty
	@XmlElement
	public List<Entry> getEntry() {
		return Entry;
	}

	public void setEntry(List<Entry> entry) {
		Entry = entry;
	}

	@JsonProperty
	@XmlAttribute
	public String getCount() {
		return Count;
	}

	public void setCount(String count) {
		Count = count;
	}

	@JsonProperty
	@XmlAttribute
	public String getLimit() {
		return Limit;
	}

	public void setLimit(String limit) {
		Limit = limit;
	}

	@JsonProperty
	@XmlAttribute
	public String getQualification() {
		return Qualification;
	}

	public void setQualification(String qualification) {
		Qualification = qualification;
	}

	@JsonProperty
	@XmlAttribute
	public String getSortItems() {
		return SortItems;
	}

	public void setSortItems(String sortItems) {
		SortItems = sortItems;
	}

	@JsonProperty
	@XmlAttribute
	public String getStructure() {
		return Structure;
	}

	public void setStructure(String structure) {
		Structure = structure;
	}
	
	
}
