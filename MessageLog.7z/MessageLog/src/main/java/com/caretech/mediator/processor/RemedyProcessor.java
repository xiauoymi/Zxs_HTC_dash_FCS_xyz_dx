package com.caretech.mediator.processor;

import java.util.Date;
import java.util.Map;
import java.util.logging.Logger;

import org.apache.commons.codec.binary.Base64;

import com.caretech.mediator.constant.Constants;
import com.caretech.mediator.utils.Utilities;
import com.caretech.webservice.integration.AuthenticationInfo;
import com.caretech.webservice.integration.CMNIntegrationCreateInBoundTicketWBService;
import com.caretech.webservice.integration.NewPort0PortType;
import com.caretech.webservice.integration.PriorityType;
import com.caretech.webservice.integration.StatusType;
import com.caretech.webservice.integration.TicketStatusType;
import com.caretech.webservice.integration.TitleType;
import com.caretech.webservice.integration.create.SourceType;

public class RemedyProcessor {
	
	private Logger LOGGER = Logger.getLogger(RemedyProcessor.class.getName());
	private  String submitter;
    private  String assignedTo;
    private  StatusType status;    
    private  String shortDescription;
    private  String attachment5CAttachmentName;
    private  byte[] attachment5CAttachmentData;
    private  Integer attachment5CAttachmentOrigSize;
    private  String patientAttachment5CAttachmentName;
    private  byte[] patientAttachment5CAttachmentData;
    private  Integer patientAttachment5CAttachmentOrigSize;
    private  String emailAddressC;
    private  String floorC;
    //private  String masterClientC;
    private  TitleType titleC;
    private  String assignedIndividualC;
    private  String pagerPinC;
    private  String attachment1CAttachmentName;
    private  byte[] attachment1CAttachmentData;
    private  Integer attachment1CAttachmentOrigSize;
    private  String attachment2CAttachmentName;
    private  byte[] attachment2CAttachmentData;
    private  Integer attachment2CAttachmentOrigSize;
    private  String attachment3CAttachmentName;
    private  byte[] attachment3CAttachmentData;
    private  Integer attachment3CAttachmentOrigSize;
    private  String attachment4CAttachmentName;
    private  byte[] attachment4CAttachmentData;
    private  Integer attachment4CAttachmentOrigSize;
    private  String suiteC;
    private  String customerTicketC;
    //private  XMLGregorianCalendar dateTimePendingOffC;
    //private  String businessOrganizationC;
    private  String ctsTicketC;
    private  String computerNameC;
    private  String departmentC;
    //private  XMLGregorianCalendar dateTimeAssignedC;
    //private  XMLGregorianCalendar ticketCreateDateC;
    private  String phoneWorkC;
    private  String pendingReasonC;
    private  TicketStatusType ticketStatusC;
    private  PriorityType priorityC;
    private  String summaryC;
    private  String lastNameC;
    private  String firstNameC;
    //private  XMLGregorianCalendar dateTimeWorkInProgressC;
    private  String vendorsC;
    private  String clientC;
    private  String typeC;
    private  String patientAttachment1CAttachmentName;
    private  Integer patientAttachment1CAttachmentOrigSize;
    private  String patientAttachment2CAttachmentName;
    private  byte[] patientAttachment2CAttachmentData;
    private  Integer patientAttachment2CAttachmentOrigSize;
    private  String patientAttachment3CAttachmentName;
    private  byte[] patientAttachment3CAttachmentData;
    private  Integer patientAttachment3CAttachmentOrigSize;
    private  String patientAttachment4CAttachmentName;
    private  byte[] patientAttachment4CAttachmentData;
    private  Integer patientAttachment4CAttachmentOrigSize;
    private  String itemC;
    private  String vendorRefC;
    private  String officeC;
    //private  XMLGregorianCalendar dateTimePendingOnC;
    private  String pagerNumericC;
    private  String buildingC;
    private  String securePatientInformationC;
    private  String phoneExtC;
    private  String categoryC;
    private  String ticketSubmitterC;
    private  String assetTagC;
    private  String assignedGroupC;
    private  String workLogC;
    private  String description;
    private String integrationCustomerName;
    private String processed;
    private String resolution;
    private String foreignParentKey;
    private String integrationAttribute01;
    private String integrationAttribute02;
    private String integrationAttribute03;
    private String integrationAttribute04;
    private String integrationAttribute05;
    private String integrationAttribute06;
    private String integrationAttribute07;
    private String integrationAttribute08;
    private String rootCauseCategory;
	private String phoneTest;
	private String errorMessage;
	private String networkLogin;
	private Integer temp01;
	private String temp02;
	private String temp03;
	private String additionalComments;
	private SourceType source;
    private  byte[] patientAttachment1CAttachmentData;
    private  AuthenticationInfo parameters = new AuthenticationInfo(Constants.WSDL_AUTHENTICATION_USERNAME, 
    						Constants.WSDL_AUTHENTICATION_PASSWORD, "", "", "");

	public String updateTicketStatus(Map<String, Object> remedyParameters)throws Exception {
		//System.out.println("Remedy parameterssss!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"+remedyParameters);
		Date startTime = new Date();
		LOGGER.info("Remedy Update Service call starts :"+Utilities.getCurrentDateTime(startTime));
		vendorRefC = (String)remedyParameters.get("Vendor_Ref___c");
		customerTicketC = (String)remedyParameters.get("Vendor_Ref___c");
		workLogC = (String)remedyParameters.get("Work_Log__c");
		ticketStatusC = remedyParameters.get("Ticket_Status__c") != null ? TicketStatusType.fromValue((String)remedyParameters.get("Ticket_Status__c")) : null;
		//shortDescription = (String)remedyParameters.get("Short_Description");
		shortDescription = "NA";
		submitter = "NA";
		//ticketCreateDateC = (String)remedyParameters.get("Ticket_Create_Date__c");
		assignedTo = (String)remedyParameters.get("Assigned_To");
		firstNameC = (String)remedyParameters.get("First_Name__c");
		lastNameC = (String)remedyParameters.get("Last_Name__c");
		phoneWorkC = (String)remedyParameters.get("Phone-Work__c");
		pagerPinC = (String)remedyParameters.get("Pager_Pin__c");
		clientC = (String)remedyParameters.get("Client__c");
		buildingC = (String)remedyParameters.get("Building__c");
		departmentC = (String)remedyParameters.get("Department__c");
		summaryC = (String)remedyParameters.get("Summary__c");
		status = StatusType.fromValue("New");
		categoryC = (String)remedyParameters.get("Category__c");
		typeC = (String)remedyParameters.get("Type__c");
		itemC=(String)remedyParameters.get("Item__c");
		assignedGroupC = remedyParameters.get("Assigned_Group__c") != null ? String.valueOf(remedyParameters.get("Assigned_Group__c")) : null;
		if(assignedGroupC != null){
			assignedGroupC = assignedGroupC.replace("â€“", "–");
		}
		priorityC =  remedyParameters.get("Priority__c") != null ? PriorityType.fromValue((String)remedyParameters.get("Priority__c")) : null;
		assignedIndividualC = (String)remedyParameters.get("Assigned_Individual__c");
		assetTagC = (String)remedyParameters.get("Asset_Tag__c");
		//businessOrganizationC = (String)remedyParameters.get("Business_Organization__c");
		//dateTimeAssignedC = (String)remedyParameters.get("Date_Time_Assigned__c");
		vendorsC = (String)remedyParameters.get("Vendors__c");
		ctsTicketC = (String)remedyParameters.get("CTS_Ticket__c");
		description = (String)remedyParameters.get("Description");
		pendingReasonC = (String)remedyParameters.get("Pending_Reason");
		integrationAttribute01 = (String)remedyParameters.get("Integration_Attribute_01");
		integrationAttribute02 = (String)remedyParameters.get("Integration_Attribute_02");
		integrationAttribute03 = (String)remedyParameters.get("Integration_Attribute_03");
		integrationAttribute04 = (String)remedyParameters.get("Integration_Attribute_04");
		integrationAttribute05 = (String)remedyParameters.get("Integration_Attribute_05");
		integrationAttribute06 = (String)remedyParameters.get("Integration_Attribute_06");
		integrationAttribute07 = (String)remedyParameters.get("Integration_Attribute_07");
		integrationAttribute08 = (String)remedyParameters.get("Integration_Attribute_08");
		rootCauseCategory = (String)remedyParameters.get("Root_Cause_Category");
		resolution = (String)remedyParameters.get("Resolution");
		securePatientInformationC = (String)remedyParameters.get("Secure_Patient_Information");
		networkLogin = (String)remedyParameters.get("Network_Login");
		additionalComments = (String)remedyParameters.get("Additional_Comments");
		source = remedyParameters.get("Source") != null ? SourceType.fromValue((String)remedyParameters.get("Source")) : null;
		attachment1CAttachmentName = (String)remedyParameters.get("attachment_1_attachmentName");
		attachment1CAttachmentData = remedyParameters.get("attachment_1_attachmentData") != null ?
				Base64.decodeBase64(((String)remedyParameters.get("attachment_1_attachmentData")).getBytes()) : null;
		attachment2CAttachmentName = (String)remedyParameters.get("attachment_2_attachmentName");
		attachment2CAttachmentData = remedyParameters.get("attachment_2_attachmentData") != null ?
				Base64.decodeBase64(((String)remedyParameters.get("attachment_2_attachmentData")).getBytes()) : null;
		attachment3CAttachmentName = (String)remedyParameters.get("attachment_3_attachmentName");
		attachment3CAttachmentData = remedyParameters.get("attachment_3_attachmentData") != null ?
				Base64.decodeBase64(((String)remedyParameters.get("attachment_3_attachmentData")).getBytes()) : null;
		attachment4CAttachmentName = (String)remedyParameters.get("attachment_4_attachmentName");
		attachment4CAttachmentData = remedyParameters.get("attachment_4_attachmentData") != null ?
				Base64.decodeBase64(((String)remedyParameters.get("attachment_4_attachmentData")).getBytes()) : null;
		attachment5CAttachmentName = (String)remedyParameters.get("attachment_5_attachmentName");
		attachment5CAttachmentData = remedyParameters.get("attachment_5_attachmentData") != null ?
				Base64.decodeBase64(((String)remedyParameters.get("attachment_5_attachmentData")).getBytes()) : null;
		foreignParentKey = (String)remedyParameters.get("Foreign_Parent_Key");
		
		CMNIntegrationCreateInBoundTicketWBService createService = new CMNIntegrationCreateInBoundTicketWBService();
		NewPort0PortType integrationCreate = createService.getNewPort0Soap();
		LOGGER.info("Field mapping value : ");
		LOGGER.info("vendorRefC : "+vendorRefC);
		LOGGER.info("customerTicketC : "+customerTicketC);
		LOGGER.info("workLogC : "+workLogC);
		LOGGER.info("shortDescription : "+shortDescription);
		LOGGER.info("submitter : "+submitter);
		LOGGER.info("assignedTo : "+assignedTo);
		LOGGER.info("phoneWorkC : "+phoneWorkC);
		LOGGER.info("priorityC : "+priorityC);
		LOGGER.info("summaryC : "+summaryC);
		LOGGER.info("status : "+status);
		LOGGER.info("categoryC : "+categoryC);
		LOGGER.info("typeC : "+typeC);
		LOGGER.info("description : "+description);
		LOGGER.info("ctsTicketC : "+ctsTicketC);
		LOGGER.info("pendingReasonC : "+pendingReasonC);
		LOGGER.info("ticketStatusC : "+ticketStatusC);
		LOGGER.info("assignedGroupC : "+assignedGroupC);
		LOGGER.info("assignedIndividualC : "+assignedIndividualC);
		LOGGER.info("itemC : "+itemC);
		LOGGER.info("integrationAttribute01 : "+integrationAttribute01);
		LOGGER.info("integrationAttribute02 : "+integrationAttribute02);
		LOGGER.info("integrationAttribute03 : "+integrationAttribute03);
		LOGGER.info("integrationAttribute04 : "+integrationAttribute04);
		LOGGER.info("integrationAttribute05 : "+integrationAttribute05);
		LOGGER.info("integrationAttribute06 : "+integrationAttribute06);
		LOGGER.info("integrationAttribute07 : "+integrationAttribute07);
		LOGGER.info("integrationAttribute08 : "+integrationAttribute08);
		LOGGER.info("rootCauseCategory : "+rootCauseCategory);
		LOGGER.info("resolution : "+resolution);
		LOGGER.info("securePatientInformationC : "+securePatientInformationC);
		LOGGER.info("additionalComments : "+additionalComments);
		LOGGER.info("foreignParentKey : "+foreignParentKey);
		LOGGER.info("attachment1CAttachmentName : "+attachment1CAttachmentName);
		
		String response = integrationCreate.newCreateOperation0(submitter, 
				assignedTo,
				status, 
				shortDescription,
				departmentC, 
				buildingC, 
				clientC, 
				assetTagC, 
				processed, 
				integrationAttribute08,
				integrationAttribute01,
				errorMessage,
				phoneTest,
				temp01,
				temp02,
				temp03,
				additionalComments,
				integrationAttribute07,
				integrationAttribute05,
				networkLogin,
				resolution,
				computerNameC, 
				rootCauseCategory,
				titleC, 
				phoneWorkC, 
				emailAddressC, 
				categoryC, 
				typeC, 
				itemC, 
				assignedGroupC,
				description,
				workLogC,
				assignedIndividualC, 
				priorityC, 
				pendingReasonC, 
				firstNameC, 
				lastNameC, 
				vendorsC, 
				attachment1CAttachmentName, 
				attachment1CAttachmentData, 
				attachment1CAttachmentOrigSize, 
				attachment2CAttachmentName, 
				attachment2CAttachmentData,
				 attachment2CAttachmentOrigSize, 
				attachment3CAttachmentName, 
				attachment3CAttachmentData, 
				attachment3CAttachmentOrigSize, 
				attachment4CAttachmentName, 
				attachment4CAttachmentData, 
				attachment4CAttachmentOrigSize, 
				attachment5CAttachmentName, 
				attachment5CAttachmentData, 
				attachment5CAttachmentOrigSize, 
				vendorRefC, 
				securePatientInformationC, 
				ctsTicketC, 
				patientAttachment1CAttachmentName, 
				patientAttachment1CAttachmentData, 
				patientAttachment1CAttachmentOrigSize, 
				patientAttachment2CAttachmentName, 
				patientAttachment2CAttachmentData, 
				patientAttachment2CAttachmentOrigSize, 
				patientAttachment3CAttachmentName, 
				patientAttachment3CAttachmentData, 
				patientAttachment3CAttachmentOrigSize, 
				patientAttachment4CAttachmentName, 
				patientAttachment4CAttachmentData, 
				patientAttachment4CAttachmentOrigSize, 
				patientAttachment5CAttachmentName, 
				patientAttachment5CAttachmentData, 
				patientAttachment5CAttachmentOrigSize, 
				customerTicketC, 
				integrationAttribute02,
				integrationAttribute03,
				foreignParentKey,
				integrationAttribute04,
				integrationAttribute06,
				integrationCustomerName,
				ticketSubmitterC, 
				ticketStatusC, 
				summaryC,
				floorC, 
				suiteC, 
				officeC, 
				phoneExtC, 
				pagerNumericC, 
				pagerPinC,
				source,
				parameters);
		LOGGER.info("Response : "+response);
		Date endTime = new Date();
		LOGGER.info("Remedy Update Service call ends :"+Utilities.getCurrentDateTime(endTime));
		LOGGER.info("Remedy Update Service call duration :"+Utilities.getTimeDifference(startTime, endTime));
		return response;

	}
	
	/*public String createTicket(Map<String, Object> remedyParameters) {
		//LOGGER.setLevel(Level.ALL);
		Date startTime = new Date();
		LOGGER.info("Remedy Update Service call starts :"+Utilities.getCurrentDateTime(startTime));
		
		vendorRefC = (String)remedyParameters.get("Vendor_Ref___c");
		customerTicketC = (String)remedyParameters.get("Vendor_Ref___c");
		workLogC = (String)remedyParameters.get("Work_Log__c");
		ticketStatusC = remedyParameters.get("Ticket_Status__c") != null ? TicketStatusType.fromValue((String)remedyParameters.get("Ticket_Status__c")) : null;
		//shortDescription = (String)remedyParameters.get("Short_Description");
		shortDescription = "NA";
		submitter = "NA";
		//ticketCreateDateC = (String)remedyParameters.get("Ticket_Create_Date__c");
		assignedTo = (String)remedyParameters.get("Assigned_To");
		firstNameC = (String)remedyParameters.get("First_Name__c");
		lastNameC = (String)remedyParameters.get("Last_Name__c");
		phoneWorkC = (String)remedyParameters.get("Phone-Work__c");
		pagerPinC = (String)remedyParameters.get("Pager_Pin__c");
		clientC = (String)remedyParameters.get("Client__c");
		buildingC = (String)remedyParameters.get("Building__c");
		departmentC = (String)remedyParameters.get("Department__c");
		summaryC = (String)remedyParameters.get("Summary__c");
		status = StatusType.fromValue("New");
		categoryC = (String)remedyParameters.get("Category__c");
		typeC = (String)remedyParameters.get("Type__c");
		itemC=(String)remedyParameters.get("Item__c");
		assignedGroupC = (String)remedyParameters.get("Assigned_Group__c");
		priorityC =  remedyParameters.get("Priority__c") != null ? PriorityType.fromValue((String)remedyParameters.get("Priority__c")) : null;
		assignedIndividualC = (String)remedyParameters.get("Assigned_Individual__c");
		assetTagC = (String)remedyParameters.get("Asset_Tag__c");
		//businessOrganizationC = (String)remedyParameters.get("Business_Organization__c");
		//dateTimeAssignedC = (String)remedyParameters.get("Date_Time_Assigned__c");
		vendorsC = (String)remedyParameters.get("Vendors__c");
		ctsTicketC = (String)remedyParameters.get("CTS_Ticket__c");
		description = (String)remedyParameters.get("Description");
		pendingReasonC = (String)remedyParameters.get("Pending_Reason");
		integrationAttribute01 = (String)remedyParameters.get("Integration_Attribute_01");
		integrationAttribute02 = (String)remedyParameters.get("Integration_Attribute_02");
		integrationAttribute03 = (String)remedyParameters.get("Integration_Attribute_03");
		integrationAttribute04 = (String)remedyParameters.get("Integration_Attribute_04");
		integrationAttribute05 = (String)remedyParameters.get("Integration_Attribute_05");
		integrationAttribute06 = (String)remedyParameters.get("Integration_Attribute_06");
		integrationAttribute07 = (String)remedyParameters.get("Integration_Attribute_07");
		integrationAttribute08 = (String)remedyParameters.get("Integration_Attribute_08");
		rootCauseCategory = (String)remedyParameters.get("Root_Cause_Category");
		resolution = (String)remedyParameters.get("Resolution");
		securePatientInformationC = (String)remedyParameters.get("Secure_Patient_Information");
		networkLogin = (String)remedyParameters.get("Network_Login");
		attachment1CAttachmentName = (String)remedyParameters.get("attachment_1_attachmentName");
		attachment1CAttachmentData = remedyParameters.get("attachment_1_attachmentData") != null ?
				Base64.decodeBase64(((String)remedyParameters.get("attachment_1_attachmentData")).getBytes()) : null;
		attachment2CAttachmentName = (String)remedyParameters.get("attachment_2_attachmentName");
		attachment2CAttachmentData = remedyParameters.get("attachment_2_attachmentData") != null ?
				Base64.decodeBase64(((String)remedyParameters.get("attachment_2_attachmentData")).getBytes()) : null;
		attachment3CAttachmentName = (String)remedyParameters.get("attachment_3_attachmentName");
		attachment3CAttachmentData = remedyParameters.get("attachment_3_attachmentData") != null ?
				Base64.decodeBase64(((String)remedyParameters.get("attachment_3_attachmentData")).getBytes()) : null;
		attachment4CAttachmentName = (String)remedyParameters.get("attachment_4_attachmentName");
		attachment4CAttachmentData = remedyParameters.get("attachment_4_attachmentData") != null ?
				Base64.decodeBase64(((String)remedyParameters.get("attachment_4_attachmentData")).getBytes()) : null;
		attachment5CAttachmentName = (String)remedyParameters.get("attachment_5_attachmentName");
		attachment5CAttachmentData = remedyParameters.get("attachment_5_attachmentData") != null ?
				Base64.decodeBase64(((String)remedyParameters.get("attachment_5_attachmentData")).getBytes()) : null;
		foreignParentKey = (String)remedyParameters.get("Foreign_Parent_Key");
		CMNIntegrationCreateInBoundNewTicketWBService createService = new CMNIntegrationCreateInBoundNewTicketWBService();
		NewTicketPort0PortType integrationCreate = createService.getNewTicketPort0Soap();
		LOGGER.info("Field mapping value : ");
		LOGGER.info("vendorRefC : "+vendorRefC);
		LOGGER.info("customerTicketC : "+customerTicketC);
		LOGGER.info("workLogC : "+workLogC);
		LOGGER.info("shortDescription : "+shortDescription);
		LOGGER.info("submitter : "+submitter);
		LOGGER.info("assignedTo : "+assignedTo);
		LOGGER.info("phoneWorkC : "+phoneWorkC);
		LOGGER.info("priorityC : "+priorityC);
		LOGGER.info("summaryC : "+summaryC);
		LOGGER.info("status : "+status);
		LOGGER.info("categoryC : "+categoryC);
		LOGGER.info("typeC : "+typeC);
		LOGGER.info("description : "+description);
		LOGGER.info("ctsTicketC : "+ctsTicketC);
		LOGGER.info("pendingReasonC : "+pendingReasonC);
		LOGGER.info("ticketStatusC : "+ticketStatusC);
		LOGGER.info("assignedGroupC : "+assignedGroupC);
		LOGGER.info("assignedIndividualC : "+assignedIndividualC);
		LOGGER.info("itemC : "+itemC);
		LOGGER.info("integrationAttribute01 : "+integrationAttribute01);
		LOGGER.info("integrationAttribute02 : "+integrationAttribute02);
		LOGGER.info("integrationAttribute03 : "+integrationAttribute03);
		LOGGER.info("integrationAttribute04 : "+integrationAttribute04);
		LOGGER.info("integrationAttribute05 : "+integrationAttribute05);
		LOGGER.info("integrationAttribute06 : "+integrationAttribute06);
		LOGGER.info("integrationAttribute07 : "+integrationAttribute07);
		LOGGER.info("integrationAttribute08 : "+integrationAttribute08);
		LOGGER.info("rootCauseCategory : "+rootCauseCategory);
		LOGGER.info("resolution : "+resolution);
		LOGGER.info("securePatientInformationC : "+securePatientInformationC);
		
		String response = integrationCreate.newTicketCreateOperation0(submitter, 
				assignedTo,
				status, 
				shortDescription,
				departmentC, 
				buildingC, 
				clientC, 
				assetTagC, 
				processed, 
				integrationAttribute08,
				integrationAttribute01,
				errorMessage,
				phoneTest,
				temp01,
				temp02,
				temp03,
				integrationAttribute07,
				integrationAttribute05,
				networkLogin,
				resolution,
				computerNameC, 
				rootCauseCategory,
				titleC, 
				phoneWorkC, 
				emailAddressC, 
				categoryC, 
				typeC, 
				itemC, 
				assignedGroupC,
				description,
				workLogC,
				assignedIndividualC, 
				priorityC, 
				pendingReasonC, 
				firstNameC, 
				lastNameC, 
				vendorsC, 
				attachment1CAttachmentName, 
				attachment1CAttachmentData, 
				attachment1CAttachmentOrigSize, 
				attachment2CAttachmentName, 
				attachment2CAttachmentData,
				 attachment2CAttachmentOrigSize, 
				attachment3CAttachmentName, 
				attachment3CAttachmentData, 
				attachment3CAttachmentOrigSize, 
				attachment4CAttachmentName, 
				attachment4CAttachmentData, 
				attachment4CAttachmentOrigSize, 
				attachment5CAttachmentName, 
				attachment5CAttachmentData, 
				attachment5CAttachmentOrigSize, 
				vendorRefC, 
				securePatientInformationC, 
				ctsTicketC, 
				patientAttachment1CAttachmentName, 
				patientAttachment1CAttachmentData, 
				patientAttachment1CAttachmentOrigSize, 
				patientAttachment2CAttachmentName, 
				patientAttachment2CAttachmentData, 
				patientAttachment2CAttachmentOrigSize, 
				patientAttachment3CAttachmentName, 
				patientAttachment3CAttachmentData, 
				patientAttachment3CAttachmentOrigSize, 
				patientAttachment4CAttachmentName, 
				patientAttachment4CAttachmentData, 
				patientAttachment4CAttachmentOrigSize, 
				patientAttachment5CAttachmentName, 
				patientAttachment5CAttachmentData, 
				patientAttachment5CAttachmentOrigSize, 
				customerTicketC, 
				integrationAttribute02,
				integrationAttribute03,
				foreignParentKey,
				integrationAttribute04,
				integrationAttribute06,
				integrationCustomerName,
				ticketSubmitterC, 
				ticketStatusC, 
				summaryC,
				floorC, 
				suiteC, 
				officeC, 
				phoneExtC, 
				pagerNumericC, 
				pagerPinC,
				parameters);
		LOGGER.info("Response : "+response);
		Date endTime = new Date();
		LOGGER.info("Remedy Update Service call ends :"+Utilities.getCurrentDateTime(endTime));
		LOGGER.info("Remedy Update Service call duration :"+Utilities.getTimeDifference(startTime, endTime));
		return response;

	}*/
}
