package com.caretech.mediator.model;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlValue;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamConverter;
import com.thoughtworks.xstream.converters.extended.ToAttributedValueConverter;

/**
 * @author gopinathn
 *
 */
@JsonInclude(Include.NON_NULL)
@JsonTypeName(value="EntryItem")
@XmlRootElement(name="entryItem")
@XStreamAlias("EntryItem")
@XStreamConverter(value = ToAttributedValueConverter.class, strings = { "value" })
public class EntryItem {
	
	@XStreamAsAttribute
	private String ID;
	
	@XStreamAsAttribute
	private String Type;
	
	private String value;
	
	private ComplexItem ComplexItem;

	@JsonProperty
	@XmlAttribute
	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	@JsonProperty
	@XmlValue
	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}

	public ComplexItem getComplexItem() {
		return ComplexItem;
	}

	public void setComplexItem(ComplexItem complexItem) {
		ComplexItem = complexItem;
	}
	
	
}
