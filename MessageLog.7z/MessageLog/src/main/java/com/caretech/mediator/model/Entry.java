package com.caretech.mediator.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

/**
 * @author gopinathn
 *
 */
@JsonInclude(Include.NON_NULL)
@JsonTypeName(value="Entry")
@XmlRootElement(name="entry")
@XStreamAlias("Entry")
public class Entry {
	
	@XStreamAsAttribute
	private String ID;
	
	@XStreamAsAttribute
	private String Structure;
	
	@XStreamImplicit
	private List<EntryItem> EntryItem = new ArrayList<EntryItem>();

	@JsonProperty
	@XmlAttribute
	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	@JsonProperty
	@XmlElement(name="entryItem")
	public List<EntryItem> getEntryItem() {
		return EntryItem;
	}

	public void setEntryItem(List<EntryItem> entryItem) {
		EntryItem = entryItem;
	}

	@JsonProperty
	@XmlAttribute
	public String getStructure() {
		return Structure;
	}

	public void setStructure(String structure) {
		Structure = structure;
	}
	
	

}
