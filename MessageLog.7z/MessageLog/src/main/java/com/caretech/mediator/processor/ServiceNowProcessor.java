package com.caretech.mediator.processor;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.xml.ws.http.HTTPException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpException;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

import com.caretech.mediator.datamapping.dto.TargetApplicationDTO;
import com.caretech.mediator.datamapping.processor.JSONProcessor;
import com.caretech.mediator.utils.Utilities;

/**
 * @author gopinathn
 *
 */
public class ServiceNowProcessor {
	
	private static JSONProcessor jSONProcessor =  new JSONProcessor() ;

	private Logger LOGGER = Logger.getLogger(ServiceNowProcessor.class.getName());

	/**
	 * Helper method to call the Service Now API for creating a new incident.
	 * 
	 * @param incidentData
	 *            Request data which contains the incident details.
	 * @param targetApplication
	 *            Target application URL and credential details
	 *            <code>TargetApplicationDTO</code>.
	 * @return
	 * @throws HTTPException
	 * @throws IOException
	 */
	public String processServiceNowPostRequest(String incidentData, TargetApplicationDTO targetApplication)
			throws HTTPException, IOException {
		Date startTime = new Date();
		LOGGER.info("Service Now API call starts, URL-> " + targetApplication.getUrl() +" : "+Utilities.getCurrentDateTime(startTime));

		String responseData = "";

		CredentialsProvider credentials = new BasicCredentialsProvider();

		credentials.setCredentials(new AuthScope(new HttpHost(targetApplication.getHost())),
				new UsernamePasswordCredentials(targetApplication.getUserName(), targetApplication.getPassword()));

		CloseableHttpClient httpclient = HttpClients.custom().setDefaultCredentialsProvider(credentials).build();

		try {

			HttpPost httpPost = new HttpPost(targetApplication.getUrl());
			httpPost.setHeader("Accept", targetApplication.getContentType());
			httpPost.setHeader("Content-Type", targetApplication.getContentType());
			HttpEntity entity = new ByteArrayEntity(incidentData.getBytes("utf-8"));
			httpPost.setEntity(entity);
			CloseableHttpResponse response = httpclient.execute(httpPost);
			try {
				responseData = EntityUtils.toString(response.getEntity());
			} finally {
				response.close();
			}
		} finally {
			httpclient.close();
		}
		Date endTime = new Date();
		LOGGER.info("Service Now API call ends, response-> " + responseData +" : "+Utilities.getCurrentDateTime(endTime));
		LOGGER.info("Service Now API call duration :"+Utilities.getTimeDifference(startTime, endTime));
		return responseData;
	}

	public String processServiceNowPutRequest(String incidentData, TargetApplicationDTO targetApplication, String incidentNumber) throws HttpException, IOException {
		Date startTime = new Date();
		LOGGER.info("Service Now API call starts, URL-> " + targetApplication.getUrl() +" : "+Utilities.getCurrentDateTime(startTime));

		String sysId = getSysid(targetApplication, incidentNumber);
		
		String responseData = null;
		
		if(sysId != null && sysId.length() > 0) {

			CredentialsProvider credentials = new BasicCredentialsProvider();
	
			credentials.setCredentials(new AuthScope(new HttpHost(targetApplication.getHost())),
					new UsernamePasswordCredentials(targetApplication.getUserName(), targetApplication.getPassword()));
	
			CloseableHttpClient httpclient = HttpClients.custom().setDefaultCredentialsProvider(credentials).build();
	
			try {
				HttpPut httpPut = new HttpPut(targetApplication.getUrl() + "/" + sysId+"?sysparm_input_display_value=True");
				httpPut.setHeader("Accept", "application/json");
				httpPut.setHeader("Content-Type", "application/json");
				HttpEntity entity = new ByteArrayEntity(incidentData.getBytes("utf-8"));			
				httpPut.setEntity(entity);
	
				CloseableHttpResponse response = httpclient.execute(httpPut);
				try {
					responseData = EntityUtils.toString(response.getEntity());
				} finally {
					response.close();
				}
			} finally {
				httpclient.close();
			}
		}
		Date endTime = new Date();
		LOGGER.info("Service Now API call ends, response-> " + responseData +" : "+Utilities.getCurrentDateTime(endTime));
		LOGGER.info("Service Now API call duration :"+Utilities.getTimeDifference(startTime, endTime));
		return responseData;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public String getSysid(TargetApplicationDTO targetApplication, String incidentNumber) throws HttpHostConnectException, IOException {
		System.out.println("incident number-----------------------"+incidentNumber);
		Date startTime = new Date();
		LOGGER.info("Service Now API call starts, URL-> " + targetApplication.getUrl() +" : "+Utilities.getCurrentDateTime(startTime));

		String responseData = "";

		CredentialsProvider credentials = new BasicCredentialsProvider();

		credentials.setCredentials(new AuthScope(new HttpHost(targetApplication.getHost())),
				new UsernamePasswordCredentials(targetApplication.getUserName(), targetApplication.getPassword()));

		CloseableHttpClient httpclient = HttpClients.custom().setDefaultCredentialsProvider(credentials).build();
		System.out.println("incidentURL------------------"+targetApplication.getIncidentUrl());
		try {
			HttpGet httpGet = new HttpGet(targetApplication.getIncidentUrl() + "?sysparm_query=number=" + incidentNumber + "&sysparm_fields=sys_id");
			httpGet.setHeader("Accept", "application/json");
			httpGet.setHeader("Content-Type", "application/json");		

			CloseableHttpResponse response = httpclient.execute(httpGet);
			try {
				responseData = EntityUtils.toString(response.getEntity());
				Map<String, Object> result = jSONProcessor.getInputJsonAsMap(responseData);
				System.out.println("result++++++++++++++++++++++++++++++"+result);
				if(result.containsKey("status") || ((List)result.get("result")).size() <= 0) {
					responseData = null;
				} else {
					responseData = ((Map<String, String>)((List)result.get("result")).get(0)).get("sys_id");
				}
			} finally {
				response.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			httpclient.close();
		}
		Date endTime = new Date();
		LOGGER.info("Service Now API call ends, response-> " + responseData +" : "+Utilities.getCurrentDateTime(endTime));
		LOGGER.info("Service Now API call duration :"+Utilities.getTimeDifference(startTime, endTime));
		return responseData;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public String getResolvedBy(TargetApplicationDTO targetApplication, String incidentNumber) throws HttpHostConnectException, IOException {
		System.out.println("incident number-----------------------"+incidentNumber);
		Date startTime = new Date();
		LOGGER.info("Service Now API call starts, URL-> " + targetApplication.getUrl() +" : "+Utilities.getCurrentDateTime(startTime));

		String responseData = "";

		CredentialsProvider credentials = new BasicCredentialsProvider();

		credentials.setCredentials(new AuthScope(new HttpHost(targetApplication.getHost())),
				new UsernamePasswordCredentials(targetApplication.getUserName(), targetApplication.getPassword()));

		CloseableHttpClient httpclient = HttpClients.custom().setDefaultCredentialsProvider(credentials).build();
		System.out.println("incidentURL------------------"+targetApplication.getIncidentUrl());
		try {
			HttpGet httpGet = new HttpGet(targetApplication.getIncidentUrl() + "?sysparm_query=number=" + incidentNumber + "&sysparm_fields=resolved_by");
			httpGet.setHeader("Accept", "application/json");
			httpGet.setHeader("Content-Type", "application/json");		

			CloseableHttpResponse response = httpclient.execute(httpGet);
			try {
				responseData = EntityUtils.toString(response.getEntity());
				Map<String, Object> result = jSONProcessor.getInputJsonAsMap(responseData);
				System.out.println("result++++++++++++++++++++++++++++++"+result);
				if(result.containsKey("status") || ((List)result.get("result")).size() <= 0) {
					responseData = null;
				} else {
					responseData = ((Map<String, String>)((List)result.get("result")).get(0)).get("resolved_by");
				}
			} finally {
				response.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			httpclient.close();
		}
		Date endTime = new Date();
		LOGGER.info("Service Now API call ends, response-> " + responseData +" : "+Utilities.getCurrentDateTime(endTime));
		LOGGER.info("Service Now API call duration :"+Utilities.getTimeDifference(startTime, endTime));
		return responseData;
	}
	
	@SuppressWarnings({ "unchecked" })
	public List<Map<String, String>> getAttachmentList(TargetApplicationDTO targetApplication, String sysID) throws HttpHostConnectException, IOException {
		Date startTime = new Date();
		LOGGER.info("Service Now API call starts, URL-> " + targetApplication.getAttachmentUrl() +" : "+Utilities.getCurrentDateTime(startTime));
		List<Map<String, String>> attachmentList = null;
		String responseData = "";

		CredentialsProvider credentials = new BasicCredentialsProvider();

		credentials.setCredentials(new AuthScope(new HttpHost(targetApplication.getHost())),
				new UsernamePasswordCredentials(targetApplication.getUserName(), targetApplication.getPassword()));

		CloseableHttpClient httpclient = HttpClients.custom().setDefaultCredentialsProvider(credentials).build();

		try {
			HttpGet httpGet = new HttpGet(targetApplication.getAttachmentUrl() + "?sysparm_suppress_pagination_header=True&sysparm_limit=20&sysparm_query=table_sys_id=" + sysID);
			httpGet.setHeader("Accept", "application/json");
			httpGet.setHeader("Content-Type", "application/json");		

			CloseableHttpResponse response = httpclient.execute(httpGet);
			try {
				responseData = EntityUtils.toString(response.getEntity());
				Map<String, Object> result = jSONProcessor.getInputJsonAsMap(responseData);
				if(result != null) {
					attachmentList = (List<Map<String, String>>)result.get("result");
				}
			} finally {
				response.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			httpclient.close();
		}
		Date endTime = new Date();
		LOGGER.info("Service Now API call ends, response-> " + attachmentList.size() +" : "+Utilities.getCurrentDateTime(endTime));
		LOGGER.info("Service Now API call duration :"+Utilities.getTimeDifference(startTime, endTime));
		return attachmentList;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public String getParentTicketNumber(TargetApplicationDTO targetApplication, String incidentNumber) throws HttpHostConnectException, IOException {
		Date startTime = new Date();
		LOGGER.info("Service Now API call starts, URL-> " + targetApplication.getUrl() +" : "+Utilities.getCurrentDateTime(startTime));

		String responseData = "";

		CredentialsProvider credentials = new BasicCredentialsProvider();

		credentials.setCredentials(new AuthScope(new HttpHost(targetApplication.getHost())),
				new UsernamePasswordCredentials(targetApplication.getUserName(), targetApplication.getPassword()));

		CloseableHttpClient httpclient = HttpClients.custom().setDefaultCredentialsProvider(credentials).build();

		try {
			HttpGet httpGet = new HttpGet(targetApplication.getIncidentUrl() + "?sysparm_query=u_external_ticket_id=" + incidentNumber + "&sysparm_fields=sys_id");
			httpGet.setHeader("Accept", "application/json");
			httpGet.setHeader("Content-Type", "application/json");		

			CloseableHttpResponse response = httpclient.execute(httpGet);
			try {
				responseData = EntityUtils.toString(response.getEntity());
				Map<String, Object> result = jSONProcessor.getInputJsonAsMap(responseData);
				if(result.containsKey("status")) {
					responseData = null;
				} else {
					responseData = ((Map<String, String>)((List)result.get("result")).get(0)).get("sys_id");
				}
			} finally {
				response.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			httpclient.close();
		}
		Date endTime = new Date();
		LOGGER.info("Service Now API call ends, response-> " + responseData +" : "+Utilities.getCurrentDateTime(endTime));
		LOGGER.info("Service Now API call duration :"+Utilities.getTimeDifference(startTime, endTime));
		return responseData;
	}

}
