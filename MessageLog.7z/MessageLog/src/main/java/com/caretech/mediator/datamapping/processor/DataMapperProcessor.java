/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.caretech.mediator.datamapping.processor;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;

import com.caretech.mediator.constant.Constants;
import com.caretech.mediator.datamapping.dto.DataMappingDTO;
import com.caretech.mediator.datamapping.dto.FieldSourceDTO;
import com.caretech.mediator.datamapping.dto.FieldTargetDTO;
import com.caretech.mediator.datamapping.dto.SourceObjectDTO;
import com.caretech.mediator.datamapping.dto.TargetApplicationDTO;
import com.caretech.mediator.datamapping.dto.TargetObjectDTO;
import com.caretech.mediator.datamapping.parser.DataMappingXMLParser;
import com.caretech.mediator.exception.MandatoryParameterException;

/**
 * @author gopinathn
 *
 */
public class DataMapperProcessor {
	
	private Logger LOGGER = Logger.getLogger(DataMapperProcessor.class.getName());
	
	
	private static DataMappingXMLParser xmlParser = new DataMappingXMLParser();

	
	/**
	 * Helper method for converting the request parameters using the data mapping xml.
	 * @param parameters Request parameters as map.
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public TargetApplicationDTO processDataMapperService(Map<String, Object> parameters) throws MandatoryParameterException, Exception {
		String serviceName = null;
		Map<String, Object> reqParameters = null;
		Map<String, Object> requestMap = (Map<String, Object>) parameters.get("request");
		if(requestMap != null) {
			serviceName = (String) requestMap.get(Constants.SERVICE_NAME);
			reqParameters = (Map<String, Object>) requestMap.get("parameters");
		} else {
			serviceName = (String) parameters.get("ServiceName");
			reqParameters = parameters;
		}
		String dataMappingFilePath = System.getenv("CATALINA_HOME") +File.separator+ "conf" +File.separator+"DataMapping"+File.separator+serviceName+".xml";
		LOGGER.info("datamappoingfilepath"+dataMappingFilePath);
		
		
		DataMappingDTO dataMappingDTO = null;
		if (dataMappingFilePath != null) {
			Map<String, Object> requestValues = new HashMap<String, Object>();
			
			dataMappingDTO = getDataMapping(dataMappingFilePath);
			
			TargetApplicationDTO targetApplication = dataMappingDTO.getTargetApplication();
			if (dataMappingDTO != null) {
				//Commented by Viswanathan for removing Entry Tag
				/*if (targetApplication.getConvertor() != null && targetApplication.getConvertor().equals("EntryToMap")) {
					requestValues = requestConverter.convertEntryToMap(getEntryItems(reqParameters));
				} else {
					requestValues = reqParameters;
				}*/
				
				requestValues = reqParameters;
				Map<String, String> fieldSources = getFieldSources(dataMappingDTO);
				ArrayList<String> mandatoryParamList = getMandatoryParams(dataMappingDTO);
				String missingParameters = validateMandatoryParams(requestValues, mandatoryParamList);
				if(missingParameters != null){
					throw new MandatoryParameterException(missingParameters);
				}
				if (fieldSources != null && !fieldSources.isEmpty()) {
			
					Map<String, Object> mappedParams = getMappedTargetValues(requestValues, fieldSources, targetApplication.getConvertor());
					for (TargetObjectDTO targetObjectDTO : dataMappingDTO.getTargetObjects()) {
						for (FieldTargetDTO fieldTargetDTO : targetObjectDTO.getTargetFields()) {
							String sourceField = fieldTargetDTO.getSourceField();
							if((sourceField == null||sourceField =="") && fieldTargetDTO.getDefaultValue() != null){
								mappedParams.put(fieldTargetDTO.getTargetFieldId(), fieldTargetDTO.getDefaultValue());
								System.out.println("mapped params**********"+mappedParams);
							}
							if(fieldTargetDTO.getSize() != null && fieldTargetDTO.getTargetFieldId() !=null) {
								String fieldValue = (String) mappedParams.get(fieldTargetDTO.getTargetFieldId());
								if(fieldValue!=null && fieldValue.length()>fieldTargetDTO.getSize().intValue()){
									String truncatedValue = fieldValue.substring(0, fieldTargetDTO.getSize().intValue());
									mappedParams.put(fieldTargetDTO.getTargetFieldId(),truncatedValue);
								}
							}
							if(sourceField != null && sourceField.contains(",")){
					
								String[] sourceFieldArray = sourceField.split(",");
								String sourceFieldValue = "";
								for(String field : sourceFieldArray){
									if(requestValues.get(field) != null)
									if(sourceFieldValue != null && sourceFieldValue.length() > 0)
										sourceFieldValue = sourceFieldValue + " " + requestValues.get(field);
									else
										sourceFieldValue = (String) requestValues.get(field);
								}
								
								if(sourceFieldValue != null && sourceFieldValue.length() > 0)
								mappedParams.put(fieldTargetDTO.getTargetFieldId(), sourceFieldValue);
							}
						}
					}
				
					targetApplication.setRequestParam(mappedParams);
				
					return targetApplication;
				} 
			}
				
		} 
		return null;
	}

	private String validateMandatoryParams(Map<String, Object> requestValues, ArrayList<String> mandatoryParamList) {
		List<String> params = new ArrayList<String>();
		for(String mandatoryParam : mandatoryParamList)
			if(!requestValues.containsKey(mandatoryParam))
				params.add(mandatoryParam);
		if (params.size() > 0) {
			return params.toString().replace("[", "").replace("]", "");
		}else{
			return null;
		}
	}

	private ArrayList<String> getMandatoryParams(DataMappingDTO dataMappingDTO) {
		ArrayList<String> fieldSources = new ArrayList<String>();
		for (SourceObjectDTO sourceObjectDTO : dataMappingDTO.getSourceObjects()) {
			for (FieldSourceDTO fieldSourceDTO : sourceObjectDTO.getSourceFields()) {
				if(fieldSourceDTO.getSourceFieldId() != null && "Y".equals(fieldSourceDTO.getMandatory()))
				fieldSources.add(fieldSourceDTO.getSourceFieldId());
			}
		}
		return fieldSources;
	}

	/**
	 * @param requestMap
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "unused" })
	private List<Map<String, Object>> getEntryItems(Map<String, Object> requestMap) {
		return (List<Map<String, Object>>) ((Map<String, Object>) requestMap.get("Entry")).get("EntryItem");
	}

	/**
	 * @param dataMappingXMLPath
	 * @return
	 * @throws Exception
	 */
	private DataMappingDTO getDataMapping(String dataMappingXMLPath) throws Exception {
		return xmlParser.getDataMapping(dataMappingXMLPath);
	}

	/**
	 * Helper method to form a Map of source field and its corresponding target field.
	 * @param dataMappingDTO <code>DataMappingDTO</code>.
	 * @return <code>Map<String, String></code>.
	 * @throws Exception
	 */
	private Map<String, String> getFieldSources(DataMappingDTO dataMappingDTO) throws Exception {
		Map<String, String> fieldSources = new HashMap<String, String>();
		for (TargetObjectDTO targetObjectDTO : dataMappingDTO.getTargetObjects()) {
			for (FieldTargetDTO fieldTargetDTO : targetObjectDTO.getTargetFields()) {
				if(fieldTargetDTO.getSourceField() != null)
				fieldSources.put(fieldTargetDTO.getSourceField(), fieldTargetDTO.getTargetFieldId());
			}
		}
		return fieldSources;
	}

	/**
     * Helper method to map the value of source field to the target field.
     * @param receivedInput Holds the request with field name and value as map.
     * @param fieldSources Holds the map of source field and corresponding target field name.
	 * @param convertor 
     * @return Map of target field name and field value.
     * @throws Exception
     */
	private Map<String, Object> getMappedTargetValues(Map<String, Object> receivedInput,
			Map<String, String> fieldSources, String convertor) throws Exception {
		Map<String, Object> mappedTargetValues = new HashMap<String, Object>();
        Iterator<Entry<String, Object>> it = receivedInput.entrySet().iterator();
        while (it.hasNext()) {
	        Entry<String, Object> pair = it.next();
	        if(fieldSources.get(pair.getKey()) != null && convertor.equals("EntryToMap")){
	        	mappedTargetValues.put(fieldSources.get(pair.getKey()), pair.getValue());}
	        else if(fieldSources.get(pair.getKey()) != null && pair.getValue() != null && pair.getValue() != "")
	        	mappedTargetValues.put(fieldSources.get(pair.getKey()), pair.getValue());
        }
		return mappedTargetValues;
	}
}
