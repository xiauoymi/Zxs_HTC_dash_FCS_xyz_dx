package com.caretech.mediator.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@JsonInclude(Include.NON_NULL)
@JsonTypeName(value="Result")
@XmlRootElement(name="Result")
@XStreamAlias("Result")
public class Result {
	
	@XStreamAsAttribute
	private Entry Entry;
	
	@XStreamAsAttribute
	private EntryList EntryList;

	@JsonProperty
	@XmlElement
	public EntryList getEntryList() {
		return EntryList;
	}

	public void setEntryList(EntryList entryList) {
		EntryList = entryList;
	}

	@JsonProperty
	@XmlElement
	public Entry getEntry() {
		return Entry;
	}

	public void setEntry(Entry entry) {
		Entry = entry;
	}

}
