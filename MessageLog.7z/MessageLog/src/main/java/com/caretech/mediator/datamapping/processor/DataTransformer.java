package com.caretech.mediator.datamapping.processor;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.http.conn.HttpHostConnectException;

import com.caretech.mediator.constant.Constants;
import com.caretech.mediator.datamapping.dto.TargetApplicationDTO;
import com.caretech.mediator.model.DataMapping;
import com.caretech.mediator.model.DataMapping.DataMapDefinition.Mapping;
import com.caretech.mediator.model.DataMapping.DataMapDefinition.Mapping.Entry;
import com.caretech.mediator.model.DataMapping.FieldMapping.Field;
import com.caretech.mediator.processor.ServiceNowProcessor;
import com.caretech.mediator.utils.Utilities;

public class DataTransformer implements DataTransformation {
	
	ServiceNowProcessor serviceNowConnector = new ServiceNowProcessor();

	private Map<String, String> fieldMap;

	private Map<String, Map<String, String>> dataMap;
	
	private List<String> pendingReasonList = new ArrayList<String>();
	
	{
		pendingReasonList.add("Awaiting Approval");
		pendingReasonList.add("Awaiting Development");
		pendingReasonList.add("Awaiting Parts");
		pendingReasonList.add("Awaiting Testing");
		pendingReasonList.add("Awaiting User");
		pendingReasonList.add("Awaiting Vendor");
		pendingReasonList.add("Awaiting Change");
		pendingReasonList.add("Awaiting Problem");
	}

	private void populateTransformData() {
		if (fieldMap == null || dataMap == null) {
			
			try {
				fieldMap = new HashMap<String, String>();
				dataMap = new HashMap<String, Map<String, String>>();
				String dataMappingFilePath = System.getenv("CATALINA_HOME") +File.separator+ "conf" +File.separator+"DataMapping"+File.separator+ Constants.DATA_TRANSFORMATION_XML +".xml";
				//Resource resource = new ClassPathResource(Constants.DATA_MAPPING_XML_FILE_PATH + Constants.DATA_TRANSFORMATION_XML + ".xml");
				//File file = resource.getFile();
				JAXBContext jaxbContext = JAXBContext.newInstance(DataMapping.class);
				Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
				DataMapping dataMapping = (DataMapping) unmarshaller.unmarshal(new File(dataMappingFilePath));
				for (Mapping mapping : dataMapping.getDataMapDefinition().getMapping()) {
					Map<String, String> valuesMap = new HashMap<String, String>();
					for (Entry entry : mapping.getEntry()) {
						valuesMap.put(entry.getKey(), entry.getvalue());
					}
					dataMap.put(mapping.getId(), valuesMap);
				}
				for (Field field : dataMapping.getFieldMapping().getField()) {
					fieldMap.put(field.getId(), field.getMappingid());
				}
				System.out.println("fieldMapping~~~~~~~~~~~~~~"+fieldMap);
				System.out.println("DataMap~~~~~~~~~~~~~~"+dataMap);
			} catch (JAXBException e) {
				e.printStackTrace();
			}
		}
	}

	
	public void transformData(Map<String, Object> requestParameters) {
		populateTransformData();
		for (Map.Entry<String, Object> serviceNowParameter : requestParameters.entrySet()) {
			String field = fieldMap.get(serviceNowParameter.getKey());
			if(field != null && field.length() > 0) {
				System.out.println("dataMap*****************"+dataMap);
				System.out.println("field******************"+field);
				System.out.println("oldvalue******************"+serviceNowParameter.getValue());
				String value = dataMap.get(field).get(serviceNowParameter.getValue());
				System.out.println("value*******************"+value);
				if(value != null && value.length() > 0)
					serviceNowParameter.setValue(value);
			}
		}
	}

	public void transformInboundStatus(Map<String, Object> requestParameters) {
		String status = (String)requestParameters.get("Ticket_Status__c");
		if(status != null && pendingReasonList.contains(status)) {
			requestParameters.put("Ticket_Status__c", "Pending");
			requestParameters.put("Pending_Reason", status);
		}
		
	}
	
	public void transformInboundEmailTicket(Map<String, Object> requestParameters) {
		String category = (String)requestParameters.get("Category__c");
		String subCategory = (String)requestParameters.get("Item__c");
		if(category != null && Constants.CATEGORY_CLINICAL_SOFTWARE.equals(category) && 
				isNull(subCategory)) {
			requestParameters.put("Item__c", "Account");
			//requestParameters.put("Integration_Attribute_01", "Abacus");
		} 
		
	}
	
	private boolean isNull(String strData) {
		if ((strData != null) && (strData.trim().length() > 0)
				&& (!strData.trim().equalsIgnoreCase("null"))) {
			return false;
		}

		return true;
	}


	public void transformOutboundStatus(Map<String, Object> requestParameters) {
		String pendingReason = (String)requestParameters.get("state_pending_reason");
		String isResolved = (String)requestParameters.get("is_resolved");
		if(pendingReason != null){
			requestParameters.put("state", pendingReason);
			requestParameters.put("incident_state", pendingReason);
		}
		String state = (String)requestParameters.get("state");
		if(state != null && Constants.STATE_CLOSED.equals(state))
			requestParameters.put("closed_at", Utilities.getCurrentSNOWDateTime());
		else if(state != null && Constants.STATE_RESOLVED.equals(state) && isResolved.equals("false")) {
			requestParameters.put("resolved_at", Utilities.getCurrentSNOWDateTime());
			requestParameters.put("resolved_by", "CareTech");
		}
		
	}
	
	public void transformOutboundAssignmentGroup(Map<String, Object> requestParameters) {
		String assignmentGroup = (String)requestParameters.get("assignment_group");
		if(assignmentGroup != null && Constants.ASSIGNMENT_GROUP_CARETECH_FIRST_LEVEL.equals(assignmentGroup))
			requestParameters.put("assigned_to", "CareTech");
		
	}

	
	public void transformOutboundParentTicket(Map<String, Object> requestParameters,
			TargetApplicationDTO targetApplication) throws HttpHostConnectException, IOException {
		
		String parentTicket = (String)requestParameters.get("parent_incident");
		if(parentTicket != null && !"".equals(parentTicket)) {
			String parentTicketNumber = serviceNowConnector.getSysid(targetApplication, parentTicket);
			System.out.println("parent ticket numbner))))))))))))))))))))))"+parentTicketNumber);
			if(parentTicketNumber != null)
			requestParameters.put("parent_incident", parentTicketNumber);
		}
		
	}

	
}
