package com.caretech.mediator.model;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamConverter;
import com.thoughtworks.xstream.converters.extended.ToAttributedValueConverter;

/**
 * @author gopinathn
 *
 */
@XStreamAlias("Message")
@XStreamConverter(value = ToAttributedValueConverter.class, strings = { "value" })
public class Message {
	
	
	@XStreamAsAttribute
	private String MessageNumber;
	
	@XStreamAsAttribute
	private String Type;
	
	@XStreamAsAttribute
	private String value;

	public String getMessageNumber() {
		return MessageNumber;
	}

	public void setMessageNumber(String messageNumber) {
		MessageNumber = messageNumber;
	}

	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	

}
