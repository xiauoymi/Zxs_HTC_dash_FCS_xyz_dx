package com.caretech.mediator.converter;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;


/**
 * @author gopinathn
 *
 */
public class RequestConverter {
	
	/**
	 * Helper method to convert List of Map Entry items to Map. 
	 * @param entryItems
	 * @return
	 */
	public Map<String, Object> convertEntryToMap(List<Map<String,Object>> entryItems){
		Map<String,Object> convEntryItem = new HashMap<String,Object>();
		for(Map<String, Object> entryItem : entryItems){
			convEntryItem.put((String) entryItem.get("@ID"), entryItem.get("$"));
		}
		
		return convEntryItem;
	}
	
	/**
	 * Helper method to convert Map to Entry string. 
	 * @param entryItems
	 * @return
	 */
	public String convertMapToEntry(Map<String,Object> entryItems){
		StringBuffer entryString = new StringBuffer();
		entryString.append("<Entry ID=\""+entryItems.get("1")+"\" >");
		Iterator<Entry<String, Object>> it = entryItems.entrySet().iterator();
        
        while (it.hasNext()) {
	        Entry<String, Object> pair = it.next();
	        if(!pair.getKey().equals("1"))
	        	entryString.append("<EntryItem ID=\""+pair.getKey()+"\" >"+pair.getValue()+"</EntryItem>");
        }
        entryString.append("</Entry>");
		return entryString.toString();
	}

}
