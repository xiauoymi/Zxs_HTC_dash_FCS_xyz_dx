package com.caretech.mediator.model;

import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

/**
 * @author gopinathn
 *
 */
@XStreamAlias("Messages")
public class Messages {
	
	@XStreamImplicit
	private List<Message> Message = new ArrayList<Message>();
	
	

}
