package com.caretech.mediator.model;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

/**
 * @author gopinathn
 *
 */
@JsonInclude(Include.NON_NULL)
@JsonTypeName(value="Response")
@XmlRootElement(name="Response")
@XStreamAlias("Response")
public class Response {
	
	@XStreamAsAttribute
	private String status;
	
	@XStreamAsAttribute
	private String errorCode;
	
	@XStreamAsAttribute
	private String tableName;
	
	@XStreamAsAttribute
	private String errorDesc;
	
	@SuppressWarnings("rawtypes")
	@XStreamAsAttribute
	private Output output;
	
	@XStreamAsAttribute
	private String RequestMethod;
	
	@XStreamAsAttribute
	private String Success;
	
	@XStreamAsAttribute
	private Result Result;
	
	@XStreamAsAttribute
	private Messages Messages;

	@JsonProperty
	@XmlAttribute
	public String getRequestMethod() {
		return RequestMethod;
	}

	public void setRequestMethod(String requestMethod) {
		RequestMethod = requestMethod;
	}

	@JsonProperty
	@XmlAttribute
	public String getSuccess() {
		return Success;
	}

	public void setSuccess(String success) {
		Success = success;
	}

	@JsonProperty
	@XmlElement
	public Result getResult() {
		return Result;
	}

	public void setResult(Result result) {
		Result = result;
	}

	@Override
	public String toString() {
		return "Response [status=" + status + ", errorCode=" + errorCode
				+ ", tableName=" + tableName + ", errorDesc=" + errorDesc
				+ ", output=" + output + ", RequestMethod=" + RequestMethod
				+ ", Success=" + Success + ", Result=" + Result + ", Messages="
				+ Messages + "]";
	}

	public Response() {
		super();
		
	}

	public Response(String requestMethod, String success, com.caretech.mediator.model.Result result) {
		super();
		RequestMethod = requestMethod;
		Success = success;
		Result = result;
	}

	@JsonProperty
	@XmlElement
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@JsonProperty
	@XmlElement
	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	@JsonProperty
	@XmlElement
	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	@SuppressWarnings("rawtypes")
	@JsonProperty
	@XmlElement
	public Output getOutput() {
		return output;
	}

	@SuppressWarnings("rawtypes")
	public void setOutput(Output output) {
		this.output = output;
	}

	@JsonProperty
	@XmlElement
	public Messages getMessages() {
		return Messages;
	}

	public void setMessages(Messages messages) {
		Messages = messages;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	
	

}
