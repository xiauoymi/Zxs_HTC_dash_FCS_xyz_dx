package com.caretech.mediator.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

/**
 * @author gopinathn
 *
 */
@XmlRootElement(name="parameter")
@XStreamAlias("parameter")
public class Parameter {
	
	@XStreamAsAttribute
	private Entry entry;

	@XmlElement
	public Entry getEntry() {
		return entry;
	}

	public void setEntry(Entry entry) {
		this.entry = entry;
	}
	
	

}
