/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.caretech.mediator.datamapping.parser;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;


import com.caretech.mediator.datamapping.dto.DataMappingDTO;
import com.caretech.mediator.datamapping.enums.InvalidDataMappingXMLErrCode;
import com.caretech.mediator.datamapping.exception.InvalidDataMappingXMLException;

public class DataMappingXMLParser {

	/**
	 * Helper method to parse the xml and return it as java object.
	 * @param dataMappingXml
	 * @return <code>DataMappingDTO</code>.
	 * @throws Exception
	 */
	public DataMappingDTO getDataMapping(String dataMappingXml) throws InvalidDataMappingXMLException {
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(DataMappingDTO.class);
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
			DataMappingDTO dataMappingDTO = (DataMappingDTO) unmarshaller.unmarshal(new File(dataMappingXml));
			return dataMappingDTO;
		} catch (JAXBException ex) {
			ex.printStackTrace();
			throw new InvalidDataMappingXMLException(InvalidDataMappingXMLErrCode.ERR_X1003.name(),
					InvalidDataMappingXMLErrCode.ERR_X1003.getErrorMessage());
		}
	}

}
