/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.caretech.mediator.datamapping.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author gopinathn
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "field")
public class FieldTargetDTO {
    
    @XmlAttribute(name = "id")
    private String targetFieldId;
    @XmlAttribute(name = "name")
    private String name;
    @XmlAttribute(name = "dataType")
    private String dataType;
    @XmlAttribute(name = "size")
    private Long size;
    @XmlAttribute(name = "mandatory")
    private String mandatory;
    @XmlAttribute(name = "sourceField")
    private String sourceField;
    @XmlAttribute(name = "defaultValue")
    private String defaultValue;

    /**
     * @return the targetFieldId
     */
    public String getTargetFieldId() {
        return targetFieldId;
    }

    /**
     * @param targetFieldId the targetFieldId to set
     */
    public void setTargetFieldId(String targetFieldId) {
        this.targetFieldId = targetFieldId;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the dataType
     */
    public String getDataType() {
        return dataType;
    }

    /**
     * @param dataType the dataType to set
     */
    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    /**
     * @return the size
     */
    public Long getSize() {
        return size;
    }

    /**
     * @param size the size to set
     */
    public void setSize(Long size) {
        this.size = size;
    }

    /**
     * @return the mandatory
     */
    public String getMandatory() {
        return mandatory;
    }

    /**
     * @param mandatory the mandatory to set
     */
    public void setMandatory(String mandatory) {
        this.mandatory = mandatory;
    }

	public String getSourceField() {
		return sourceField;
	}

	public void setSourceField(String sourceField) {
		this.sourceField = sourceField;
	}

	public String getDefaultValue() {
		return defaultValue;
	}

	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}

   
    
}
