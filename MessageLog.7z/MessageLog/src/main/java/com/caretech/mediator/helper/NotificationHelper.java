package com.caretech.mediator.helper;

import java.io.File;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

import com.caretech.mediator.datamapping.processor.JSONProcessor;
import com.caretech.mediator.model.Mailconfig;
import com.caretech.mediator.model.Mailconfig.Property;
import com.sun.mail.smtp.SMTPMessage;

public class NotificationHelper {
	
	JSONProcessor jSONProcessor;
	
	private Logger LOGGER = Logger.getLogger(NotificationHelper.class.getName());

	//@Autowired
	private VelocityEngine velocityEngine;

	private Mailconfig mailConfig = null;

	/**
	 * This method will compose and send the message
	 * @param errorCode
	 * @param errorDesc
	 * @throws Exception 
	 */
	public void sendNotification(HashMap<String, String> parameters){
		LOGGER.info("sendNotification method starts");
		try {			
			velocityEngine = new VelocityEngine();
			velocityEngine.addProperty(VelocityEngine.FILE_RESOURCE_LOADER_PATH, System.getenv("CATALINA_HOME") + "/conf/email");
			
			File file = new File(System.getenv("CATALINA_HOME") + "/conf/mailConfig.xml");
			JAXBContext jaxbContext = JAXBContext.newInstance(Mailconfig.class);
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
			mailConfig = (Mailconfig) unmarshaller.unmarshal(file);
			if(mailConfig.getIsEmailRequired().trim().equals("Y")){
				Properties props = System.getProperties();
				for (Property property : mailConfig.getProperty()) {
					props.put(property.getKey(), property.getvalue());
				}
				Session session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
					@Override
					protected PasswordAuthentication getPasswordAuthentication() {
						return new PasswordAuthentication(mailConfig.getUsername().trim(), mailConfig.getPassword().trim());
					}
				});
				SMTPMessage message = new SMTPMessage(session);
	
				message.setFrom(new InternetAddress(mailConfig.getMailfrom().trim()));
				LOGGER.info("From: " + mailConfig.getMailfrom().trim());
				for (com.caretech.mediator.model.Mailconfig.Templates.Template template : mailConfig.getTemplates().getTemplate()) {
					if (template.getErrorcode() != null && template.getErrorcode().length() > 0) {
						if (Arrays.asList(template.getErrorcode().split(",")).contains(parameters.get("errorCode"))) {
							for (String mailto : template.getMailtos().getMailto()) {
								message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(mailto.trim()));
								LOGGER.info("To: " + mailto.trim());
							}
							for (String mailcc : template.getMailccs().getMailcc()) {
								message.setRecipients(Message.RecipientType.CC, InternetAddress.parse(mailcc.trim()));
								LOGGER.info("To: " + mailcc.trim());
							}
							for (String mailbcc : template.getMailbccs().getMailbcc()) {
								message.setRecipients(Message.RecipientType.BCC, InternetAddress.parse(mailbcc.trim()));
								LOGGER.info("To: " + mailbcc.trim());
							}
							message.setSubject(template.getSubject());
							LOGGER.info("Subject: " + template.getSubject());
							message.setSentDate(new Date());					
							Template velocityTemplate = velocityEngine.getTemplate(template.getTemplatename());
							StringWriter templateWriter = new StringWriter();
							VelocityContext context = new VelocityContext();
							for(Entry<String, String> params : parameters.entrySet()) {
								if(params.getKey().equals("params")){
									String value = removeAttachmentData(params.getValue());
									context.put(params.getKey(), value);
								}else{
									context.put(params.getKey(), params.getValue());
								}
							}
							velocityTemplate.merge(context, templateWriter);
							//message.setText(stringWriter.toString());
							message.setContent(templateWriter.toString(), "text/html");
							LOGGER.info("Body: " + templateWriter.toString());
							Transport.send(message);
						}
					}
				}
			}
		} catch(MessagingException e) {
			LOGGER.error(e.getMessage(), e);
		} catch (JAXBException e) {
			LOGGER.error(e.getMessage(), e);
		}
		LOGGER.info("sendNotification method ends");
	}

	private String removeAttachmentData(String paramData){
		Map<String, Object> responseData;
		try {
			responseData = jSONProcessor.getInputJsonAsMap(paramData);
			responseData.remove("Attachment_1_attachmentData");
			paramData = jSONProcessor.getInputMapAsJson(responseData);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return paramData;
	}
}