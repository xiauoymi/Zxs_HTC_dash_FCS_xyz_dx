/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.caretech.mediator.datamapping.enums;

/**
 *
 * @author yadhubhushanr
 */
public enum ObjectTypeEnum {

    LIST_TYPE("list"),PLAIN_TYPE("plain");
    private String value;

    private ObjectTypeEnum(String value) {
        this.value = value;
    }

    /**
     * @return the value
     */
    public String getValue() {
        return value;
    }
}
