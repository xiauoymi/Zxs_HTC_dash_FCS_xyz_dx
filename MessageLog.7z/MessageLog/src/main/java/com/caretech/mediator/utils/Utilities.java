package com.caretech.mediator.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

public class Utilities {
	
	public static String getCurrentDateTime() {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		return dateFormat.format(cal.getTime());
	}
	
	public static String getCurrentDateTime(Date currentTime) {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		return dateFormat.format(currentTime.getTime());
	}
	
	public static String getTimeDifference(Date startTime, Date endTime) {
		long difference = endTime.getTime()-startTime.getTime();
		long dsecs = difference / 1000;
	    //long dminutes = difference / (60 * 1000);
		return String.valueOf(dsecs) + " Seconds";
	}
	
	public static String getCurrentSNOWDateTime() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		return dateFormat.format(cal.getTime());
	}
	
	public static String escapeSpecialCharacter(Map<String, Object> remedyParameters,
			String fieldName) {
		String fieldValue = remedyParameters.get(fieldName) != null ? String.valueOf(fieldName) : null;
		if(fieldValue != null){
			fieldValue = fieldValue.replace("â€“", "–");
		}
		return fieldValue;
	}

}
