/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.caretech.mediator.datamapping.dto;

import java.util.Objects;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;


/**
 * @author gopinathn
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "field")
public class FieldSourceDTO {
    //Attributes

    @XmlAttribute(name = "id")
    private String sourceFieldId;
    @XmlAttribute(name = "name")
    private String name;
    @XmlAttribute(name = "dataType")
    private String dataType;
    @XmlAttribute(name = "precision")
    private String precision;
    @XmlAttribute(name = "mandatory")
    private String mandatory;
    @XmlAttribute(name = "size")
    private String size;

    public FieldSourceDTO() {
    }

    public FieldSourceDTO(String id) {
        this.sourceFieldId = id;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final FieldSourceDTO other = (FieldSourceDTO) obj;
        if (!Objects.equals(this.sourceFieldId, other.sourceFieldId)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + Objects.hashCode(this.sourceFieldId);
        return hash;
    }

    /**
     * @return the sourceFieldId
     */
    public String getSourceFieldId() {
        return sourceFieldId;
    }

    /**
     * @param sourceFieldId the sourceFieldId to set
     */
    public void setSourceFieldId(String sourceFieldId) {
        this.sourceFieldId = sourceFieldId;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the dataType
     */
    public String getDataType() {
        return dataType;
    }

    /**
     * @param dataType the dataType to set
     */
    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    /**
     * @return the mandatory
     */
    public String getMandatory() {
        return mandatory;
    }

    /**
     * @param mandatory the mandatory to set
     */
    public void setMandatory(String mandatory) {
        this.mandatory = mandatory;
    }

    /**
     * @return the size
     */
    public String getSize() {
        return size;
    }

    /**
     * @param size the size to set
     */
    public void setSize(String size) {
        this.size = size;
    }

    /**
     * @return the precision
     */
    public String getPrecision() {
        return precision;
    }

    /**
     * @param precision the precision to set
     */
    public void setPrecision(String precision) {
        this.precision = precision;
    }
}
