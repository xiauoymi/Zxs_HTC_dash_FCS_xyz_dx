package com.caretech.mediator.service;




import java.util.Map;

import com.caretech.mediator.datamapping.exception.IncidentException;
import com.caretech.mediator.model.Response;


public interface TicketService {
	
	/**
	 * Method to update the incident status in Remedy.
	 * @param incident
	 * @return
	 * @throws IncidentException 
	 */
	public Map<String, Object> updateIncidentStatus(String incident) throws IncidentException;

	/**
	 * Method to create a new incident in Service Now.
	 * @param incident
	 * @return
	 * @throws IncidentException 
	 */
	public Map<String, Object> createIncident(String incident) throws IncidentException;

	/**
	 * Method to upload attachments to Service Now.
	 * @param incident
	 * @return
	 * @throws IncidentException 
	 */
	public Map<String, Object> uploadAttachments(String incident) throws IncidentException;

	/**
	 * Method to update a new incident in Service Now.
	 * @param incident
	 * @param requestMessageId 
	 * @return
	 * @throws IncidentException 
	 */
	public Response updateIncident(String incident, String requestMessageId) throws IncidentException;
	
	public Response createTicket(String incident) throws IncidentException;
	
	public Response createDataSync(String incident) throws IncidentException;
	

}
