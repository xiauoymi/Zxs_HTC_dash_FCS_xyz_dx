
package com.caretech.webservice.datasync;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the cmn.integrationfoundationdatasync_ws package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _NewCreateOperation0_QNAME = new QName("urn:CMN:IntegrationFoundationDataSync_WS", "New_Create_Operation_0");
    private final static QName _NewCreateOperation0Response_QNAME = new QName("urn:CMN:IntegrationFoundationDataSync_WS", "New_Create_Operation_0Response");
    private final static QName _AuthenticationInfo_QNAME = new QName("urn:CMN:IntegrationFoundationDataSync_WS", "AuthenticationInfo");
    private final static QName _InputMapping1TransactionType_QNAME = new QName("urn:CMN:IntegrationFoundationDataSync_WS", "Transaction_Type");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: cmn.integrationfoundationdatasync_ws
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link InputMapping1 }
     * 
     */
    public InputMapping1 createInputMapping1() {
        return new InputMapping1();
    }

    /**
     * Create an instance of {@link OutputMapping1 }
     * 
     */
    public OutputMapping1 createOutputMapping1() {
        return new OutputMapping1();
    }

    /**
     * Create an instance of {@link AuthenticationInfo }
     * 
     */
    public AuthenticationInfo createAuthenticationInfo() {
        return new AuthenticationInfo();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InputMapping1 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:CMN:IntegrationFoundationDataSync_WS", name = "New_Create_Operation_0")
    public JAXBElement<InputMapping1> createNewCreateOperation0(InputMapping1 value) {
        return new JAXBElement<InputMapping1>(_NewCreateOperation0_QNAME, InputMapping1 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OutputMapping1 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:CMN:IntegrationFoundationDataSync_WS", name = "New_Create_Operation_0Response")
    public JAXBElement<OutputMapping1> createNewCreateOperation0Response(OutputMapping1 value) {
        return new JAXBElement<OutputMapping1>(_NewCreateOperation0Response_QNAME, OutputMapping1 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AuthenticationInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:CMN:IntegrationFoundationDataSync_WS", name = "AuthenticationInfo")
    public JAXBElement<AuthenticationInfo> createAuthenticationInfo(AuthenticationInfo value) {
        return new JAXBElement<AuthenticationInfo>(_AuthenticationInfo_QNAME, AuthenticationInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TransactionTypeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:CMN:IntegrationFoundationDataSync_WS", name = "Transaction_Type", scope = InputMapping1 .class)
    public JAXBElement<TransactionTypeType> createInputMapping1TransactionType(TransactionTypeType value) {
        return new JAXBElement<TransactionTypeType>(_InputMapping1TransactionType_QNAME, TransactionTypeType.class, InputMapping1 .class, value);
    }

}
