@javax.xml.bind.annotation.XmlSchema(namespace = "urn:CMN:IntegrationFoundationDataSync_WS", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.caretech.webservice.datasync;
