
package com.caretech.webservice.integration.create;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SourceType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="SourceType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="ACD"/>
 *     &lt;enumeration value="Requester"/>
 *     &lt;enumeration value="Email"/>
 *     &lt;enumeration value="Web"/>
 *     &lt;enumeration value="Direct"/>
 *     &lt;enumeration value="Import"/>
 *     &lt;enumeration value="Fax"/>
 *     &lt;enumeration value="Voicemail"/>
 *     &lt;enumeration value="Proactive"/>
 *     &lt;enumeration value="Service Catalog"/>
 *     &lt;enumeration value="Chat"/>
 *     &lt;enumeration value="Self-Service"/>
 *     &lt;enumeration value="Integration"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "SourceType")
@XmlEnum
public enum SourceType {

    ACD("ACD"),
    @XmlEnumValue("Requester")
    REQUESTER("Requester"),
    @XmlEnumValue("Email")
    EMAIL("Email"),
    @XmlEnumValue("Web")
    WEB("Web"),
    @XmlEnumValue("Direct")
    DIRECT("Direct"),
    @XmlEnumValue("Import")
    IMPORT("Import"),
    @XmlEnumValue("Fax")
    FAX("Fax"),
    @XmlEnumValue("Voicemail")
    VOICEMAIL("Voicemail"),
    @XmlEnumValue("Proactive")
    PROACTIVE("Proactive"),
    @XmlEnumValue("Service Catalog")
    SERVICE_CATALOG("Service Catalog"),
    @XmlEnumValue("Chat")
    CHAT("Chat"),
    @XmlEnumValue("Self-Service")
    SELF_SERVICE("Self-Service"),
    @XmlEnumValue("Integration")
    INTEGRATION("Integration");
    private final String value;

    SourceType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static SourceType fromValue(String v) {
        for (SourceType c: SourceType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
