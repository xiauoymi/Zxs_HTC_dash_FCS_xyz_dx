
package com.caretech.webservice.integration;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the cmn.integration.createinboundticket_wb package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _AuthenticationInfo_QNAME = new QName("urn:CMN:Integration:CreateInBoundTicket_WB", "AuthenticationInfo");
    private final static QName _NewCreateOperation0_QNAME = new QName("urn:CMN:Integration:CreateInBoundTicket_WB", "New_Create_Operation_0");
    private final static QName _NewCreateOperation0Response_QNAME = new QName("urn:CMN:Integration:CreateInBoundTicket_WB", "New_Create_Operation_0Response");
    private final static QName _InputMapping1Title_QNAME = new QName("urn:CMN:Integration:CreateInBoundTicket_WB", "Title");
    private final static QName _InputMapping1Source_QNAME = new QName("urn:CMN:Integration:CreateInBoundTicket_WB", "Source");
    private final static QName _InputMapping1TicketStatus_QNAME = new QName("urn:CMN:Integration:CreateInBoundTicket_WB", "Ticket_Status");
    private final static QName _InputMapping1Priority_QNAME = new QName("urn:CMN:Integration:CreateInBoundTicket_WB", "Priority");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: cmn.integration.createinboundticket_wb
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link InputMapping1 }
     * 
     */
    public InputMapping1 createInputMapping1() {
        return new InputMapping1();
    }

    /**
     * Create an instance of {@link OutputMapping1 }
     * 
     */
    public OutputMapping1 createOutputMapping1() {
        return new OutputMapping1();
    }

    /**
     * Create an instance of {@link AuthenticationInfo }
     * 
     */
    public AuthenticationInfo createAuthenticationInfo() {
        return new AuthenticationInfo();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AuthenticationInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:CMN:Integration:CreateInBoundTicket_WB", name = "AuthenticationInfo")
    public JAXBElement<AuthenticationInfo> createAuthenticationInfo(AuthenticationInfo value) {
        return new JAXBElement<AuthenticationInfo>(_AuthenticationInfo_QNAME, AuthenticationInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InputMapping1 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:CMN:Integration:CreateInBoundTicket_WB", name = "New_Create_Operation_0")
    public JAXBElement<InputMapping1> createNewCreateOperation0(InputMapping1 value) {
        return new JAXBElement<InputMapping1>(_NewCreateOperation0_QNAME, InputMapping1 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OutputMapping1 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:CMN:Integration:CreateInBoundTicket_WB", name = "New_Create_Operation_0Response")
    public JAXBElement<OutputMapping1> createNewCreateOperation0Response(OutputMapping1 value) {
        return new JAXBElement<OutputMapping1>(_NewCreateOperation0Response_QNAME, OutputMapping1 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TitleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:CMN:Integration:CreateInBoundTicket_WB", name = "Title", scope = InputMapping1 .class)
    public JAXBElement<TitleType> createInputMapping1Title(TitleType value) {
        return new JAXBElement<TitleType>(_InputMapping1Title_QNAME, TitleType.class, InputMapping1 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SourceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:CMN:Integration:CreateInBoundTicket_WB", name = "Source", scope = InputMapping1 .class)
    public JAXBElement<SourceType> createInputMapping1Source(SourceType value) {
        return new JAXBElement<SourceType>(_InputMapping1Source_QNAME, SourceType.class, InputMapping1 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TicketStatusType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:CMN:Integration:CreateInBoundTicket_WB", name = "Ticket_Status", scope = InputMapping1 .class)
    public JAXBElement<TicketStatusType> createInputMapping1TicketStatus(TicketStatusType value) {
        return new JAXBElement<TicketStatusType>(_InputMapping1TicketStatus_QNAME, TicketStatusType.class, InputMapping1 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PriorityType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:CMN:Integration:CreateInBoundTicket_WB", name = "Priority", scope = InputMapping1 .class)
    public JAXBElement<PriorityType> createInputMapping1Priority(PriorityType value) {
        return new JAXBElement<PriorityType>(_InputMapping1Priority_QNAME, PriorityType.class, InputMapping1 .class, value);
    }

}
