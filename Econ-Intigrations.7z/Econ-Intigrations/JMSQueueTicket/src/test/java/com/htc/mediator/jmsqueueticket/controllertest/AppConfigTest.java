package com.htc.mediator.jmsqueueticket.controllertest;


import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;


import com.htc.mediator.jmsqueueticket.configuration.MessagingConfiguration;
import com.htc.mediator.jmsqueueticket.configuration.MessagingListnerConfiguration;
//import com.htc.mediator.jmsqueueticketresponse.messaging.MessageReceiver;

@Configuration
// @ComponentScan(basePackages =
// {"com.htc.mediator.jmsqueueticket.configuration"})
// @Import({MessagingConfiguration.class,MessagingListnerConfiguration.class})
@PropertySource(value = { "classpath:dbconfig.properties" })
@ComponentScan(basePackages = {"com.htc.mediator.jmsqueueticket.controller",
		                       "com.htc.mediator.jmsqueueticket.service",
		                       "com.htc.mediator.jmsqueueticket.messaging",
		                       "com.htc.mediator.jmsqueueticket.controllertest",
		                       "com.htc.mediator.jmsSenderResponse.Dao",
		                       "com.htc.mediator.jmsSenderResponse.Dao.Impl"
		                      		                       })



//@Import({ MessagingConfiguration.class, MessagingListnerConfiguration.class })
@EnableWebMvc
public class AppConfigTest  {

	
	@Autowired
    private Environment env;
	
	   @Bean
	    public DataSource datasource() {
	        DriverManagerDataSource dataSource = new DriverManagerDataSource();
	        dataSource.setDriverClassName(env.getRequiredProperty("jdbc.driverClassName"));
	        dataSource.setUrl(env.getRequiredProperty("jdbc.url"));
	        dataSource.setUsername(env.getRequiredProperty("jdbc.username"));
	        dataSource.setPassword(env.getRequiredProperty("jdbc.password"));
	        return dataSource;
	    }
	 
	    @Bean
	    public JdbcTemplate jdbcTemplate(DataSource dataSource) {
	        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
	        jdbcTemplate.setResultsMapCaseInsensitive(true);
	        return jdbcTemplate;
	    }
}  
