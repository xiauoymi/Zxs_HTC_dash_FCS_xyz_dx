package com.htc.mediator.jmsqueueticket.controllertest;

import static org.junit.Assert.*;

import org.junit.Test;


import com.google.gson.Gson;
import com.htc.mediator.jmsqueueticket.configuration.AppConfig;
import com.htc.mediator.jmsqueueticket.controller.AppController;
import com.htc.mediator.jmsqueueticket.model.TicketAttachment;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {AppConfigTest.class})
public class AppControllerTest {

	@Autowired
	private AppController appController;
	
	@Test
	public void testuploadAttachment() {
		TicketAttachment ticketAttachment = new TicketAttachment();
		try {
			appController.uploadAttachment(ticketAttachment);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



}

