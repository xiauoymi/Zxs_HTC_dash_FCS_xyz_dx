package com.htc.mediator.jmsqueueticket.messaging;

import static com.htc.mediator.jmsqueueticket.util.JMSHelper.objectToMessage;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Component;

import com.htc.mediator.jmsqueueticket.model.Order;

@Component
public class MessageSender {

	static final Logger LOG = LoggerFactory.getLogger(MessageSender.class);

	@Autowired
	JmsTemplate jmsTemplate;

	
	private static final String UPDATETICKETOR_QUEUE = "updateTicketOR-queue";
	private static final String CREATETICKETOR_QUEUE = "createTicketOR-queue";
	private static final String CREATE_IR_QUEUE = "createIR-queue";
	private static final String UPDATE_IR_QUEUE = "updateIR-queue";
	private static final String UPLOADATTACHMENT_QUEUE = "uploadAttachment-queue";
	
	private static final String UPLOADTICKETIR_QUEUE = "uploadTicketIR-queue";
	
	public void createTicketORQue(final Order order) {

		jmsTemplate.send(CREATETICKETOR_QUEUE,new MessageCreator(){
			@Override
				public Message createMessage(Session session) throws JMSException{
					ObjectMessage objectMessage = session.createObjectMessage(order);
				
					
					return objectMessage;
				}
			});
	}
	
	public void updateTicketORQue(final Order order) {

		
		jmsTemplate.send(UPDATETICKETOR_QUEUE, new MessageCreator(){
			@Override
			public Message createMessage(Session session) throws JMSException{
				ObjectMessage objectMessage = session.createObjectMessage(order);
			
				
				return objectMessage;
			}
			});
		
	}

public void createTicketIRMessage(final Order order) {

		
		jmsTemplate.send(CREATE_IR_QUEUE, new MessageCreator(){
			@Override
			public Message createMessage(Session session) throws JMSException{
				ObjectMessage objectMessage = session.createObjectMessage(order);
			
				
				return objectMessage;
			}
			});
		
	}


public void uploadTicketIRMessage(final Order order) {

	
	jmsTemplate.send(UPLOADTICKETIR_QUEUE, new MessageCreator(){
		@Override
		public Message createMessage(Session session) throws JMSException{
			ObjectMessage objectMessage = session.createObjectMessage(order);
		
			
			return objectMessage;
		}
		});
	
}


public void updateTicketIRMessage(final Order order) {

	
	jmsTemplate.send(UPDATE_IR_QUEUE, new MessageCreator(){
		@Override
		public Message createMessage(Session session) throws JMSException{
			ObjectMessage objectMessage = session.createObjectMessage(order);
		
			
			return objectMessage;
		}
		});
	
}

	public void uplaodAttachment(final Order order) {


        
		if (order != null) {

	        if(order.getTicketAttachment() != null) {
	        	 
					jmsTemplate.send(UPLOADATTACHMENT_QUEUE,new MessageCreator(){ 					
						@Override
						public Message createMessage(Session session) throws JMSException{
					    byte[] objBytes = objectToMessage(order);
						BytesMessage bytesMessage = session.createBytesMessage();
						bytesMessage.writeBytes(objBytes);
						return bytesMessage;
					}});
				}else {
					jmsTemplate.send(UPLOADATTACHMENT_QUEUE,new MessageCreator(){
						@Override
							public Message createMessage(Session session) throws JMSException{
								ObjectMessage objectMessage = session.createObjectMessage(order);
								return objectMessage;
							}
						});
				}
			}
	  }

}

// public void sendBytesMessages(String destinationName) throws JMSException {
// final StringBuilder buffer = new StringBuilder();
//
// for (int i = 0; i < numberOfMessages; ++i) {
// buffer.append("Message '").append(i).append("' sent at: ").append(new
// Date());
//
// final int count = i;
// final String payload = buffer.toString();
//
// jmsTemplate.send(destinationName, new MessageCreator() {
// public Message createMessage(Session session) throws JMSException {
// BytesMessage message = session.createBytesMessage();
// message.writeUTF(payload);
// message.setIntProperty("messageCount", count);
// LOG.info("Sending bytes message number '{}'", count);
// return message;
// }
// });
// }
// }
//
// for (int i = 0; i < numberOfMessages; ++i) {
// buffer.append("Message '").append(i).append("' sent at: ").append(new
// Date());
//
// final int count = i;
// final String payload = buffer.toString();
//
// jmsTemplate.send(destinationName, new MessageCreator() {
// public Message createMessage(Session session) throws JMSException {
// BytesMessage message = session.createBytesMessage();
// message.writeUTF(payload);
// message.setIntProperty("messageCount", count);
// LOG.info("Sending bytes message number '{}'", count);
// return message;
// }
// });
// }
