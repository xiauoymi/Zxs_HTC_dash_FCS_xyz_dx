package com.htc.mediator.jmsqueueticket.model;

import java.io.Serializable;

public class ServiceNowTicket implements Serializable{

/**
	 * 
	 */
	private static final long serialVersionUID = -4666130226870715612L;
private String number;
private String ServiceName;
public String getServiceName() {
	return ServiceName;
}
public void setServiceName(String serviceName) {
	ServiceName = serviceName;
}
private String u_external_ticket_id;
private String u_call_back_number;
private String short_description;
private String resolved_by;
private String resolved_at;
private String work_notes;
private String active;
private String state;
private String opened_by;
private String sys_created_by;
private String sys_created_on;
private String assigned_to;
private String caller_id;
private String comments;
private String description;
private String location;
private String priority;
private String category;
private String subcategory;
private String cmdb_ci;
private String assignment_group;
private String company;
private String contact_type;
private String sys_updated_on;
private String u_department;
private String close_code;
private String close_notes;
private String closed_by;
private String u_node_name;
private String u_citrix_server;
private String u_kb_article_not_found;
private String u_remote_used;
private String knowledge;
private String u_kcs_solution;
private String u_overide_priority;
private String u_reason_override_priority;
private String u_patient_info;
private String user_id;
private String u_unlisted_location;
private String u_unlisted_caller;
private String urgency;
private String attachment_1_attachmentName;
private String attachment_1_attachmentData;
private String attachment_2_attachmentName;
private String attachment_2_attachmentData;
private String attachment_3_attachmentName;
private String attachment_3_attachmentData;
private String attachment_4_attachmentName;
private String attachment_4_attachmentData;
private String attachment_5_attachmentName;
private String attachment_5_attachmentData;
private String sys_id;


public String getSys_id() {
	return sys_id;
}

public void setSys_id(String sys_id) {
	this.sys_id = sys_id;
}

@Override
public String toString() {
	String result ="{" 
			+ (number != null ?  "\"number\":\"" + number + "\", " : "")
			+ (ServiceName != null ?  "\"ServiceName\":\"" + ServiceName + "\", " : "")
			+ (u_external_ticket_id != null ?  "\"u_external_ticket_id\":\"" + u_external_ticket_id + "\", " : "")
			+ (u_call_back_number != null ?  "\"u_call_back_number\":\"" + u_call_back_number + "\", " : "")
			+ (short_description != null ?  "\"short_description\":\"" + short_description + "\", " : "")
			+ (resolved_by != null ?  "\"resolved_by\":\"" + resolved_by + "\", " : "")
			+ (resolved_at != null ?  "\"resolved_at\":\"" + resolved_at + "\", " : "")
			+ (work_notes != null ?  "\"work_notes\":\"" + work_notes + "\", " : "")
			+ (active != null ?  "\"active\":\"" + active + "\", " : "")
			+ (state != null ?  "\"state\":\"" + state + "\", " : "")
			+ (opened_by != null ?  "\"opened_by\":\"" + opened_by + "\", " : "")
			+ (sys_created_by != null ?  "\"sys_created_by\":\"" + sys_created_by + "\", " : "")
			+ (sys_created_on != null ?  "\"sys_created_on\":\"" + sys_created_on + "\", " : "")
			+ (assigned_to != null ?  "\"assigned_to\":\"" + assigned_to + "\", " : "")
			+ (caller_id != null ?  "\"caller_id\":\"" + caller_id + "\", " : "")
			+ (comments != null ?  "\"comments\":\"" + comments + "\", " : "")
			+ (description != null ?  "\"description\":\"" + description + "\", " : "")
			+ (location != null ?  "\"location\":\"" + location + "\", " : "")
			+ (priority != null ?  "\"priority\":\"" + priority + "\", " : "")
			+ (category != null ?  "\"category\":\"" + category + "\", " : "")
			+ (subcategory != null ?  "\"subcategory\":\"" + subcategory + "\", " : "")
			+ (cmdb_ci != null ?  "\"cmdb_ci\":\"" + cmdb_ci + "\", " : "")
			+ (assignment_group != null ?  "\"assignment_group\":\"" + assignment_group + "\", " : "")
			+ (company != null ?  "\"company\":\"" + company + "\", " : "")
			+ (contact_type != null ?  "\"contact_type\":\"" + contact_type + "\", " : "")
			+ (sys_updated_on != null ?  "\"sys_updated_on\":\"" + sys_updated_on + "\", " : "")
			+ (u_department != null ?  "\"u_department\":\"" + u_department + "\", " : "")
			+ (close_code != null ?  "\"close_code\":\"" + close_code + "\", " : "")
			+ (close_notes != null ?  "\"close_notes\":\"" + close_notes + "\", " : "")
			+ (closed_by != null ?  "\"closed_by\":\"" + closed_by + "\", " : "")
			+ (u_node_name != null ?  "\"u_node_name\":\"" + u_node_name + "\", " : "")
			+ (u_citrix_server != null ?  "\"u_citrix_server\":\"" + u_citrix_server + "\", " : "")
			+ (u_kb_article_not_found != null ?  "\"u_kb_article_not_found\":\"" + u_kb_article_not_found + "\", " : "")
			+ (u_remote_used != null ?  "\"u_remote_used\":\"" + u_remote_used + "\", " : "")
			+ (knowledge != null ?  "\"knowledge\":\"" + knowledge + "\", " : "")
			+ (u_kcs_solution != null ?  "\"u_kcs_solution\":\"" + u_kcs_solution + "\", " : "")
			+ (u_overide_priority != null ?  "\"u_overide_priority\":\"" + u_overide_priority + "\", " : "")
			+ (u_reason_override_priority != null ?  "\"u_reason_override_priority\":\"" + u_reason_override_priority + "\", " : "")
			+ (u_patient_info != null ?  "\"u_patient_info\":\"" + u_patient_info + "\", " : "")
			+ (user_id != null ?  "\"user_id\":\"" + user_id + "\", " : "")
			+ (u_unlisted_location != null ?  "\"u_unlisted_location\":\"" + u_unlisted_location + "\", " : "")
			+ (u_unlisted_caller != null ?  "\"u_unlisted_caller\":\"" + u_unlisted_caller + "\", " : "")
			+ (urgency != null ?  "\"urgency\":\"" + urgency + "\", " : "")
			+ (attachment_1_attachmentName != null ?  "\"attachment_1_attachmentName\":\"" + attachment_1_attachmentName + "\", " : "")
			+ (attachment_1_attachmentData != null ?  "\"attachment_1_attachmentData\":\"" + attachment_1_attachmentData + "\", " : "")
			+ (attachment_2_attachmentName != null ?  "\"attachment_2_attachmentName\":\"" + attachment_2_attachmentName + "\", " : "")
			+ (attachment_2_attachmentData != null ?  "\"attachment_2_attachmentData\":\"" + attachment_2_attachmentData + "\", " : "")
			+ (attachment_3_attachmentName != null ?  "\"attachment_3_attachmentName\":\"" + attachment_3_attachmentName + "\", " : "")
			+ (attachment_3_attachmentData != null ?  "\"attachment_3_attachmentData\":\"" + attachment_3_attachmentData + "\", " : "")
			+ (attachment_4_attachmentName != null ?  "\"attachment_4_attachmentName\":\"" + attachment_4_attachmentName + "\", " : "")
			+ (attachment_4_attachmentData != null ?  "\"attachment_4_attachmentData\":\"" + attachment_4_attachmentData + "\", " : "")
			+ (attachment_5_attachmentName != null ?  "\"attachment_5_attachmentName\":\"" + attachment_5_attachmentName + "\", " : "")
			+ (attachment_5_attachmentData != null ?  "\"attachment_5_attachmentData\":\"" + attachment_5_attachmentData + "\", " : "")
			+ (parent_incident != null ?  "\"parent_incident\":\"" + parent_incident + "\", " : "")
			+ (sys_id != null ? "\"sys_id\":\"" + sys_id +"\", " : "");

			result = result.substring(0, result.lastIndexOf(","))+ "}";
return result;
}
private String parent_incident;
public String getNumber() {
	return number;
}
public void setNumber(String number) {
	this.number = number;
}
public String getU_external_ticket_id() {
	return u_external_ticket_id;
}
public void setU_external_ticket_id(String u_external_ticket_id) {
	this.u_external_ticket_id = u_external_ticket_id;
}
public String getU_call_back_number() {
	return u_call_back_number;
}
public void setU_call_back_number(String u_call_back_number) {
	this.u_call_back_number = u_call_back_number;
}
public String getShort_description() {
	return short_description;
}
public void setShort_description(String short_description) {
	this.short_description = short_description;
}
public String getResolved_by() {
	return resolved_by;
}
public void setResolved_by(String resolved_by) {
	this.resolved_by = resolved_by;
}
public String getResolved_at() {
	return resolved_at;
}
public void setResolved_at(String resolved_at) {
	this.resolved_at = resolved_at;
}
public String getWork_notes() {
	return work_notes;
}
public void setWork_notes(String work_notes) {
	this.work_notes = work_notes;
}
public String getActive() {
	return active;
}
public void setActive(String active) {
	this.active = active;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getOpened_by() {
	return opened_by;
}
public void setOpened_by(String opened_by) {
	this.opened_by = opened_by;
}
public String getSys_created_by() {
	return sys_created_by;
}
public void setSys_created_by(String sys_created_by) {
	this.sys_created_by = sys_created_by;
}
public String getSys_created_on() {
	return sys_created_on;
}
public void setSys_created_on(String sys_created_on) {
	this.sys_created_on = sys_created_on;
}
public String getAssigned_to() {
	return assigned_to;
}
public void setAssigned_to(String assigned_to) {
	this.assigned_to = assigned_to;
}
public String getCaller_id() {
	return caller_id;
}
public void setCaller_id(String caller_id) {
	this.caller_id = caller_id;
}
public String getComments() {
	return comments;
}
public void setComments(String comments) {
	this.comments = comments;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public String getPriority() {
	return priority;
}
public void setPriority(String priority) {
	this.priority = priority;
}
public String getCategory() {
	return category;
}
public void setCategory(String category) {
	this.category = category;
}
public String getSubcategory() {
	return subcategory;
}
public void setSubcategory(String subcategory) {
	this.subcategory = subcategory;
}
public String getCmdb_ci() {
	return cmdb_ci;
}
public void setCmdb_ci(String cmdb_ci) {
	this.cmdb_ci = cmdb_ci;
}
public String getAssignment_group() {
	return assignment_group;
}
public void setAssignment_group(String assignment_group) {
	this.assignment_group = assignment_group;
}
public String getCompany() {
	return company;
}
public void setCompany(String company) {
	this.company = company;
}
public String getContact_type() {
	return contact_type;
}
public void setContact_type(String contact_type) {
	this.contact_type = contact_type;
}
public String getSys_updated_on() {
	return sys_updated_on;
}
public void setSys_updated_on(String sys_updated_on) {
	this.sys_updated_on = sys_updated_on;
}
public String getU_department() {
	return u_department;
}
public void setU_department(String u_department) {
	this.u_department = u_department;
}
public String getClose_code() {
	return close_code;
}
public void setClose_code(String close_code) {
	this.close_code = close_code;
}
public String getClose_notes() {
	return close_notes;
}
public void setClose_notes(String close_notes) {
	this.close_notes = close_notes;
}
public String getClosed_by() {
	return closed_by;
}
public void setClosed_by(String closed_by) {
	this.closed_by = closed_by;
}
public String getU_node_name() {
	return u_node_name;
}
public void setU_node_name(String u_node_name) {
	this.u_node_name = u_node_name;
}
public String getU_citrix_server() {
	return u_citrix_server;
}
public void setU_citrix_server(String u_citrix_server) {
	this.u_citrix_server = u_citrix_server;
}
public String getU_kb_article_not_found() {
	return u_kb_article_not_found;
}
public void setU_kb_article_not_found(String u_kb_article_not_found) {
	this.u_kb_article_not_found = u_kb_article_not_found;
}
public String getU_remote_used() {
	return u_remote_used;
}
public void setU_remote_used(String u_remote_used) {
	this.u_remote_used = u_remote_used;
}
public String getKnowledge() {
	return knowledge;
}
public void setKnowledge(String knowledge) {
	this.knowledge = knowledge;
}
public String getU_kcs_solution() {
	return u_kcs_solution;
}
public void setU_kcs_solution(String u_kcs_solution) {
	this.u_kcs_solution = u_kcs_solution;
}
public String getU_overide_priority() {
	return u_overide_priority;
}
public void setU_overide_priority(String u_overide_priority) {
	this.u_overide_priority = u_overide_priority;
}
public String getU_reason_override_priority() {
	return u_reason_override_priority;
}
public void setU_reason_override_priority(String u_reason_override_priority) {
	this.u_reason_override_priority = u_reason_override_priority;
}
public String getU_patient_info() {
	return u_patient_info;
}
public void setU_patient_info(String u_patient_info) {
	this.u_patient_info = u_patient_info;
}
public String getUser_id() {
	return user_id;
}
public void setUser_id(String user_id) {
	this.user_id = user_id;
}
public String getU_unlisted_location() {
	return u_unlisted_location;
}
public void setU_unlisted_location(String u_unlisted_location) {
	this.u_unlisted_location = u_unlisted_location;
}
public String getU_unlisted_caller() {
	return u_unlisted_caller;
}
public void setU_unlisted_caller(String u_unlisted_caller) {
	this.u_unlisted_caller = u_unlisted_caller;
}
public String getUrgency() {
	return urgency;
}
public void setUrgency(String urgency) {
	this.urgency = urgency;
}
public String getAttachment_1_attachmentName() {
	return attachment_1_attachmentName;
}
public void setAttachment_1_attachmentName(String attachment_1_attachmentName) {
	this.attachment_1_attachmentName = attachment_1_attachmentName;
}
public String getAttachment_1_attachmentData() {
	return attachment_1_attachmentData;
}
public void setAttachment_1_attachmentData(String attachment_1_attachmentData) {
	this.attachment_1_attachmentData = attachment_1_attachmentData;
}
public String getAttachment_2_attachmentName() {
	return attachment_2_attachmentName;
}
public void setAttachment_2_attachmentName(String attachment_2_attachmentName) {
	this.attachment_2_attachmentName = attachment_2_attachmentName;
}
public String getAttachment_2_attachmentData() {
	return attachment_2_attachmentData;
}
public void setAttachment_2_attachmentData(String attachment_2_attachmentData) {
	this.attachment_2_attachmentData = attachment_2_attachmentData;
}
public String getAttachment_3_attachmentName() {
	return attachment_3_attachmentName;
}
public void setAttachment_3_attachmentName(String attachment_3_attachmentName) {
	this.attachment_3_attachmentName = attachment_3_attachmentName;
}
public String getAttachment_3_attachmentData() {
	return attachment_3_attachmentData;
}
public void setAttachment_3_attachmentData(String attachment_3_attachmentData) {
	this.attachment_3_attachmentData = attachment_3_attachmentData;
}
public String getAttachment_4_attachmentName() {
	return attachment_4_attachmentName;
}
public void setAttachment_4_attachmentName(String attachment_4_attachmentName) {
	this.attachment_4_attachmentName = attachment_4_attachmentName;
}
public String getAttachment_4_attachmentData() {
	return attachment_4_attachmentData;
}
public void setAttachment_4_attachmentData(String attachment_4_attachmentData) {
	this.attachment_4_attachmentData = attachment_4_attachmentData;
}
public String getAttachment_5_attachmentName() {
	return attachment_5_attachmentName;
}
public void setAttachment_5_attachmentName(String attachment_5_attachmentName) {
	this.attachment_5_attachmentName = attachment_5_attachmentName;
}
public String getAttachment_5_attachmentData() {
	return attachment_5_attachmentData;
}
public void setAttachment_5_attachmentData(String attachment_5_attachmentData) {
	this.attachment_5_attachmentData = attachment_5_attachmentData;
}
public String getParent_incident() {
	return parent_incident;
}
public void setParent_incident(String parent_incident) {
	this.parent_incident = parent_incident;
}
	
	
}
