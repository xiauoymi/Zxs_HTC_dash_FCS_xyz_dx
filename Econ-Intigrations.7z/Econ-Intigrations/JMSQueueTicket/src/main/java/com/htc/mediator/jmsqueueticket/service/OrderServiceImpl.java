package com.htc.mediator.jmsqueueticket.service;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.htc.mediator.jmsqueueticket.messaging.MessageSender;
import com.htc.mediator.jmsqueueticket.model.InventoryResponse;
import com.htc.mediator.jmsqueueticket.model.Order;
import com.htc.mediator.jmsqueueticket.model.OrderStatus;
import com.htc.mediator.jmsqueueticket.model.ServiceNowTicket;
import com.htc.mediator.jmsqueueticket.util.BasicUtil;
import com.htc.mediator.jmsqueueticket.service.OrderService;;



@Service("orderService")
public class OrderServiceImpl implements OrderService{

	static final Logger LOG = LoggerFactory.getLogger(OrderServiceImpl.class);
	
	@Autowired
	MessageSender messageSender;
	
	@Autowired
	OrderRepository orderRepository;
	
	@Override
	public String createTicketOR(Order order) {
		LOG.info("+++++++++++++++++++++++++++++++++++++++++++++++++++++");
		order.setOrderId(BasicUtil.getUniqueId());
		order.setStatus(OrderStatus.CREATED);
		order.setDestination("ServiceNow");
		orderRepository.putOrder(order);
		LOG.info("Application : sending order request {}", order);
		messageSender.createTicketORQue(order);
		LOG.info("+++++++++++++++++++++++++++++++++++++++++++++++++++++");
		return "Creator ticket sent to JMSQue";
	}

	@Override
	public String updateTicketOR(Order order) {
		order.setOrderId(BasicUtil.getUniqueId());
		order.setStatus(OrderStatus.CREATED);
		order.setDestination("ServiceNow");
		messageSender.updateTicketORQue(order);
		return "UpdateOr ticket sent to JMSQue";
	}
	
	@Override
	public String createTicketIR(Order order ) {
		order.setOrderId(BasicUtil.getUniqueId());
		order.setStatus(OrderStatus.CREATED);
		order.setDestination("Remedy");
		messageSender.createTicketIRMessage(order);
		return "CreateIR ticket sent to JMSQue";
	}
	
	@Override
	public String updateTicketIR(Order order ) {
		order.setOrderId(BasicUtil.getUniqueId());
		order.setStatus(OrderStatus.CREATED);
		order.setDestination("Remedy");
		messageSender.updateTicketIRMessage(order);
		return "UpdateIR ticket sent to JMSQue";
	}
	public Map<String, Order> getAllOrders(){
		return orderRepository.getAllOrders();
	}

	@Override
	public String uploadAttachment(Order order) {
		order.setOrderId(BasicUtil.getUniqueId());
		order.setStatus(OrderStatus.CREATED);
		order.setDestination("ServiceNow");
		messageSender.uplaodAttachment(order);
		return "upload attachment ticket sent to JMSQue";
		
	}

	
}
