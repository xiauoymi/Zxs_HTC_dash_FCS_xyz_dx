package com.htc.mediator.jmsqueueticket.service;

import java.util.Map;

import com.htc.mediator.jmsqueueticket.model.Order;
import com.htc.mediator.jmsqueueticket.model.ServiceNowTicket;

public interface OrderService {
	
	
	public Map<String, Order> getAllOrders();


	public String createTicketIR(Order order);

	public String updateTicketIR(Order order);

	public String createTicketOR(Order order);

	public String updateTicketOR(Order order);
		
	
	String uploadAttachment(Order order);

	
}
