package com.htc.mediator.jmsqueueticket.model;

import java.io.Serializable;
import java.util.List;


public class Order implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String orderId;
	
	private String productName;
	private String Description;
	private String Destination;
	

	private ServiceNowTicket serviceNowTicket; 
	
	private TicketAttachment ticketAttachment;
	
	private Ticket ticket;
	

	public TicketAttachment getTicketAttachment() {
		return ticketAttachment;
	}

	public void setTicketAttachment(TicketAttachment ticketAttachment) {
		this.ticketAttachment = ticketAttachment;
	}

	public ServiceNowTicket getServiceNowTicket() {
		return serviceNowTicket;
	}

	public void setServiceNowTicket(ServiceNowTicket serviceNowTicket) {
		this.serviceNowTicket = serviceNowTicket;
	}


	public String getDestination() {
		return Destination;
	}

	public void setDestination(String destination) {
		Destination = destination;
	}

	

	public Ticket getTicket() {
		return ticket;
	}

	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private int quantity;

	private OrderStatus status;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public OrderStatus getStatus() {
		return status;
	}

	public void setStatus(OrderStatus status) {
		this.status = status;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((orderId == null) ? 0 : orderId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		if (orderId == null) {
			if (other.orderId != null)
				return false;
		} else if (!orderId.equals(other.orderId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", productName=" + productName + ", quantity=" + quantity + ", status="
				+ status + "]";
	}

	

	
}