package com.htc.mediator.jmsSenderResponse.Dao;

import com.htc.mediator.jmsqueueticket.model.Order;

public interface JMSSenderResponsDao {
	public void acknowledgementCreatTicketIR(Order order) ;

	public void acknowledgementUpdateTicketOR(Order order);

	void acknowledgementCreatorTicketOR(Order order);
}
