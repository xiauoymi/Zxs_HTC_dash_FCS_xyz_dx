//package com.htc.mediator.jmsqueueticket.util;
//
//import org.apache.axis2.databinding.types.xsd.Base64Binary;
//
//import java.io.BufferedInputStream;
//
//
//import javax.activation.DataHandler;
//
//import org.apache.commons.codec.binary.Base64;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//public class ImageHelper {
//
//	static final Logger LOG = LoggerFactory.getLogger(ImageHelper.class);
//	
//	public static byte[] convertImagetoBytes(Object value){
//		
//		byte[] encoded =null;
//		
//		try {
//			DataHandler data =  ((Base64Binary)value).getBase64Binary();
//			if(data != null) {
//				BufferedInputStream in = new BufferedInputStream(data.getInputStream());
//				byte[] byteArray=org.apache.commons.io.IOUtils.toByteArray(in);
//				encoded = Base64.encodeBase64(byteArray);
//			}
//		} catch (Exception e) {
//			LOG.error("Converting Image to bytes Exception"+e.getStackTrace());
//		}
//		
//		return encoded;
//		
//	}
//	
//}
