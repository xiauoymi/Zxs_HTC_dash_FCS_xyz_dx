package com.htc.mediator.jmsqueueticket.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.ws.wsdl.wsdl11.Wsdl11Definition;

import com.htc.mediator.jmsSenderResponse.Dao.JMSSenderResponsDao;
import com.htc.mediator.jmsqueueticket.model.Order;
import com.htc.mediator.jmsqueueticket.model.ServiceNowTicket;
import com.htc.mediator.jmsqueueticket.model.Ticket;
import com.htc.mediator.jmsqueueticket.model.TicketAttachment;
import com.htc.mediator.jmsqueueticket.service.OrderService;

@Controller
public class AppController {

	@Autowired
	OrderService orderService;
	@Autowired
	JMSSenderResponsDao jmsSenderResponseDao;
	
	
	
	@RequestMapping(value = { "/", "/home" }, method = RequestMethod.GET)
	public String prepareProduct(ModelMap model) {
		return "index";
	}

	@RequestMapping(value = { "/createTicketOR" }, method = RequestMethod.POST)
	public @ResponseBody String createTicket(@RequestBody Ticket ticket)throws Exception {
		Order order=new Order();
		order.setTicket(ticket);
		String reponseStatus=orderService.createTicketOR(order);
		order.setDescription(reponseStatus);
		
	jmsSenderResponseDao.acknowledgementCreatorTicketOR(order);
		return reponseStatus;
		
	}
	
	@RequestMapping(value = { "/CreateTicketIR" }, method = RequestMethod.POST)
	public @ResponseBody String CreateTicketIR(@RequestBody ServiceNowTicket serviceNowTicket)throws Exception {
		
		Order order=new Order();
		order.setServiceNowTicket(serviceNowTicket);
		String reponseStatus=orderService.createTicketIR(order);
		jmsSenderResponseDao.acknowledgementCreatTicketIR(order);
		//model.addAttribute("success", "Order for " + order + " registered.");
		return reponseStatus;
	}
	
	@RequestMapping(value = { "/UpdateTicketIR" }, method = RequestMethod.POST)
	public @ResponseBody String UpdateTicketIR(@RequestBody ServiceNowTicket serviceNowTicket)throws Exception {
		
		Order order=new Order();
		order.setServiceNowTicket(serviceNowTicket);
		String reponseStatus=orderService.updateTicketIR(order);
		//jmsSenderResponseDao.acknowledgementCreatorTicket(order);
		//model.addAttribute("success", "Order for " + order + " registered.");
		return reponseStatus;
	}
	
	@RequestMapping(value = { "/updateTicketOR" }, method = RequestMethod.POST)
	public @ResponseBody String updateTicket(@RequestBody TicketAttachment  ticket)throws Exception {
		
		Order order=new Order();
		order.setTicketAttachment(ticket);
		String reponseStatus=orderService.updateTicketOR(order);
		order.setDescription(reponseStatus);
		jmsSenderResponseDao.acknowledgementCreatorTicketOR(order);
		//model.addAttribute("success", "Order for " + order + " registered.");
		return reponseStatus;
	}
	
	
	@RequestMapping(value = { "/uploadAttachment" }, method = RequestMethod.POST)
	public @ResponseBody String uploadAttachment(@RequestBody TicketAttachment ticketAttachment)throws Exception {
		
		Order order=new Order();
		order.setTicketAttachment(ticketAttachment);;
		String reponseStatus=orderService.uploadAttachment(order);
		order.setDescription(reponseStatus);
		//jmsSenderResponseDao.acknowledgementCreatorTicketOR(order);
		//model.addAttribute("success", "Order for " + order + " registered.");
		return reponseStatus;
	}
	
	
	@RequestMapping(value = { "/checkStatus" }, method = RequestMethod.GET)
	public String checkOrderStatus(ModelMap model) {
		model.addAttribute("orders", orderService.getAllOrders());
		return "orderStatus";
	}
}
