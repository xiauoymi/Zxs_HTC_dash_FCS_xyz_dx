package com.htc.mediator.jmsqueueticket.constants;

public class Constants {
   
	public static final String CREATE_TICKET_OR_REQUEST_JMS_SEND_QUE = "INSERT INTO jms_send_queue(que_order_id,ticket,status,Description,destination,source_ticket_number,client_name)VALUES (?,?,?,?,?,?,?)";
	public static final String UPDATE_TICKET_OR_REQUEST_JMS_SEND_QUE = "INSERT INTO jms_send_queue(que_order_id,ticket,status,Description,destination,source_ticket_number,client_name)VALUES (?,?,?,?,?,?,?)";
	public static final String CREATE_TICKET_IR_REQUEST_JMS_SEND_QUE = "INSERT INTO jms_send_queue(que_order_id,ticket,status,Description,destination,source_ticket_number,client_name,sys_id)VALUES (?,?,?,?,?,?,?,?)";
	public static final String UPDATE_TICKET_IR_REQUEST_JMS_SEND_QUE = "INSERT INTO jms_send_queue(que_order_id,ticket,status,Description,destination,source_ticket_number,client_name,sys_id)VALUES (?,?,?,?,?,?,?,?)";
}
