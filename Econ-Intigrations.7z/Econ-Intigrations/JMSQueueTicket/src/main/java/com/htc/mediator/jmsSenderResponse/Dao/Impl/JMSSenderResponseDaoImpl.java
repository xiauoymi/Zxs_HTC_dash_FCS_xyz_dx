package com.htc.mediator.jmsSenderResponse.Dao.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.htc.mediator.jmsSenderResponse.Dao.JMSSenderResponsDao;
import com.htc.mediator.jmsqueueticket.constants.Constants;
import com.htc.mediator.jmsqueueticket.model.Order;


@Repository
@Service("jmsSenderResponseDao")
public class JMSSenderResponseDaoImpl implements JMSSenderResponsDao {

	@Autowired
	DataSource datasource;
	
	
	@Override
	public void acknowledgementCreatorTicketOR(Order order) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement sendQue=null;
		PreparedStatement detail= null;
		ResultSet resultSet = null;
		try {
			connection = datasource.getConnection();
			sendQue = connection.prepareStatement(Constants.CREATE_TICKET_OR_REQUEST_JMS_SEND_QUE, Statement.RETURN_GENERATED_KEYS);
			sendQue.setString(1, order.getOrderId());
			sendQue.setString(2, order.getTicket().toString());
			sendQue.setString(3, order.getStatus().getStatus());
			sendQue.setString(4, order.getDescription());
			sendQue.setString(5, order.getDestination());
			sendQue.setString(6, order.getTicket().getCase_Number());
			sendQue.setString(7, order.getTicket().getClient_ID());
			sendQue.executeUpdate();
			
			resultSet = sendQue.getGeneratedKeys();
			while(resultSet.next()){
				
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try { if (resultSet != null && !resultSet.isClosed()) resultSet.close(); } catch (Exception e) {};
		    try { if (sendQue != null && !sendQue.isClosed()) sendQue.close(); } catch (Exception e) {};
		    try { if (detail != null && !detail.isClosed()) detail.close(); } catch (Exception e) {};
		    try { if (connection != null && !connection.isClosed()) connection.close(); } catch (Exception e) {};
		}
		
		
	}
	
	@Override
	public void acknowledgementUpdateTicketOR(Order order) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement sendQue=null;
		PreparedStatement detail= null;
		ResultSet resultSet = null;
		try {
			connection = datasource.getConnection();
			sendQue = connection.prepareStatement(Constants.UPDATE_TICKET_OR_REQUEST_JMS_SEND_QUE, Statement.RETURN_GENERATED_KEYS);
			sendQue.setString(1, order.getOrderId());
			sendQue.setString(2, order.getTicket().toString());
			sendQue.setString(3, order.getStatus().getStatus());
			sendQue.setString(4, order.getDescription());
			sendQue.setString(5, order.getDestination());
			sendQue.setString(6, order.getTicket().getCase_Number());
			sendQue.setString(7, order.getTicket().getClient_ID());
			sendQue.executeUpdate();
			
			resultSet = sendQue.getGeneratedKeys();
			while(resultSet.next()){
				
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try { if (resultSet != null && !resultSet.isClosed()) resultSet.close(); } catch (Exception e) {};
		    try { if (sendQue != null && !sendQue.isClosed()) sendQue.close(); } catch (Exception e) {};
		    try { if (detail != null && !detail.isClosed()) detail.close(); } catch (Exception e) {};
		    try { if (connection != null && !connection.isClosed()) connection.close(); } catch (Exception e) {};
		}
		
		
	}

	@Override
	public void acknowledgementCreatTicketIR(Order order) {
		// TODO Auto-generated method stub
				Connection connection = null;
				PreparedStatement sendQue=null;
				PreparedStatement detail= null;
				ResultSet resultSet = null;
				try {
					connection = datasource.getConnection();
					sendQue = connection.prepareStatement(Constants.CREATE_TICKET_IR_REQUEST_JMS_SEND_QUE, Statement.RETURN_GENERATED_KEYS);
					sendQue.setString(1, order.getOrderId());
					sendQue.setString(2, order.getServiceNowTicket().toString());
					sendQue.setString(3, order.getStatus().getStatus());
					sendQue.setString(4, order.getDescription());
					sendQue.setString(5, order.getDestination());
					sendQue.setString(6, order.getServiceNowTicket().getNumber());
					sendQue.setString(7, "MIAMI");
					sendQue.setString(8, order.getServiceNowTicket().getSys_id());
					sendQue.executeUpdate();
					
					resultSet = sendQue.getGeneratedKeys();
					while(resultSet.next()){
						
					}
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}finally{
					try { if (resultSet != null && !resultSet.isClosed()) resultSet.close(); } catch (Exception e) {};
				    try { if (sendQue != null && !sendQue.isClosed()) sendQue.close(); } catch (Exception e) {};
				    try { if (detail != null && !detail.isClosed()) detail.close(); } catch (Exception e) {};
				    try { if (connection != null && !connection.isClosed()) connection.close(); } catch (Exception e) {};
				}
	}

}
