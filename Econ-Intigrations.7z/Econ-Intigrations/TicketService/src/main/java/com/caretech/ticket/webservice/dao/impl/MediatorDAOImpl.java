package com.caretech.ticket.webservice.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.caretech.ticket.webservice.dao.MediatorDAO;
import com.caretech.ticketwebservice.constants.Constants;

/**
 * @author thilak
 *
 */
public class MediatorDAOImpl implements MediatorDAO {
	
	DataSource datasource;
	
	public void setDataSource(DataSource dataSource) {
		this.datasource = dataSource;
	}
	
	
	Logger log = Logger.getLogger(MediatorDAOImpl.class.getName());
	//DatabaseManager datasource = new DatabaseManager();
	

	/**
	 * @param requestParameters
	 * @throws Exception
	 */

	public void requestCreateTicketORLog(HashMap<String , String> databaseParams) {
		System.out.println("database parammm****************"+databaseParams);
		Connection connection = null;
		PreparedStatement endpointStatement= null;
		int endpointResultSet;
		try {
			connection = datasource.getConnection();
			
			endpointStatement = connection.prepareStatement(Constants.CREATE_TICKET_OR_REQUEST_SUMMARY_QUERY);
			endpointStatement.setString(1, databaseParams.get(Constants.REMEDY_TICKET_NUMBER));
			endpointStatement.setString(2, databaseParams.get(Constants.CLIENT_ID));
			endpointStatement.setString(3, databaseParams.get(Constants.REQUEST_TYPE));
			endpointStatement.setString(4, databaseParams.get(Constants.REQUESTPARAMETER));
			endpointStatement.setString(5, databaseParams.get(Constants.ENDPOINT_INTIME));
			endpointResultSet=endpointStatement.executeUpdate();
			
			
			
			
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage());
			e.printStackTrace();
		}finally{
			 try { if (endpointStatement != null && !endpointStatement.isClosed()) endpointStatement.close(); } catch (Exception e) {};
		    try { if (connection != null && !connection.isClosed()) connection.close(); } catch (Exception e) {};
		}
	}


	@Override
	public void requestUpdateTicketORLog(HashMap<String, String> databaseParams) {
		// TODO Auto-generated method stub
		System.out.println("database parammm****************"+databaseParams);
		Connection connection = null;
		PreparedStatement endpointStatement= null;
		int endpointResultSet;
		try {
			connection = datasource.getConnection();
			
			endpointStatement = connection.prepareStatement(Constants.UPDATE_TICKET_OR_REQUEST_SUMMARY_QUERY);
			endpointStatement.setString(1, databaseParams.get(Constants.REMEDY_TICKET_NUMBER));
			endpointStatement.setString(2, databaseParams.get(Constants.CLIENT_ID));
			endpointStatement.setString(3, databaseParams.get(Constants.REQUEST_TYPE));
			endpointStatement.setString(4, databaseParams.get(Constants.REQUESTPARAMETER));
			endpointStatement.setString(5, databaseParams.get(Constants.ENDPOINT_INTIME));
			endpointResultSet=endpointStatement.executeUpdate();
			
			
			
			
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage());
			e.printStackTrace();
		}finally{
			 try { if (endpointStatement != null && !endpointStatement.isClosed()) endpointStatement.close(); } catch (Exception e) {};
		    try { if (connection != null && !connection.isClosed()) connection.close(); } catch (Exception e) {};
		}
		
	}
	
}
