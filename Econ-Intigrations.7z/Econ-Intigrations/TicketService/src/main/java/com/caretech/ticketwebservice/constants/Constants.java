package com.caretech.ticketwebservice.constants;

/**
 * @author gopinathn
 *
 */ 
public class Constants {
	
	public static final String CREATE_TICKET_OR_REQUEST_SUMMARY_QUERY = "INSERT INTO ts_endpoint_log(remedy_ticket_number, client_id, requestType,requestParameter,endPointInTime)VALUES (?, ?, ?, ?, ?)";
	public static final String UPDATE_TICKET_OR_REQUEST_SUMMARY_QUERY = "INSERT INTO ts_endpoint_log(remedy_ticket_number, client_id, requestType,requestParameter,endPointInTime)VALUES (?, ?, ?, ?, ?)";
	
	
	
	public static final String REQUESTPARAMETER="requestParameter"; 
	public static final String CLIENT_ID="client_Id"; 
	public static final String REQUEST_TYPE="request_Type"; 
	public static final String REMEDY_TICKET_NUMBER="remedy_Ticket"; 
	public static final String ENDPOINT_INTIME="endPoint_InTime"; 
	public static final String CREATETICKETORTARGET="createTicketOR";
	public static final String CREATETICKETOR_SYNC_TARGET="createTicketOR";
	public static final String UPDATETICKETORTARGET="updateTicketOR";
	public static final String UPLOADATTACHMENTTARGET="uploadAttachment";
    public static final String CREATETICKETOR_ENDPOINT_NAMESPACE="http://controller.webservice.ticket.caretech.com/create";
    public static final String CREATETICKETOR_ENDPOINT_LOCALPART="insertTicket";
    public static final String UPDATETICKETOR_ENDPOINT_NAMESPACE="http://controller.webservice.ticket.caretech.com/update";
    public static final String UPDATETICKETOR_ENDPOINT_LOCALPART="updateTicket";
    public static final String UPLOLADATTACHMENT_ENDPOINT_NAMESPACE="http://controller.webservice.ticket.caretech.com/create";
    public static final String UPLOLADATTACHMENT_ENDPOINT_LOCALPART="uploadAttachment";
	
}
