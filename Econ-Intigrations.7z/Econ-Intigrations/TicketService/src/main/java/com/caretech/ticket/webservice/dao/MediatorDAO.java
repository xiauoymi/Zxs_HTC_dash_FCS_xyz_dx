package com.caretech.ticket.webservice.dao;

import java.util.HashMap;

public interface MediatorDAO {
	
	public void requestCreateTicketORLog(HashMap<String, String> databaseParams) ;
	public void requestUpdateTicketORLog(HashMap<String, String> databaseParams) ;
	
	
	
}
