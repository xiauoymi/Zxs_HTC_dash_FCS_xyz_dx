package com.caretech.ticket.webservice.endpoint;


import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import com.fasterxml.jackson.databind.ObjectMapper;



import com.caretech.ticket.webservice.model.create.Response;
import com.caretech.ticket.webservice.model.create.Ticket;
import com.caretech.ticket.webservice.model.create.TicketAttachment;

public class JMSProcessor {

	public Response createTicketOR(Ticket ticket, String target) {
		String responseData = "";
		String incidentData = ticket.toString();
		String syn_URL="http://localhost:8080/JMSQueueTicketResponse/"+target;
		String async_URL="http://localhost:8080/JMSQueueTicket/"+target;
		CloseableHttpClient httpclient = HttpClients.custom().build();
		ObjectMapper objectMapper =new ObjectMapper();
		Response responseObject=null;

		try {
			
			//HttpPost httpPost = new HttpPost(async_URL);
			HttpPost httpPost = new HttpPost(syn_URL);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-Type", "application/json");
			HttpEntity entity = new ByteArrayEntity(
					incidentData.getBytes("utf-8"));
			httpPost.setEntity(entity);
			// System.out.println("Executing request " +
			// httpPost.getRequestLine());
			CloseableHttpResponse response = httpclient.execute(httpPost);
			try {
				responseObject=objectMapper.readValue(EntityUtils.toString(response.getEntity()), Response.class);
				responseData = EntityUtils.toString(response.getEntity());
				// System.out.println(responseData);
			} catch (Exception e) {
				responseData = e.getLocalizedMessage();
				// e.printStackTrace();
			} finally {
				response.close();
			}
			httpclient.close();
		} catch (Exception e) {
			responseData = e.getLocalizedMessage();

			e.printStackTrace();
		}
		return responseObject;
		
	
		
	}

	public String updateTicketOR(
			com.caretech.ticket.webservice.model.update.Ticket ticket,
			String target) {
		String responseData = "";
		String incidentData = ticket.toString();
		CloseableHttpClient httpclient = HttpClients.custom().build();

		try {

			HttpPost httpPost = new HttpPost(
					"http://localhost:8080/JMSQueueTicket/" + target);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-Type", "application/json");
			HttpEntity entity = new ByteArrayEntity(
					incidentData.getBytes("utf-8"));
			httpPost.setEntity(entity);
			// System.out.println("Executing request " +
			// httpPost.getRequestLine());
			CloseableHttpResponse response = httpclient.execute(httpPost);
			try {
				responseData = EntityUtils.toString(response.getEntity());
				// System.out.println(responseData);
			} catch (Exception e) {
				responseData = e.getLocalizedMessage();
				// e.printStackTrace();
			} finally {
				response.close();
			}
			httpclient.close();
		} catch (Exception e) {
			responseData = e.getLocalizedMessage();

			e.printStackTrace();
		}
		return responseData;
	}


	public String uploadeAttachment(TicketAttachment ticket, String target) {
		String responseData = "";
		String incidentData = ticket.toString();
		CloseableHttpClient httpclient = HttpClients.custom().build();

		try {

			HttpPost httpPost = new HttpPost(
					"http://localhost:8080/JMSQueueTicket/" + target);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-Type", "application/json");
			HttpEntity entity = new ByteArrayEntity(
					incidentData.getBytes("utf-8"));
			httpPost.setEntity(entity);
			// System.out.println("Executing request " +
			// httpPost.getRequestLine());
			CloseableHttpResponse response = httpclient.execute(httpPost);
			try {
				responseData = EntityUtils.toString(response.getEntity());
				// System.out.println(responseData);
			} catch (Exception e) {
				responseData = e.getLocalizedMessage();
				// e.printStackTrace();
			} finally {
				response.close();
			}
			httpclient.close();
		} catch (Exception e) {
			responseData = e.getLocalizedMessage();

			e.printStackTrace();
		}
		return responseData;
	}

	
}
