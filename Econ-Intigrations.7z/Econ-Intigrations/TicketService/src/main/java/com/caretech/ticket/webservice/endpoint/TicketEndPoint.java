package com.caretech.ticket.webservice.endpoint;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;



import javax.xml.bind.JAXBElement;
import javax.xml.ws.http.HTTPException;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;


import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.caretech.ticket.webservice.controller.create.InsertTicket;
import com.caretech.ticket.webservice.controller.create.InsertTicketResponse;
import com.caretech.ticket.webservice.controller.create.ObjectFactory;
import com.caretech.ticket.webservice.controller.create.UploadAttachment;
import com.caretech.ticket.webservice.controller.create.UploadAttachmentResponse;
import com.caretech.ticket.webservice.controller.update.UpdateTicket;
import com.caretech.ticket.webservice.controller.update.UpdateTicketResponse;
import com.caretech.ticket.webservice.dao.MediatorDAO;
import com.caretech.ticket.webservice.model.create.Response;
import com.caretech.ticket.webservice.model.create.TicketAttachment;
import com.caretech.ticketwebservice.constants.Constants;



@Endpoint
public class TicketEndPoint {

	@Autowired
	MediatorDAO mediatorDao;
	
	
	private JMSProcessor jmsProcessor = new JMSProcessor();

	@PayloadRoot(namespace = Constants.CREATETICKETOR_ENDPOINT_NAMESPACE, localPart = Constants.CREATETICKETOR_ENDPOINT_LOCALPART)
	@ResponsePayload
	public InsertTicketResponse insertTicket(
			@RequestPayload InsertTicket request) throws ParseException {

		InsertTicketResponse response = null;
		try {
			
			HashMap<String,String> databaseParams=new HashMap<>();
			
			com.caretech.ticket.webservice.model.create.Ticket ticket=request.getTicket().getValue();
			java.util.Date date = new java.util.Date();
			Date sqlDate = new Date((date).getTime());
			Timestamp inTimeToEndPoint = new Timestamp(sqlDate.getTime());
			
			databaseParams.put(Constants.REQUESTPARAMETER, ticket.toString());
			databaseParams.put(Constants.REMEDY_TICKET_NUMBER, ticket.getCTS_Ticket());
			databaseParams.put(Constants.CLIENT_ID, ticket.getClient_ID());
			databaseParams.put(Constants.REQUEST_TYPE, ticket.getServiceName());
			databaseParams.put(Constants.ENDPOINT_INTIME, inTimeToEndPoint.toString());
			
			mediatorDao.requestCreateTicketORLog(databaseParams);
			databaseParams.clear();
			
			
			//String responseData = jmsProcessor.createTicketOR(ticket,Constants.CREATETICKETORTARGET);
			Response responseData = jmsProcessor.createTicketOR(ticket,Constants.CREATETICKETOR_SYNC_TARGET);
			
			JSONParser parser = new JSONParser(); 
			JSONObject json = (JSONObject) parser.parse(responseData.getResult());
			String remedyNumber="";
			if(null!=json){
				remedyNumber=json.get("number").toString();
			}
			
			ObjectFactory factory = new ObjectFactory();
			com.caretech.ticket.webservice.model.create.ObjectFactory model_factory = new com.caretech.ticket.webservice.model.create.ObjectFactory();
			response = factory.createInsertTicketResponse();
			com.caretech.ticket.webservice.model.create.Response res = new com.caretech.ticket.webservice.model.create.Response();
			res.setStatus("SUCCESS");
		    res.setResult(remedyNumber);
			System.out.println("number-----------------+++===="+remedyNumber);
			JAXBElement<com.caretech.ticket.webservice.model.create.Response> model_response = factory.createInsertTicketResponseReturn(res);
			response.setReturn(model_response);
		} catch (HTTPException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return response;
	}

	@PayloadRoot(namespace = Constants.UPDATETICKETOR_ENDPOINT_NAMESPACE, localPart = Constants.UPDATETICKETOR_ENDPOINT_LOCALPART)
	@ResponsePayload
	public UpdateTicketResponse updateTicket(
			@RequestPayload UpdateTicket request) {

		UpdateTicketResponse response = null;
		try {
			
HashMap<String,String> databaseParams=new HashMap<>();
			
            com.caretech.ticket.webservice.model.update.Ticket ticket=request.getTicket().getValue();
			java.util.Date date = new java.util.Date();
			Date sqlDate = new Date((date).getTime());
			Timestamp inTimeToEndPoint = new Timestamp(sqlDate.getTime());
			
			databaseParams.put(Constants.REQUESTPARAMETER, ticket.toString());
			databaseParams.put(Constants.REMEDY_TICKET_NUMBER, ticket.getCTS_Ticket());
			databaseParams.put(Constants.CLIENT_ID, ticket.getClient_ID());
			databaseParams.put(Constants.REQUEST_TYPE, ticket.getServiceName());
			databaseParams.put(Constants.ENDPOINT_INTIME, inTimeToEndPoint.toString());
			
			mediatorDao.requestCreateTicketORLog(databaseParams);
			databaseParams.clear();
			
			
			String responseData = jmsProcessor.updateTicketOR(request.getTicket().getValue(), Constants.UPDATETICKETORTARGET);
			
			
			com.caretech.ticket.webservice.controller.update.ObjectFactory factory = new com.caretech.ticket.webservice.controller.update.ObjectFactory();
			com.caretech.ticket.webservice.model.update.ObjectFactory model_factory = new com.caretech.ticket.webservice.model.update.ObjectFactory();
			response = factory.createUpdateTicketResponse();
			com.caretech.ticket.webservice.model.update.Response res = new com.caretech.ticket.webservice.model.update.Response();
			res.setResult(responseData);
			JAXBElement<com.caretech.ticket.webservice.model.update.Response> model_response = factory.createUpdateTicketResponseReturn(res);
			response.setReturn(model_response);
		} catch (HTTPException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return response;
	}
	
	@PayloadRoot(namespace = Constants.UPLOLADATTACHMENT_ENDPOINT_NAMESPACE, localPart = Constants.UPLOLADATTACHMENT_ENDPOINT_LOCALPART)

    @ResponsePayload

    public UploadAttachmentResponse uploadAttachment(

                  @RequestPayload UploadAttachment attachment) {



           UploadAttachmentResponse response = null;

           try {
        	   HashMap<String,String> databaseParams=new HashMap<>();

        	   TicketAttachment ticket=attachment.getAttachment().getValue();
        	   
        	   java.util.Date date = new java.util.Date();
   			Date sqlDate = new Date((date).getTime());
   			Timestamp inTimeToEndPoint = new Timestamp(sqlDate.getTime());
   			
   			databaseParams.put(Constants.REQUESTPARAMETER, ticket.toString());
   			databaseParams.put(Constants.REMEDY_TICKET_NUMBER, ticket.getCTS_Ticket__c());
   		//	databaseParams.put(Constants.CLIENT_ID, ticket.getClient_ID());
   			databaseParams.put(Constants.REQUEST_TYPE, ticket.getServiceName());
   			databaseParams.put(Constants.ENDPOINT_INTIME, inTimeToEndPoint.toString());
   			
   			mediatorDao.requestCreateTicketORLog(databaseParams);
   			databaseParams.clear();
   			
        	   
        	   
                  String responseData = jmsProcessor.uploadeAttachment(attachment.getAttachment().getValue(), Constants.UPLOADATTACHMENTTARGET);

                  ObjectFactory factory = new ObjectFactory();

                  com.caretech.ticket.webservice.model.create.ObjectFactory model_factory = new com.caretech.ticket.webservice.model.create.ObjectFactory();

                  response = factory.createUploadAttachmentResponse();

                  /*com.caretech.ticket.webservice.model.create.Response res = new com.caretech.ticket.webservice.model.create.Response();

                  res.setResult(model_factory.createResponseResult(responseData));

                  JAXBElement<com.caretech.ticket.webservice.model.create.Response> model_response = factory.createInsertTicketResponseReturn(res);

                  response.setReturn(model_response);*/

           } catch (HTTPException e) {

                  // TODO Auto-generated catch block

                  e.printStackTrace();

           }

           return response;

    }

}