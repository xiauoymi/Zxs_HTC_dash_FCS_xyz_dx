//package com.htc.mediator.jmsqueueticketresponse.service;
//
//import static org.junit.Assert.*;
//
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//import org.springframework.test.context.support.AnnotationConfigContextLoader;
//
//import com.htc.mediator.jmsqueueticketresponse.configuration.AppConfigTest;
//import com.htc.mediator.jmsqueueticketresponse.messaging.MessageReceiver;
//
//@RunWith(SpringJUnit4ClassRunner.class)
////ApplicationContext will be loaded from the OrderServiceConfig class
//@ContextConfiguration(classes=AppConfigTest.class, loader=AnnotationConfigContextLoader.class)
//public class OrderInventoryServiceImplTest {
//
//	@Autowired
//	MessageReceiver messageReceiver;
//	
//	@Test
//	public void testGetOrderFromQueue() {
//		
//		System.out.println("Message count "+ messageReceiver.getLatch());
//		
//		
//		messageReceiver.testOrder();
//	}
//
//}
