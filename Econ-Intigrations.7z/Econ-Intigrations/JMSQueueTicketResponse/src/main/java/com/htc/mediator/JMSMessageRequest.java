package com.htc.mediator;

import java.util.Map;

import com.htc.mediator.jmsqueueticket.model.Order;

public interface JMSMessageRequest {
	public Map<String, Object> processRequest(Order order) ;

}
