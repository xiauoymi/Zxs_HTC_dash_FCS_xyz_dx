package com.htc.mediator.service.impl;

import java.net.InetAddress;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.caretech.mediator.datamapping.exception.IncidentException;
import com.caretech.mediator.datamapping.processor.JSONProcessor;
import com.caretech.mediator.helper.NotificationHelper;
import com.caretech.mediator.model.Response;
import com.caretech.mediator.service.TicketService;
import com.caretech.mediator.utils.Utilities;
import com.htc.mediator.MessageParameters;
import com.htc.mediator.constants.Constants;
import com.htc.mediator.dao.MediatorDAO;
import com.htc.mediator.service.MediatorService;


@Service("mediatorService")
public class MediatorServiceImpl implements MediatorService {

	
	@Autowired
	TicketService ticketService;
	@Autowired
	MediatorDAO mediatorDao;
	
	
	private String requestMessageId;
	private String remedyNumber;
	private String snowNumber;
	private String serverIp;
	
	//private String requestParameter;
	private String responseMessageId;
	private String responseparameter;
	private String ticketNumber;
	private String status;
	
	
	private static JSONProcessor jsonProcessor = new JSONProcessor();

	private static NotificationHelper notificationHelper = new NotificationHelper();

	Logger log = Logger.getLogger(MediatorServiceImpl.class.getName());
	private HashMap<String, String> parameters = new HashMap<String, String>();

	
	public String destinationService(String serviceName){
		return mediatorDao.destinationService(serviceName, clientName(Constants.CLIENT_ID));		
	}
	
	public String clientName(String clientId){
		return mediatorDao.clientName(clientId);
	}
	
	
	@Override
	public Map<String, Object> requestCreateTicketOR(MessageParameters context) {

		Map<String, Object> requestParameter = context.getRequestData();
		Map<String, Object> resposeParameter = context.getRequestData();
		String parameter = null;
		try {

			Date startTime = new Date();
			log.info("CareTechService: createincident starts : "
					+ Utilities.getCurrentDateTime(startTime));
			log.info("CareTechService: createincident parameters : "
					+ context.getRequestData());
			Response restResponse = new Response();
			java.util.Date inDate = new java.util.Date();
			Date sqlInDate = new Date((inDate).getTime());
			Timestamp inTimeToESB = new Timestamp(sqlInDate.getTime());
			Timestamp inTimeToSNOW = new Timestamp(sqlInDate.getTime());
			try {
				parameter = ticketService.createIncident(context
						.getRequestData());
				restResponse.setStatus("SUCCESS");
				JSONParser parser = new JSONParser(); 
				JSONObject json = (JSONObject) parser.parse(parameter);

				if(null!=json){
					JSONProcessor jsonProccessor=new JSONProcessor();
					resposeParameter=jsonProccessor.getInputJsonAsMap(json.get("result").toString());
					resposeParameter.put("responseParam", json.get("result").toString());
				}
				
			} catch (IncidentException e) {
				restResponse.setStatus("FAILURE");
				restResponse.setErrorCode(e.getErrorCode());
				restResponse.setErrorDesc(e.getErrorMessage());

				parameters.put("errorCode", e.getErrorCode());
				parameters.put("errorDesc", e.getErrorMessage());
				parameters.put("serviceName", "CreateTicketOR : insertTicket");
				parameters.put("params", requestParameter.toString());
				notificationHelper.sendNotification(parameters);
			}

			
			Date endTime = new Date();
			log.info("CareTechService: createticket ends : "
					+ Utilities.getCurrentDateTime(endTime));
			log.info("CareTechService: createticket duration : "
					+ Utilities.getTimeDifference(startTime, endTime));

			HashMap<String, Object> databaseParams = new HashMap<String, Object>();
			
			java.util.Date Date = new java.util.Date();
			Date sqlDate = new Date((Date).getTime());
			// Long inTimeMilliSec = Long.valueOf((String)
			// context.getProperty(Constants.PROPERTY_INTIME));
			Timestamp outTimeFromESB = new Timestamp(sqlDate.getTime());
			Timestamp outTimeFromSNOW = new Timestamp(sqlDate.getTime());
			 requestMessageId = (String)
			 context.getProperty(Constants.PROPERTY_REQUEST_MESSAGE_ID);
		// requestParameter = (String)
		//context.getProperty(Constants.PROPERTY_REQUEST_PARAMETER);
			remedyNumber = (String) context
					.getProperty(Constants.PROPERTY_REMEDY_TICKET);
			serverIp = InetAddress.getLocalHost().getHostAddress();

			if(restResponse.getStatus()=="FAILED"){
				databaseParams.put(Constants.ERROR_CODE,parameters.get("errorCode"));
				databaseParams.put(Constants.ERROR_DESC,parameters.get("errorDesc"));
			}
			databaseParams.put(Constants.SYS_ID,resposeParameter.get("sys_id"));
			databaseParams.put(Constants.DESTINATION_TICKETNUMBER,resposeParameter.get("number"));
			databaseParams.put(Constants.PARAM_SOURCE,
					Constants.SERVICENAME_CREATE_TICKET_OR);
			databaseParams.put(Constants.PARAM_REQUEST_MESSAGE_ID,
					requestMessageId);
			databaseParams.put(Constants.PARAM_REMEDY_TICKET_NUMBER,
					remedyNumber);
			databaseParams.put(Constants.RESPONSE_STATUS,
					restResponse.getStatus());
			databaseParams.put(Constants.PARAM_INTIME_TO_ESB, inTimeToESB);
			databaseParams.put(Constants.PARAM_INTIME_TO_SNOW, inTimeToSNOW);
			databaseParams.put(Constants.PARAM_OUTTIME_FROM_ESB, outTimeFromESB);
			databaseParams.put(Constants.PARAM_OUTTIME_FROM_SNOW, outTimeFromSNOW);
			databaseParams.put(Constants.PARAM_DESTINATION,destinationService(Constants.SERVICENAME_CREATE_TICKET_OR));
			databaseParams.put(Constants.PARAM_CLIENT_NAME,clientName(Constants.CLIENT_ID));
			databaseParams.put(Constants.PARAM_CLIENT_NAME, "MIA1");
			databaseParams.put(Constants.PARAM_SERVER_IP, serverIp);
			databaseParams.put(Constants.PARAM_REMEDY_TICKET_ORDER_NUMBER, context.getJmsSendQueOrderId());
			

			databaseParams.put(Constants.PARAM_REQUEST_PARAMETER,
					requestParameter);
			 mediatorDao.requestCreateTicketORLog(databaseParams);
			databaseParams.clear();

		} catch (Exception e) {
			log.error(e.getMessage());
			e.printStackTrace();
		}
		return resposeParameter;
	}
	
	
	/**
	 * @param MessageContext
	 * @return 
	 */
	
	public Map<String, Object> requestUpdateTicketOR(MessageParameters context) {
		
		String requestParameter= context.getRequestData().toString();
	//	String restRes =  null;
		Map<String, Object> parameter =  new HashMap<String, Object>();
		Map<String, Object> responseParameter =  new HashMap<String, Object>();
		java.util.Date inDate = new java.util.Date();
		Date sqlInDate = new Date((inDate).getTime());
		Timestamp inTimeToESB = new Timestamp(sqlInDate.getTime());
		Timestamp inTimeToSNOW = new Timestamp(sqlInDate.getTime());
		try {
			

			Date startTime = new Date();
			log.info("CareTechService: updateStatus starts : " + Utilities.getCurrentDateTime(startTime));
			log.info("CareTechService: updateStatus parameters : " + requestParameter);

			Response restResponse = new Response();
			try {
				parameter = ticketService.updateIncidentStatus(context.getRequestData());
				 JSONParser parser = new JSONParser(); 
					JSONObject json = (JSONObject) parser.parse(parameter.get("requestParm").toString());

					if(null!=json){
						JSONProcessor jsonProccessor=new JSONProcessor();
						responseParameter=jsonProccessor.getInputJsonAsMap(json.toString());
					}
				
			} catch (IncidentException e) {
				restResponse.setStatus("FAILED");
				restResponse.setErrorCode(e.getErrorCode());
				restResponse.setErrorDesc(e.getErrorMessage());
				
				parameters.put("errorCode", e.getErrorCode());
				parameters.put("errorDesc", e.getErrorMessage());
				parameters.put("serviceName", "UpdateTicketOR");
				parameters.put("params", requestParameter.toString());
				notificationHelper.sendNotification(parameters);
			}

			Date endTime = new Date();
			log.info("CareTechService: updateStatus ends : " + Utilities.getCurrentDateTime(endTime));
			log.info("CareTechService: updateStatus duration : " + Utilities.getTimeDifference(startTime, endTime));
			String Status = (String) parameter.get("status");
			HashMap< String, Object> databaseParams = new HashMap<String, Object>();
			java.util.Date date= new java.util.Date();
			Date sqlDate = new Date((date).getTime());	
			//Long inTimeMilliSec = Long.valueOf((String)context.getProperty(Constants.PROPERTY_INTIME));
			//Timestamp inTimeToESB= new Timestamp(inTimeMilliSec) ;
			
			Timestamp outTimeFromESB = new Timestamp(sqlDate.getTime());
			Timestamp outTimeFromSNOW= new Timestamp(sqlDate.getTime());	
			requestMessageId= (String)context.getProperty(Constants.PROPERTY_REQUEST_MESSAGE_ID);
			requestParameter= (String)context.getProperty(Constants.PROPERTY_REQUEST_PARAMETER);
			remedyNumber = (String)context.getProperty(Constants.PROPERTY_REMEDY_TICKET);
			serverIp= InetAddress.getLocalHost().getHostAddress();
			
			if(restResponse.getStatus()=="FAILED"){
				databaseParams.put(Constants.ERROR_CODE,parameters.get("errorCode"));
				databaseParams.put(Constants.ERROR_DESC,parameters.get("errorDesc"));
			}
			databaseParams.put(Constants.STATUS, Status);
			databaseParams.put(Constants.SYS_ID, (String)responseParameter.get("sys_id"));
			databaseParams.put(Constants.DESTINATION_TICKETNUMBER,(String)responseParameter.get("number"));
			databaseParams.put(Constants.PARAM_SOURCE, Constants.SERVICENAME_UPDATE_TICKET_OR);
			databaseParams.put(Constants.PARAM_REQUEST_MESSAGE_ID, requestMessageId);
			databaseParams.put(Constants.PARAM_INTIME_TO_ESB, inTimeToESB);
			databaseParams.put(Constants.PARAM_INTIME_TO_SNOW, inTimeToSNOW);
			databaseParams.put(Constants.PARAM_OUTTIME_FROM_ESB, outTimeFromESB);
			databaseParams.put(Constants.PARAM_OUTTIME_FROM_SNOW, outTimeFromSNOW);
			databaseParams.put(Constants.PARAM_REMEDY_TICKET_NUMBER, remedyNumber);
			databaseParams.put(Constants.PARAM_DESTINATION, destinationService(Constants.SERVICENAME_UPDATE_TICKET_OR));
			databaseParams.put(Constants.PARAM_CLIENT_NAME, clientName(Constants.CLIENT_ID));
			databaseParams.put(Constants.PARAM_SERVER_IP, serverIp);
			databaseParams.put(Constants.PARAM_REMEDY_TICKET_ORDER_NUMBER, context.getJmsSendQueOrderId());
			databaseParams.put(Constants.PARAM_REQUEST_PARAMETER, requestParameter);
			
			
			mediatorDao.requestUpdateTicketORLog(databaseParams);
			databaseParams.clear();
			
		} catch (Exception e) {
			log.error(e.getMessage());
			e.printStackTrace();
		}
		return responseParameter;		
	}

	

	public String requestCreateTicketIR(MessageParameters context) {
		String requestParameter= (String)context.getProperty(Constants.PROPERTY_REQUEST_PARAMETER);
		Response response = new Response();
		Map<String, Object>  requestParam = new HashMap<String, Object>();
		JSONProcessor jSONProcessor = new JSONProcessor();
	//	String restRes =  null;
		String jsonValue = null;

		try {

			Date startTime = new Date();
			log.info("CareTechService: createincident starts : " + Utilities.getCurrentDateTime(startTime));
			Response restResponse = new Response();
		try {
			response = ticketService.createTicket(requestParameter);
			requestParam.put("Status",response.getStatus());
			requestParam.put("Result",response.getOutput().getResult());
		   
		} catch (IncidentException e) {
			restResponse.setStatus("FAILED");
			restResponse.setErrorCode(e.getErrorCode());
			restResponse.setErrorDesc(e.getErrorMessage());
			requestParam.put("Status","FAILED");
			requestParam.put("Result", e.getErrorMessage());
			//requestParameter= removeAttachmentData((String)context.getProperty(Constants.PROPERTY_REQUEST_PARAMETER));
			parameters.put("errorCode", e.getErrorCode());
			parameters.put("errorDesc", e.getErrorMessage());
			parameters.put("serviceName", "CreateTicketIR");
			parameters.put("params", requestParameter);
			notificationHelper.sendNotification(parameters);
		}
		 jsonValue = jSONProcessor.getInputMapAsJson(requestParam);

		Date endTime = new Date();
		log.info("CareTechService: createincident ends : " + Utilities.getCurrentDateTime(endTime));
		log.info("CareTechService: createincident duration : " + Utilities.getTimeDifference(startTime, endTime));
	
		HashMap< String, Object> databaseParams = new HashMap<String, Object>();
		java.util.Date date= new java.util.Date();
		Date sqlDate = new Date((date).getTime());	
		Long inTimeMilliSec = Long.valueOf((String)context.getProperty(Constants.PROPERTY_INTIME));
		Timestamp inTimeToESB= new Timestamp(inTimeMilliSec) ;
		Timestamp inTimeToSNOW= new Timestamp(sqlDate.getTime()) ;
		requestMessageId= (String)context.getProperty(Constants.PROPERTY_REQUEST_MESSAGE_ID);
		//requestParameter= removeAttachmentData((String)context.getProperty(Constants.PROPERTY_REQUEST_PARAMETER));
		snowNumber = (String)context.getProperty(Constants.PROPERTY_SNOW_TICKET);
		serverIp= InetAddress.getLocalHost().getHostAddress();
		
		databaseParams.put(Constants.PARAM_SOURCE, Constants.SERVICENAME_CREATE_TICKET_IR);		
		databaseParams.put(Constants.PARAM_REQUEST_MESSAGE_ID, requestMessageId);
		databaseParams.put(Constants.PARAM_INTIME_TO_ESB, inTimeToESB);
		databaseParams.put(Constants.PARAM_INTIME_TO_SNOW, inTimeToSNOW);
		databaseParams.put(Constants.PARAM_DESTINATION, destinationService(Constants.SERVICENAME_CREATE_TICKET_IR));
		databaseParams.put(Constants.PARAM_SNOW_TICKET_NUMBER, snowNumber);
		databaseParams.put(Constants.PARAM_CLIENT_NAME,clientName(Constants.CLIENT_ID));
		databaseParams.put(Constants.PARAM_SERVER_IP, serverIp);
		databaseParams.put(Constants.RESPONSE, jsonValue);
		databaseParams.put(Constants.PARAM_ESB_OUT_TIME, new Timestamp(endTime.getTime()));
		databaseParams.put(Constants.PARAM_SNOW_OUT_TIME, new Timestamp(startTime.getTime()));
		databaseParams.put(Constants.PARAM_STATUS, requestParam.get("Status"));
		databaseParams.put(Constants.PARAM_REQUEST_PARAMETER, requestParameter);
		mediatorDao.requestUpdateTicketIRLog(databaseParams);
		databaseParams.clear();
		
			return jsonValue;
		} catch (Exception e) {
			log.error(e.getMessage());
			e.printStackTrace();
		}
		return jsonValue;		
	}
	
	
	
	@Override
	public Map<String,Object> requestUploadAttachment(MessageParameters context) {
		String requestParameter= (String)context.getProperty(Constants.PROPERTY_REQUEST_PARAMETER);
//		String restRes =  null;
		Map<String, Object> parameter =  new HashMap<String, Object>();
	//	Response response = new Response();
		try {

			Date startTime = new Date();
			log.info("CareTechService: uploadattachment starts : " +Utilities.getCurrentDateTime(startTime));

			Response restResponse = new Response();
			try {
				parameter = ticketService.uploadAttachments(requestParameter);
			} catch (IncidentException e) {
				restResponse.setStatus("FAILED");
				restResponse.setErrorCode(e.getErrorCode());
				restResponse.setErrorDesc(e.getErrorMessage());
				requestParameter= removeAttachmentData((String)context.getProperty(Constants.PROPERTY_REQUEST_PARAMETER));
				parameters.put("errorCode", e.getErrorCode());
				parameters.put("errorDesc", e.getErrorMessage());
				parameters.put("serviceName", "CreateTicketOR : uploadAttachment");
				parameters.put("params", requestParameter);
				///notificationHelper.sendNotification(parameters);
			}
			Date endTime = new Date();
			log.info("CareTechService: uploadattachment starts : " +Utilities.getCurrentDateTime(startTime));
			log.info("CareTechService: uploadattachment duration : " +Utilities.getTimeDifference(startTime, endTime));
			String status = (String) parameter.get("status");
			String message = (String) parameter.get("Error");
			HashMap< String, Object> databaseParams = new HashMap<String, Object>();
			java.util.Date date= new java.util.Date();
			Date sqlDate = new Date((date).getTime());	
			Long inTimeMilliSec = Long.valueOf((String)context.getProperty(Constants.PROPERTY_INTIME));
			Timestamp inTimeToESB= new Timestamp(inTimeMilliSec) ;
			Timestamp inTimeToSNOW= new Timestamp(sqlDate.getTime()) ;
			requestMessageId= (String)context.getProperty(Constants.PROPERTY_REQUEST_MESSAGE_ID);
			requestParameter= removeAttachmentData((String)context.getProperty(Constants.PROPERTY_REQUEST_PARAMETER));
			snowNumber = (String)context.getProperty(Constants.PROPERTY_SNOW_TICKET);
			remedyNumber = (String)context.getProperty(Constants.PROPERTY_REMEDY_TICKET);
			serverIp= InetAddress.getLocalHost().getHostAddress();
			
			if(status != null){
				databaseParams.put(Constants.STATUS, status);
				databaseParams.put(Constants.MESSAGE, message);
			}
			
			databaseParams.put(Constants.PARAM_SOURCE, Constants.SERVICENAME_UPLOAD_ATTACHMENT);		
			databaseParams.put(Constants.PARAM_REQUEST_MESSAGE_ID, requestMessageId);
			databaseParams.put(Constants.PARAM_INTIME_TO_ESB, inTimeToESB);
			databaseParams.put(Constants.PARAM_INTIME_TO_SNOW, inTimeToSNOW);
			databaseParams.put(Constants.PARAM_DESTINATION, destinationService(Constants.SERVICENAME_UPLOAD_ATTACHMENT));
			databaseParams.put(Constants.PARAM_REMEDY_TICKET_NUMBER, remedyNumber);
			databaseParams.put(Constants.PARAM_SNOW_TICKET_NUMBER, snowNumber);
			databaseParams.put(Constants.PARAM_CLIENT_NAME,clientName(Constants.CLIENT_ID));
			databaseParams.put(Constants.PARAM_SERVER_IP, serverIp);
			
			databaseParams.put(Constants.PARAM_REQUEST_PARAMETER, requestParameter);
			mediatorDao.requestUploadAttachmentLog(databaseParams);
			databaseParams.clear();
			return parameter;
		} catch (Exception e) {
			log.error(e.getMessage());
			e.printStackTrace();
		}
		return parameter;		
	}



	@Override
	public String requestUpdateTicketIR(MessageParameters context) {
		// TODO Auto-generated method stub
		String requestParameter= (String)context.getProperty(Constants.PROPERTY_REQUEST_PARAMETER);
		Response response = new Response();
		String jsonValue = null;
		Map<String, Object>  requestParam = new HashMap<String, Object>();
		JSONProcessor jSONProcessor = new JSONProcessor();
		try {

			Date startTime = new Date();
			log.info("CareTechService: updateincident starts : " + Utilities.getCurrentDateTime(startTime));
			//log.info("CareTechService: updateincident parameters : " + requestParameter);
			Response restResponse = new Response();
			try {
				 requestMessageId= (String)context.getProperty(Constants.PROPERTY_REQUEST_MESSAGE_ID);
				 response = ticketService.updateIncident(requestParameter, requestMessageId);
				 requestParam.put("Status",response.getStatus());
			     requestParam.put("Result",response.getOutput().getResult());
				
			} catch (IncidentException e) {
				restResponse.setStatus("FAILED");
				restResponse.setErrorCode(e.getErrorCode());
				restResponse.setErrorDesc(e.getErrorMessage());
				requestParam.put("Status","FAILED");
				requestParam.put("Result", e.getErrorMessage());
				requestParameter= removeAttachmentData((String)context.getProperty(Constants.PROPERTY_REQUEST_PARAMETER));
				parameters.put("errorCode", e.getErrorCode());
				parameters.put("errorDesc", e.getErrorMessage());
				parameters.put("serviceName", "UpdateTicketIR : updateTicket");
				parameters.put("params", requestParameter);
				notificationHelper.sendNotification(parameters);
			}
			 jsonValue = jSONProcessor.getInputMapAsJson(requestParam);
			Date endTime = new Date();
			log.info("CareTechService: updateincident ends : " + Utilities.getCurrentDateTime(endTime));
			log.info("CareTechService: updateincident duration : " + Utilities.getTimeDifference(startTime, endTime));
			
		
			
			
			HashMap< String, Object> databaseParams = new HashMap<String, Object>();
			java.util.Date date= new java.util.Date();
			Date sqlDate = new Date((date).getTime());	
			Long inTimeMilliSec = Long.valueOf((String)context.getProperty(Constants.PROPERTY_INTIME));
			Timestamp inTimeToESB= new Timestamp(inTimeMilliSec) ;
			Timestamp inTimeToSNOW= new Timestamp(sqlDate.getTime()) ;
			requestMessageId= (String)context.getProperty(Constants.PROPERTY_REQUEST_MESSAGE_ID);
			requestParameter= removeAttachmentData((String)context.getProperty(Constants.PROPERTY_REQUEST_PARAMETER));
			snowNumber = (String)context.getProperty(Constants.PROPERTY_SNOW_TICKET);
			remedyNumber = (String)context.getProperty(Constants.PROPERTY_REMEDY_TICKET);
			serverIp= InetAddress.getLocalHost().getHostAddress();
			
			databaseParams.put(Constants.PARAM_SOURCE, Constants.SERVICENAME_UPDATE_TICKET_IR);		
			databaseParams.put(Constants.PARAM_REQUEST_MESSAGE_ID, requestMessageId);
			databaseParams.put(Constants.PARAM_INTIME_TO_ESB, inTimeToESB);
			databaseParams.put(Constants.PARAM_INTIME_TO_SNOW, inTimeToSNOW);
			databaseParams.put(Constants.PARAM_DESTINATION, destinationService(Constants.SERVICENAME_UPDATE_TICKET_IR));
			databaseParams.put(Constants.PARAM_REMEDY_TICKET_NUMBER, remedyNumber);
			databaseParams.put(Constants.PARAM_SNOW_TICKET_NUMBER, snowNumber);
			databaseParams.put(Constants.PARAM_CLIENT_NAME,clientName(Constants.CLIENT_ID));
			databaseParams.put(Constants.PARAM_SERVER_IP, serverIp);
			databaseParams.put(Constants.PARAM_STATUS, requestParam.get("Status"));
			databaseParams.put(Constants.RESPONSE, jsonValue);
			databaseParams.put(Constants.PARAM_ESB_OUT_TIME, new Timestamp(endTime.getTime()));
			databaseParams.put(Constants.PARAM_SNOW_OUT_TIME, new Timestamp(startTime.getTime()));
			
			databaseParams.put(Constants.PARAM_REQUEST_PARAMETER, requestParameter);
			mediatorDao.requestUpdateTicketIRLog(databaseParams);
			databaseParams.clear();
			return jsonValue;
		} catch (Exception e) {
			log.error(e.getMessage());
			e.printStackTrace();
		}
		return jsonValue;		
	}

	@Override
	public String requestCreateDataSync(MessageParameters parameters) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String requestUpdateDataSync(MessageParameters parameters) {
		// TODO Auto-generated method stub
		return null;
	}
	
	/**
	 * @param JSON String
	 */
	private String removeAttachmentData(String jsonString){
		Map<String, Object> responseData;
		try {
			responseData = jsonProcessor.getInputJsonAsMap(jsonString);
			responseData.remove("Attachment_1_attachmentData");
			responseData.remove("Attachment_2_attachmentData");
			responseData.remove("Attachment_3_attachmentData");
			responseData.remove("Attachment_4_attachmentData");
			responseData.remove("Attachment_5_attachmentData");
			responseData.remove("attachment_1_attachmentData");
			responseData.remove("attachment_2_attachmentData");
			responseData.remove("attachment_3_attachmentData");
			responseData.remove("attachment_4_attachmentData");
			responseData.remove("attachment_5_attachmentData");
			
			jsonString = jsonProcessor.getInputMapAsJson(responseData);
		} catch (Exception e) {
			log.error(e.getMessage());
			e.printStackTrace();
		}
		return jsonString;
	}


}
