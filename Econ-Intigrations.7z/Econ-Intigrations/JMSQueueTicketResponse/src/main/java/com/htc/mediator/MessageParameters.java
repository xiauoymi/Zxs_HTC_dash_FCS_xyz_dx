package com.htc.mediator;

import java.util.HashMap;
import java.util.Map;

import com.caretech.ticket.webservice.model.TargetApplicationDTO;


public class MessageParameters {
	
	private HashMap<String, Object> map = new HashMap<String, Object>();
	
	private Map<String, Object> requestData = new HashMap<String, Object>();
	
	private TargetApplicationDTO targetApplication;
	private String jmsSendQueOrderId;
	
	
	public String getJmsSendQueOrderId() {
		return jmsSendQueOrderId;
	}

	public void setJmsSendQueOrderId(String jmsSendQueOrderId) {
		this.jmsSendQueOrderId = jmsSendQueOrderId;
	}

	public void setProperty(String key, Object value) {
		map.put(key, value);
	}

	public Object getProperty(String propertyRequestParameter) {
		return map.get(propertyRequestParameter);
	}

	public void setRequestData(Map<String, Object> requestData) {
		this.requestData = requestData;
	}

	public Map<String, Object> getRequestData() {
		return requestData;
	}

	public void setTargetApplication(TargetApplicationDTO targetApplication) {
		// TODO Auto-generated method stub
		this.targetApplication = targetApplication;
	}
	

	public TargetApplicationDTO getTargetApplication(){
		return targetApplication;
	}
	

}
