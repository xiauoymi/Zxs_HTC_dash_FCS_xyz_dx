package com.htc.mediator.jmsqueueticket.model;

import java.io.Serializable;



public class Order implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String orderId;
	
	private String productName;
	private String sys_id;
	private String remedyTicketID;
	private String externalTicketID;
	private Ticket ticket;
	private ServiceNowTicket serviceNowTicket; 
	private TicketAttachment ticketAttachment;
	
	
	
	public TicketAttachment getTicketAttachment() {
		return ticketAttachment;
	}

	public void setTicketAttachment(TicketAttachment ticketAttachment) {
		this.ticketAttachment = ticketAttachment;
	}

	public String getRemedyTicketID() {
		return remedyTicketID;
	}

	public void setRemedyTicketID(String remedyTicketID) {
		this.remedyTicketID = remedyTicketID;
	}

	public String getExternalTicketID() {
		return externalTicketID;
	}

	public void setExternalTicketID(String externalTicketID) {
		this.externalTicketID = externalTicketID;
	}

	public String getSys_id() {
		return sys_id;
	}

	public void setSys_id(String sys_id) {
		this.sys_id = sys_id;
	}

	
	

	public ServiceNowTicket getServiceNowTicket() {
		return serviceNowTicket;
	}

	public void setServiceNowTicket(ServiceNowTicket serviceNowTicket) {
		this.serviceNowTicket = serviceNowTicket;
	}

	public Ticket getTicket() {
		return ticket;
	}

	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private int quantity;

	private OrderStatus status;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public OrderStatus getStatus() {
		return status;
	}

	public void setStatus(OrderStatus status) {
		this.status = status;
	}

	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((orderId == null) ? 0 : orderId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		if (orderId == null) {
			if (other.orderId != null)
				return false;
		} else if (!orderId.equals(other.orderId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", productName=" + productName + ", quantity=" + quantity + ", status="
				+ status + "]";
	}

	
}