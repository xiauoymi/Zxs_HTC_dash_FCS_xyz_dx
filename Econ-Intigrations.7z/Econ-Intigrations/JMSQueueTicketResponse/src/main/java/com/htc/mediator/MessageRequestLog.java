package com.htc.mediator;


import java.net.Inet4Address;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.htc.mediator.constants.Constants;
import com.htc.mediator.jmsqueueticket.model.Order;
import com.htc.mediator.service.MediatorService;
import com.caretech.mediator.utils.Utilities;
import com.caretech.ticket.datamapping.processor.JSONProcessor;

@Service("jmsRequest")
public class MessageRequestLog implements JMSMessageRequest{

	Logger log = Logger.getLogger(MessageRequestLog.class.getName());
	
	
	@Autowired
	MediatorService mediatorService;
	
	@Override
	public Map<String, Object> processRequest(Order order) { 
		
		String responseData = null;
		String serviceName=null;
		Map<String, Object> requestMap=null;
		Map<String, Object> responseParameter=new HashMap<String,Object>();
		Map<String, Object> parameter=new HashMap<String,Object>();
		try {
			MessageParameters parameters = new MessageParameters();
			
			if(null!= order.getTicket())
			{
			 requestMap =Utilities.convertObjectToMap(order.getTicket());
			 
			 parameters.setProperty(Constants.PROPERTY_REMEDY_TICKET, requestMap.get("Case_Number"));
			
			}else if(null!= order.getServiceNowTicket()){
				 requestMap =Utilities.convertObjectToMap(order.getServiceNowTicket());
				 
				parameters.setProperty(Constants.PROPERTY_REMEDY_TICKET, requestMap.get("number"));
			}else if(null!= order.getTicketAttachment()){
				 requestMap =Utilities.convertObjectToMap(order.getTicketAttachment());
				 
					parameters.setProperty(Constants.PROPERTY_REMEDY_TICKET, requestMap.get("CTS_Ticket__c"));
			}
			 parameters.setRequestData(requestMap);
			 parameters.setProperty(Constants.PROPERTY_REQUEST_PARAMETER, requestMap.toString());
				parameters.setProperty(Constants.PROPERTY_INTIME, new Date().toString());
				 serviceName=  (String) requestMap.get(Constants.SERVICE_NAME);
			
			
				
			
			parameters.setProperty(Constants.PROPERTY_REQUEST_MESSAGE_ID, order.getOrderId());
			parameters.setJmsSendQueOrderId(order.getOrderId());
			
			log.info("Log mediator call starts for the Service->"+serviceName+" : "+Utilities.getCurrentDateTime());
			Inet4Address IP=(Inet4Address) Inet4Address.getLocalHost();
			log.info("Econnector IP ADRESS  ="+IP.getHostAddress());
			if(Constants.CREATE_INCIDENT.equals(serviceName)) {
				responseParameter = mediatorService.requestCreateTicketOR(parameters);
				
			}else if(Constants.UPDATE_TICKET.equals(serviceName)){	
				 parameters.setProperty(Constants.PROPERTY_REMEDY_TICKET, requestMap.get("CTS_Ticket"));
				 responseParameter= mediatorService.requestUpdateTicketOR(parameters);
				
			}else if(Constants.CREATE_TICKET.equals(order.getServiceNowTicket().getServiceName())){
				parameters.setProperty(Constants.PROPERTY_REQUEST_PARAMETER, order.getServiceNowTicket().toString());
				responseData = mediatorService.requestCreateTicketIR(parameters);
				 
			}else if(Constants.SERVICENAME_UPLOAD_ATTACHMENT.equals(serviceName)){
				parameters.setProperty(Constants.PROPERTY_REQUEST_PARAMETER, order.getServiceNowTicket().toString());
				responseParameter =  mediatorService.requestUploadAttachment(parameters);
				String status = (String) responseParameter.get("status");
				//String jsonValue = jSONProcessor.getInputMapAsJson(responseParameter);
				if(status != null ){
					//parameters.setProperty("jsonValue", jsonValue);
					parameters.setProperty("status","failure");
				}
				else{
					parameters.setProperty("status","success");
					parameters.setProperty("URL", responseParameter.get("URL"));
					parameters.setProperty("Username", responseParameter.get("userName"));
					parameters.setProperty("Password", responseParameter.get("password"));
					parameters.setProperty("RequestParam", responseParameter.get("requestParm"));
					}
				
				
			}else if(Constants.UPDATE_INCIDENT.equals(order.getServiceNowTicket().getServiceName())){
				parameters.setProperty(Constants.PROPERTY_REQUEST_PARAMETER, order.getServiceNowTicket().toString());
				responseData = mediatorService.requestUpdateTicketIR(parameters);
				}
			else if(Constants.SERVICENAME_CREATE_DATA_SYNC.equals(serviceName)){
				responseData = mediatorService.requestCreateDataSync(parameters);
				
			}
			else if(Constants.SERVICENAME_UPDATE_DATA_SYNC.equals(serviceName)){
				responseData = mediatorService.requestUpdateDataSync(parameters);
				
				 
			}
				 
			
			
			
		} catch (Exception e) {
			log.log(Level.SEVERE,e.getMessage());
			e.printStackTrace();		
		}
		log.info("Log mediator call ends : "+Utilities.getCurrentDateTime());
		return responseParameter;
	}
	
	
	
}
