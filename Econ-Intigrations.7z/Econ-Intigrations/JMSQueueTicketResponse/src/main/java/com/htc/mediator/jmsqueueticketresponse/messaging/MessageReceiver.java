package com.htc.mediator.jmsqueueticketresponse.messaging;

import java.util.HashMap;
import java.util.Map;

import javax.jms.JMSException;











import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;

import com.htc.mediator.JMSMessageRequest;
import com.htc.mediator.jmsqueueticket.model.Order;
import com.htc.mediator.jmsqueueticketresponse.service.OrderInventoryService;

@Component
public class MessageReceiver {

	static final Logger LOG = LoggerFactory.getLogger(MessageReceiver.class);
	private static final String CREATETICKETOR_QUEUE = "createTicketOR-queue";
	private static final String UPDATETICKETOR_QUEUE = "updateTicketOR-queue";
	private static final String CREATE_IR_QUEUE = "createIR-queue";
	private static final String UPDATE_IR_QUEUE = "updateIR-queue";
	private static final String UPLOADATTACHMENT_QUEUE = "uploadAttachment-queue";
	
	@Autowired
	OrderInventoryService orderInventoryService;
	
    @Autowired
    JMSMessageRequest jmsRequest;
	
	
	@JmsListener(destination = CREATETICKETOR_QUEUE)
	public void receiveMessage(final Message<Order> message) throws Exception {
		LOG.info("----------------------------------------------------");
		MessageHeaders headers =  message.getHeaders();
		Map<String,Object> parameter=new HashMap();
		LOG.info("Application : headers received : {}", headers);
		
		Order order = message.getPayload();
		LOG.info("Application : product : {}",order);	
		parameter=jmsRequest.processRequest(order);
		
		
			order.setSys_id(parameter.get("sys_id").toString());
			order.setRemedyTicketID(parameter.get("u_external_ticket_id").toString());
			order.setExternalTicketID(parameter.get("number").toString());
	
		orderInventoryService.createTicketOR(order);
		LOG.info("----------------------------------------------------");

	}
	
	@JmsListener(destination = UPDATETICKETOR_QUEUE)
	public void receivUpdateQueeMessage(final Message<Order> message) throws JMSException {
		LOG.info("----------------------------------------------------");
		Map<String,Object> parameter=new HashMap<String, Object>();
		MessageHeaders headers =  message.getHeaders();
		LOG.info("Application : headers received : {}", headers);
		
		Order order = message.getPayload();
		LOG.info("Application : product : {}",order);	
		parameter=jmsRequest.processRequest(order);
		System.out.println("--------------------------"+parameter.get("sysId"));
		
			order.setSys_id((String)parameter.get("sys_id"));
			//order.setRemedyTicketID(parameter.get("u_external_ticket_id").toString());
			order.setExternalTicketID((String)parameter.get("number"));
		
		orderInventoryService.updateTicketOR(order);
		LOG.info("----------------------------------------------------");

		
	}
	
	@JmsListener(destination = CREATE_IR_QUEUE)
	public void createIRQue(final Message<Order> message) throws JMSException {
		LOG.info("----------------------------------------------------");
		MessageHeaders headers =  message.getHeaders();
		LOG.info("Application : headers received : {}", headers);
		
		Order order = message.getPayload();
		String sNowField=order.getServiceNowTicket().toString();
		LOG.info("Application : product : {}",order);	
		jmsRequest.processRequest(order);

		//orderInventoryService.processOrder(order);
		LOG.info("----------------------------------------------------");

	}
	
	@JmsListener(destination = UPDATE_IR_QUEUE)
	public void updateIRQue(final Message<Order> message) throws JMSException {
		LOG.info("----------------------------------------------------");
		MessageHeaders headers =  message.getHeaders();
		LOG.info("Application : headers received : {}", headers);
		
		Order order = message.getPayload();
		String sNowField=order.getServiceNowTicket().toString();
		LOG.info("Application : product : {}",order);	
		jmsRequest.processRequest(order);

		//orderInventoryService.processOrder(order);
		LOG.info("----------------------------------------------------");

	}
	
	@JmsListener(destination = UPLOADATTACHMENT_QUEUE)
	public void uploadAttachment(final Message<Order> message) throws JMSException {
		LOG.info("----------------------------------------------------");
		MessageHeaders headers =  message.getHeaders();
		LOG.info("Application : headers received : {}", headers);
		
		Order order = message.getPayload();
		order.getTicketAttachment().toString();
		LOG.info("Application : product : {}",order);	
		jmsRequest.processRequest(order);

		//orderInventoryService.processOrder(order);
		LOG.info("----------------------------------------------------");

	}
	
}
