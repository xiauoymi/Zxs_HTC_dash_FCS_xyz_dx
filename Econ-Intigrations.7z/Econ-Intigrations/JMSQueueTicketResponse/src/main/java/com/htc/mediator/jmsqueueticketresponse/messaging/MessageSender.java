package com.htc.mediator.jmsqueueticketresponse.messaging;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Component;

import com.htc.mediator.jmsqueueticket.model.InventoryResponse;

@Component
public class MessageSender {

	@Autowired
	JmsTemplate jmsTemplate;

	private static final String CREATETICKETORRESPONSE_QUEUE = "createTicketOR-Response-queue";
	private static final String UPATETICKETORRESPONSE_QUEUE = "updateTicketOR-Response-queue";
	
	
	
	public void createTicketORResponse(final InventoryResponse inventoryResponse) {

		jmsTemplate.send(CREATETICKETORRESPONSE_QUEUE,new MessageCreator(){
			@Override
				public Message createMessage(Session session) throws JMSException{
					ObjectMessage objectMessage = session.createObjectMessage(inventoryResponse);
					return objectMessage;
				}
			});
	}



	public void updateTicketOR(final InventoryResponse inventoryResponse) {
		jmsTemplate.send(UPATETICKETORRESPONSE_QUEUE,new MessageCreator(){
			@Override
				public Message createMessage(Session session) throws JMSException{
					ObjectMessage objectMessage = session.createObjectMessage(inventoryResponse);
					return objectMessage;
				}
			});
		
	}

}
