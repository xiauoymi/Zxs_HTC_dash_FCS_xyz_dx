package com.htc.mediator.jmsqueueticketresponse.util;


import javax.jms.BytesMessage;
import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.io.*;


import static java.util.Objects.requireNonNull;


public final class JMSHelper {

	static final Logger LOG = LoggerFactory.getLogger(JMSHelper.class);
	
    private JMSHelper() {
        // Helper class
    }


    
    /**
     * Deserialize a JMS message containing a Java serialized abject.
     *
     * @param message JMS input message with a serialized payload
     * @param <T>     Type of the serialized object
     * @return The de-serialized object
     * @throws RuntimeException Can be thrown if deserialization fails.
     */
    public static <T extends Serializable> T messageToObject(@NotNull final BytesMessage message) {
        requireNonNull(message);

        try {
            byte[] rawData = new byte[(int) message.getBodyLength()];
            message.readBytes(rawData);
            return (T) convertFromBytes(rawData);
        } catch (JMSException e) {
        	LOG.error("Image De-Serializable Error :: ",e.getMessage());
        	return null;
        }
    }

    /**
     * Serialize an object to a byte buffer (payload to be de-serialized with {@link #objectFromMsg(BytesMessage)}).
     *
     * @param object A serializable object
     * @return The byte buffer containing the serialized object
     * @throws RuntimeException Can be thrown if serialization fails.
     */
    public static byte[] objectToMessage(@NotNull final Serializable object) {
        try (ByteArrayOutputStream bos = new ByteArrayOutputStream();
             ObjectOutput out = new ObjectOutputStream(bos)) {
            out.writeObject(object);
            return bos.toByteArray();
        } catch (IOException e) {
        	LOG.error("Image Serializable Error :: ",e.getMessage());
        	return null;
        }
    }

//    private BytesMessage objectToMessage(final Serializable payload)
//            throws IOException, ClassNotFoundException, javax.jms.JMSException {
//        try (ByteArrayOutputStream bos = new ByteArrayOutputStream();
//             ObjectOutput out = new ObjectOutputStream(bos)) {
//
//            out.writeObject(payload);
//            byte[] yourBytes = bos.toByteArray();
//            BytesMessage bytesMessage = session.createBytesMessage();
//            bytesMessage.setJMSDeliveryMode(DeliveryMode.NON_PERSISTENT);
//            bytesMessage.writeBytes(yourBytes);
//            return bytesMessage;
//        }
//    }
    
    
    static <T extends Serializable> T convertFromBytes(byte[] bytes) {
        try (ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
             ObjectInput in = new ObjectInputStream(bis)) {
            return (T) in.readObject();
        } catch (ClassNotFoundException | IOException e) {
        	LOG.error("Image Serializable Error :: ",e.getMessage());
        	return null;
        }
    }
}