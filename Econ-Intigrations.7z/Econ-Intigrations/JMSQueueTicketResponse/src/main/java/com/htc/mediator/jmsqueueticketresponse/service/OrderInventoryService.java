package com.htc.mediator.jmsqueueticketresponse.service;

import com.htc.mediator.jmsqueueticket.model.Order;

public interface OrderInventoryService {

	public void createTicketOR(Order order);
	public void updateTicketOR(Order order);
	
	
}
