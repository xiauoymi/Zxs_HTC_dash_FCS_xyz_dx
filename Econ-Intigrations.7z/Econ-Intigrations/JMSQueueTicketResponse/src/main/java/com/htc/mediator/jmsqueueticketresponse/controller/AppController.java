package com.htc.mediator.jmsqueueticketresponse.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;





import com.htc.mediator.JMSMessageRequest;
import com.htc.mediator.jmsqueueticket.model.Order;
import com.htc.mediator.jmsqueueticket.model.Response;
import com.htc.mediator.jmsqueueticket.model.Ticket;




@Controller
public class AppController {
	

	 @Autowired
	    JMSMessageRequest jmsRequest;
	 
	 @RequestMapping(value = { "/", "/home" }, method = RequestMethod.GET)
		public String prepareProduct(ModelMap model) {
			return "index";
		}

	@RequestMapping(value = { "/createTicketOR" }, method = RequestMethod.POST)
	public @ResponseBody ResponseEntity<Response> createTicket(@RequestBody Ticket ticket)throws Exception {
		Order order=new Order();
		Map<String,Object> parameter=new HashMap();
		order.setTicket(ticket);
		parameter=jmsRequest.processRequest(order);
		Response response=new Response();
		System.out.println("----------------"+(String)parameter.get("number"));
	//	String response=(String)parameter.get("responseParam");
		response.setResult((String)parameter.get("responseParam"));
		return new ResponseEntity<Response>(response, HttpStatus.OK);
		
	}
	
}
