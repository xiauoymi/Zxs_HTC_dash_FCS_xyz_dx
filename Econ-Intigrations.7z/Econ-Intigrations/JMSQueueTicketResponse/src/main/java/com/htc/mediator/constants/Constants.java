package com.htc.mediator.constants;

public class Constants
{
  public static final String SERVICENAME_TICKET_HANDLER = "TicketHandler";
  public static final String SERVICENAME_CREATE_TICKET_IR = "CreateTicketIR";
  public static final String SERVICENAME_CREATE_DATA_SYNC = "CreateDataSync";
  public static final String SERVICENAME_UPDATE_DATA_SYNC = "UpdateDataSync";
  public static final String SERVICENAME_UPDATE_TICKET_IR = "UpdateTicketIR";
  public static final String SERVICENAME_UPDATE_TICKET_OR = "UpdateTicketOR";
  public static final String SERVICENAME_UPLOAD_ATTACHMENT = "UploadAttachment";
  public static final String SERVICENAME_CREATE_TICKET_OR = "CreateTicketOR";
  public static final String STATUS_FAILED = "FAILED";
  public static final String STATUS_PASSED = "PASSED";
  public static final String STATUS_SUCCESS = "SUCCESS";
  public static final String DATABASE_NAME = "jdbc/WSO2MYSQL";
  public static final String PARAM_SOURCE = "source";
  public static final String PARAM_DESTINATION = "destination";
  public static final String PARAM_REQUEST_PARAMETER = "requestParameter";
  public static final String PARAM_REQUEST_MESSAGE_ID = "requestMessageId";
  public static final String PARAM_ESB_OUT_TIME = "esbInTime";
  public static final String PARAM_SNOW_OUT_TIME = "snowOutTime";
  public static final String PARAM_RESPONSE_PARAMETER = "responseParameter";
  public static final String PARAM_RESPONSE_MESSAGE_ID = "responseMessageId";
  public static final String PARAM_REMEDY_TICKET_NUMBER = "remedyNumber";
  public static final String PARAM_SNOW_TICKET_NUMBER = "snowTicket";
  public static final String PARAM_REMEDY_TICKET_ORDER_NUMBER = "jmsSendQueOrderId";
  
 /* public static final String PARAM_TABLE_NAME = "tableName";
  public static final String PARAM_ELEMENT = "element";
  public static final String PARAM_VALUE = "value";
  public static final String PARAM_ACTIVE = "active";
  public static final String PARAM_SEQUENCE = "sequence";
  public static final String PARAM_USER = "user";
  public static final String PARAM_CANEL_ID = "canelId";
  public static final String PARAM_UM_ID = "umId";
  public static final String PARAM_TITLE = "title";*/
  
  public static final String PARAM_INTIME_TO_ESB = "inTimeToESB";
  public static final String PARAM_INTIME_TO_SNOW = "inTimeToSnow";
  public static final String STATUS = "STATUS";
  public static final String MESSAGE = "MESSAGE";
  public static final String MODE = "mode";
  public static final String DATE = "date";
  public static final String CREATE = "Create";
  public static final String UPDATE = "Update";
  public static final String PARAM_OUTTIME_FROM_ESB = "outTimeFromESB";
  public static final String PARAM_OUTTIME_FROM_SNOW = "outTimeFromSnow";
  public static final String PARAM_CLIENT_NAME = "clientName";
  public static final String PARAM_ROUND_TRIP_DURATION = "roundDuration";
  public static final String PARAM_STATUS = "status";
  public static final String PARAM_SERVICE_NAME = "serviceName";
  public static final String SERVICE_NAME = "ServiceName";
  public static final String PARAM_SERVER_IP = "serverIp";
  public static final String CLIENT_ID = "Miami";
  public static final String PROPERTY_INTIME = "inTime";
  public static final String PROPERTY_REQUEST_MESSAGE_ID = "Request_Message_ID";
  public static final String PROPERTY_REQUEST_PARAMETER = "Request_Parameter";
  public static final String PROPERTY_SNOW_TICKET = "SNOW_Ticket";
 /* public static final String PROPERTY_TABLE_NAME = "tableName";
  public static final String PROPERTY_ELEMENT = "element";
  public static final String PROPERTY_VALUE = "value";
  public static final String PROPERTY_ACTIVE = "active";
  public static final String PROPERTY_SEQUENCE = "sequence" ;
  public static final String PROPERTY_USER = "user";
  public static final String PROPERTY_CANEL_ID = "canelId";
  public static final String PROPERTY_UM_ID = "umId";
  public static final String PROPERTY_TITLE = "title";*/
  public static final String PROPERTY_TICKET_NUMBER = "tickerNumber";
  public static final String PROPERTY_REMEDY_TICKET = "Remedy_Ticket";
  public static final String PROPERTY_OUTTIME = "outTime";
  public static final String PROPERTY_RESPONSE_PARAMETER = "Response_Parameter";
  public static final String PROPERTY_RESPONSE_MESSAGE_ID = "Response_Message_ID";
  public static final String PROPERTY_STATUS = "Status";
  public static final String SUCCESS = "SUCCESS";
  public static final String RESPONSE = "Response";
  public static final String FAILURE = "FAILURE";
  public static final String GET_JMS_SENDQUE_Client_TRANSACTIONID = "Select que_transaction_id from jms_send_queue where que_order_id= ? ";
  public static final String CREATE_TICKET_OR_REQUEST_SUMMARY_QUERY = "INSERT INTO jms_send_response_summary(source, request_message_id, in_time_to_esb, in_time_to_snow, destination, source_ticket_number, client_name, status, server_ip,que_transaction_id,sys_id,destination_ticket_number,out_time_from_esb,out_time_from_snow)VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?,?)";
  public static final String CREATE_TICKET_OR_REQUEST_DETAIL_QUERY = "INSERT INTO jms_log_details(transaction_id, request_parameter) VALUES (?, ?)";
  public static final String CREATE_TICKET_IR_REQUEST_SUMMARY_QUERY = "INSERT INTO jms_send_response_summary(source, request_message_id, in_time_to_esb, in_time_to_snow, destination, source_ticket_number, client_name, status, server_ip,que_transaction_id,destination_ticket_number,out_time_from_esb,out_time_from_snow)VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?)";
  public static final String CREATE_TICKET_IR_REQUEST_DETAIL_QUERY = "INSERT INTO jms_log_details(transaction_id, request_parameter) VALUES (?, ?)";
  public static final String UPLOAD_ATTACHMENT_REQUEST_SUMMARY_QUERY = "INSERT INTO esb_log_summary(source, request_message_id, in_time_to_esb, in_time_to_snow, destination, source_ticket_number, destination_ticket_number, client_name, status, server_ip)VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
  public static final String UPLOAD_ATTACHMENT_REQUEST_DETAIL_QUERY = "INSERT INTO jms_log_details(transaction_id, request_parameter) VALUES (?, ?)";
  public static final String UPDATE_TICKET_IR_REQUEST_SUMMARY_QUERY = "INSERT INTO jms_send_response_summary(source, request_message_id, in_time_to_esb, in_time_to_snow, destination, source_ticket_number, destination_ticket_number, client_name, status, server_ip,response_message_id,out_time_from_esb,out_time_from_snow,que_transaction_id)VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";
  
  public static final String CREATE_DATA_SYNC_QUERY = "INSERT INTO esb_data_synchronization(request_message_id,client_name,status,server_ip,request_parameter,response_parameter,mode,in_time_to_esb, in_time_to_snow,out_time_from_esb,out_time_from_snow,source,destination)VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
  public static final String UPDATE_DATA_SYNC_QUERY = "INSERT INTO esb_data_synchronization(request_message_id,client_name,status,server_ip,request_parameter,response_parameter,mode,date)VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
  
  public static final String UPDATE_TICKET_IR_REQUEST_DETAIL_QUERY = "INSERT INTO jms_log_details(transaction_id, request_parameter, response_parameter) VALUES (?, ?, ?)";
  public static final String UPDATE_TICKET_OR_REQUEST_SUMMARY_QUERY = "INSERT INTO jms_send_response_summary(source, request_message_id, in_time_to_esb, in_time_to_snow, destination,client_name, status, source_ticket_number, server_ip,que_transaction_id,sys_id,destination_ticket_number,out_time_from_esb,out_time_from_snow)VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?,?)";
  public static final String UPDATE_TICKET_OR_FAILED_RESPONSE_SUMMARY_QUERY = "INSERT INTO jms_send_response_summary(source, request_message_id, in_time_to_esb, in_time_to_snow, destination,client_name,status, source_ticket_number, destination_ticket_number,que_transaction_id,errorCode,errorDesc,out_time_from_esb,out_time_from_snow)VALUES (?, ?, ?, ?, ?, ?,?,?,?,?,?,?,?,?)";
  public static final String CREATE_TICKET_OR_FAILED_RESPONSE_SUMMARY_QUERY = "INSERT INTO jms_send_response_summary(source, request_message_id, in_time_to_esb, in_time_to_snow, destination,client_name,status, source_ticket_number, destination_ticket_number,que_transaction_id,errorCode,errorDesc,out_time_from_esb,out_time_from_snow)VALUES (?, ?, ?, ?, ?, ?,?,?,?,?,?,?,?,?)";
  public static final String CREATE_TICKET_OR_FAILED_RESPONSE_DETAIL_QUERY = "INSERT INTO esb_log_details(transaction_id,response_parameter, request_parameter) VALUES (?, ?, ?)";
  public static final String UPDATE_TICKET_OR_REQUEST_DETAIL_QUERY = "INSERT INTO jms_log_details(transaction_id,request_parameter) VALUES (?, ?)";
  public static final String CREATE_TICKET_OR_RESPONSE_SUMMARY_QUERY = "UPDATE esb_log_summary SET  response_message_id=?,  out_time_from_snow=?, out_time_from_esb=?, destination_ticket_number=? ,status=? WHERE request_message_id=?";
  public static final String CREATE_TICKET_OR_RESPONSE_DETAIL_QUERY = "UPDATE esb_log_details ed SET ed.response_parameter=? WHERE ed.transaction_id=(Select es.transaction_id FROM esb_log_summary es WHERE es.request_message_id=?)";
  public static final String CREATE_TICKET_IR_RESPONSE_SUMMARY_QUERY = "UPDATE esb_log_summary SET  response_message_id=?,  out_time_from_snow=?, out_time_from_esb=? , destination_ticket_number=?, status=? WHERE request_message_id=?";
  public static final String CREATE_TICKET_IR_RESPONSE_DETAIL_QUERY = "UPDATE esb_log_details ed SET ed.response_parameter=? WHERE ed.transaction_id=(Select es.transaction_id FROM esb_log_summary es WHERE es.request_message_id=?)";
  public static final String UPLOAD_ATTACHMENT_RESPONSE_SUMMARY_QUERY = "UPDATE esb_log_summary SET  response_message_id=?,  out_time_from_snow=?, out_time_from_esb=? ,status=? WHERE request_message_id=?";
  public static final String UPLOAD_ATTACHMENT_RESPONSE_DETAIL_QUERY = "UPDATE esb_log_details ed SET ed.response_parameter=? WHERE ed.transaction_id=(Select es.transaction_id FROM esb_log_summary es WHERE es.request_message_id=?)";
  public static final String UPDATE_TICKET_IR_RESPONSE_SUMMARY_QUERY = "UPDATE esb_log_summary SET  response_message_id=?,  out_time_from_snow=?, out_time_from_esb=? , status=? WHERE request_message_id=?";
  public static final String UPDATE_TICKET_IR_RESPONSE_DETAIL_QUERY = "UPDATE esb_log_details ed SET ed.response_parameter=? WHERE ed.transaction_id=(Select es.transaction_id FROM esb_log_summary es WHERE es.request_message_id=?)";
  public static final String UPDATE_TICKET_OR_RESPONSE_SUMMARY_QUERY = "UPDATE jms_send_response_summary SET  response_message_id=?,  out_time_from_snow=?, out_time_from_esb=? , destination_ticket_number=?, status=? ,que_transaction_id=? WHERE request_message_id=?";
  public static final String UPDATE_TICKET_OR_RESPONSE_DETAIL_QUERY = "UPDATE esb_log_details ed SET ed.response_parameter=? WHERE ed.transaction_id=(Select es.transaction_id FROM esb_log_summary es WHERE es.request_message_id=?)";
  public static final String UPDATE_STATUS_SUMMARY_QUERY = "UPDATE esb_log_summary SET  status=? WHERE request_message_id=?";
  public static final String DESTINATION_SERVICE_QUERY = "SELECT url FROM jms_services WHERE service_name=? and client_name=?";
  public static final String CLIENT_NAME_QUERY = "SELECT client_name FROM jms_client WHERE client_id=?";
  
  public static final String CREATE_INCIDENT="create_incident";
  public static final String UPDATE_INCIDENT="update_incident";
  public static final String CREATE_TICKET="create_ticket";
  public static final String UPDATE_TICKET="update_incident";
  public static final String RESPONSE_STATUS="response_status";
  public static final String SYS_ID = "sys_id";
  public static final String DESTINATION_TICKETNUMBER = "number";
  public static final String ERROR_CODE = "errorCode";
  public static final String ERROR_DESC = "errorDesc";
  
}