package com.htc.mediator.service;

import java.util.Map;

import com.htc.mediator.MessageParameters;


public interface MediatorService {
 
	public Map<String, Object> requestCreateTicketOR(MessageParameters context);
	public Map<String, Object> requestUpdateTicketOR(MessageParameters context);
	public Map<String, Object> requestUploadAttachment(MessageParameters parameters);
	public String requestCreateTicketIR(MessageParameters parameters);
	public String requestUpdateTicketIR(MessageParameters parameters);
	public String requestCreateDataSync(MessageParameters parameters);
	public String requestUpdateDataSync(MessageParameters parameters);
}
