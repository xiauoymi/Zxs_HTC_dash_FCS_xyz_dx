package com.caretech.mediator.service.impl;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.xml.ws.http.HTTPException;

import org.apache.http.conn.HttpHostConnectException;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.stereotype.Service;

import com.caretech.mediator.constant.Constants;
import com.caretech.mediator.constant.MimeTypeConstants;
import com.caretech.mediator.datamapping.dto.TargetApplicationDTO;
import com.caretech.mediator.datamapping.enums.ErrorCode;
import com.caretech.mediator.datamapping.exception.BaseException;
import com.caretech.mediator.datamapping.exception.IncidentException;
import com.caretech.mediator.datamapping.exception.InvalidDataMappingXMLException;
import com.caretech.mediator.datamapping.processor.DataMapperProcessor;
import com.caretech.mediator.datamapping.processor.DataTransformer;
import com.caretech.mediator.datamapping.processor.JSONProcessor;
import com.caretech.mediator.exception.MandatoryParameterException;
import com.caretech.mediator.model.Output;
import com.caretech.mediator.model.Response;
import com.caretech.mediator.processor.RemedyDataSyncProcessor;
import com.caretech.mediator.processor.RemedyProcessor;
import com.caretech.mediator.processor.RemedyProcessorNew;
import com.caretech.mediator.processor.ServiceNowProcessor;
import com.caretech.mediator.service.TicketService;
import com.htc.mediator.dao.MediatorDAO;
import com.htc.mediator.dao.impl.MediatorDAOImpl;


@Service("ticketService")
public class TicketServiceImpl implements TicketService{

	private Logger LOGGER = Logger.getLogger(TicketServiceImpl.class.getName());
	
	private static DataMapperProcessor processor =  new DataMapperProcessor();
	
	private static JSONProcessor jSONProcessor = new JSONProcessor();
	
	private static ServiceNowProcessor serviceNowConnector =  new ServiceNowProcessor();

	private static RemedyProcessor remedyConnector = new RemedyProcessor();
	
	private static RemedyProcessorNew remedyConnectorCreate = new RemedyProcessorNew();
	
	private static RemedyDataSyncProcessor remedyDataSync = new RemedyDataSyncProcessor();
	
	private static DataTransformer dataTransformer = new DataTransformer();
	
	/*
	 * (non-Javadoc)
	 * @see com.caretech.webservice.service.TicketService#updateIncidentStatus(java.lang.String)
	 */
	public Map<String, Object> updateIncidentStatus(Map<String,Object> requestMap) throws IncidentException {
	//	Response restResponse = new Response();
	//	String response = null;
		Map<String,Object> param = new HashMap<String, Object>();
		String responseData = null;
		try {  
			LOGGER.info("UpdateIncident ServiceImpl starts");
			//Map<String, Object> requestMap = jSONProcessor.getInputJsonAsMap(incident);
			if(requestMap.get("Submitter") != null) {
				requestMap.put("Last_Updated_By", requestMap.get("Submitter"));
			}
		    TargetApplicationDTO targetApplication = processor.processDataMapperService(requestMap);
		    Map<String, Object> serviceNowParameters = targetApplication.getRequestParam();
		    String sysId = serviceNowConnector.getSysid(targetApplication, (String)serviceNowParameters.get("number"));
			   
		    for(int i=0; i<10; i++){
		    	if(sysId!=null)
		    		break;
		    	else
		    		sysId = serviceNowConnector.getSysid(targetApplication, (String)serviceNowParameters.get("number"));
		    	
		    }
		    String resolvedBy = serviceNowConnector.getResolvedBy(targetApplication, (String)serviceNowParameters.get("number"));
		    if(!isNull(resolvedBy))
		    	serviceNowParameters.put("is_resolved", "true");
		    else
		    	serviceNowParameters.put("is_resolved", "false");
		    serviceNowParameters.put("sys_id", sysId);
		    serviceNowParameters.put("u_remedy_flag", "true");
		    dataTransformer.transformOutboundStatus(serviceNowParameters);
		    dataTransformer.transformOutboundAssignmentGroup(serviceNowParameters);
			dataTransformer.transformData(serviceNowParameters);
			dataTransformer.transformOutboundParentTicket(serviceNowParameters, targetApplication);
		    String serviceNowParam = jSONProcessor.getInputMapAsJson(serviceNowParameters);
		    serviceNowParam = serviceNowParam.replace("\\n", "\\r\\n");
		    //Thread.sleep(2000);
		    
		    System.out.println("ServiceNow Parameters---------->"+serviceNowParam);
		    responseData= dataTransformer.transformOutboundTicket(serviceNowParam, targetApplication);
		    if(sysId == null){
		    	param.put("Error", "Error while connecting to ServiceNow api");
		    	param.put("status", "Failure");
		    }
		    else{
			    param.put("status", "Success");
			    param.put("requestParm",serviceNowParam);
				param.put("URL",targetApplication.getIncidentUrl()+"/"+sysId+"?sysparm_input_display_value=True");
			    param.put("userName",targetApplication.getUserName());
				param.put("password",targetApplication.getPassword());
		    }
		    
			
		} catch (InvalidDataMappingXMLException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(e.getErrorCode(), e.getErrorMessage());			
		} catch (MandatoryParameterException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(ErrorCode.ERR_X1001.name(), ErrorCode.ERR_X1001.getErrorMessage()+" : "+e.getMessage());
		} catch (HTTPException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(ErrorCode.ERR_X1002.name(), ErrorCode.ERR_X1002.getErrorMessage()+" : "+e.getMessage());
		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(ErrorCode.ERR_X1004.name(), ErrorCode.ERR_X1004.getErrorMessage()+" : "+e.getMessage());
		} catch (BaseException exception) {
		    LOGGER.error(exception.getErrorMessage(), exception);
			throw new IncidentException(ErrorCode.ERR_X1003.name(), ErrorCode.ERR_X1003.getErrorMessage()+" : "+exception.getMessage());
		} catch (Exception exception) {
		    LOGGER.error(exception.getMessage(), exception);
			throw new IncidentException(ErrorCode.ERR_X1005.name(), ErrorCode.ERR_X1005.getErrorMessage()+" : "+exception.getMessage());
		}
		LOGGER.info("UpdateIncident ServiceImpl ends");
		//response = restResponse.toString();
		return param;
	}

	/*
	 * (non-Javadoc)
	 * @see com.caretech.webservice.service.TicketService#createIncident(java.lang.String)
	 */
	@SuppressWarnings({ "unused" })
	public Map<String, Object> createIncident(String incident) throws IncidentException {
		Response restResponse = new Response();
		String response = null;
		String serviceNowParam = null;
		 Map<String,Object> param = new HashMap<String, Object>();
		try {  
			LOGGER.info("CreateIncident ServiceImpl starts");
			LOGGER.info("request parameter"+incident);
			Map<String, Object> requestMap = jSONProcessor.getInputJsonAsMap(incident);
		    TargetApplicationDTO targetApplication = processor.processDataMapperService(requestMap);
		    Constants.WSDL_URL = targetApplication.getIncidentUrl();
		    Map<String, Object> serviceNowParameters = targetApplication.getRequestParam();
		    serviceNowParameters.put("is_resolved", "false");
		    serviceNowParameters.put("u_remedy_flag", "true");
		    dataTransformer.transformOutboundStatus(serviceNowParameters);
		    dataTransformer.transformOutboundAssignmentGroup(serviceNowParameters);
			dataTransformer.transformData(serviceNowParameters);
			dataTransformer.transformOutboundParentTicket(serviceNowParameters, targetApplication);
		    serviceNowParam = jSONProcessor.getInputMapAsJson(serviceNowParameters);
		    serviceNowParam = serviceNowParam.replace("\\n", "\\r\\n");
		    
		 
		  param.put("requestParm",serviceNowParam);
		  param.put("URL",targetApplication.getIncidentUrl()+ "?sysparm_input_display_value=True");
		  param.put("userName",targetApplication.getUserName());
		  param.put("password",targetApplication.getPassword());
		   
		} catch (InvalidDataMappingXMLException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(e.getErrorCode(), e.getErrorMessage());			
		} catch (MandatoryParameterException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(ErrorCode.ERR_X1001.name(), "Missing Parameters");
		} catch (HttpHostConnectException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(ErrorCode.ERR_X1002.name(), ErrorCode.ERR_X1002.getErrorMessage()+" : "+e.getMessage());
		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(ErrorCode.ERR_X1004.name(), ErrorCode.ERR_X1004.getErrorMessage()+" : "+e.getMessage());
		} catch (BaseException exception) {
		    LOGGER.error(exception.getErrorMessage(), exception);
			throw new IncidentException(ErrorCode.ERR_X1003.name(), ErrorCode.ERR_X1003.getErrorMessage()+" : "+exception.getMessage());
		} catch (Exception exception) {
		    LOGGER.error(exception.getMessage(), exception);
			throw new IncidentException(ErrorCode.ERR_X1005.name(), ErrorCode.ERR_X1005.getErrorMessage()+" : "+exception.getMessage());
		}
		LOGGER.info("CreateIncident ServiceImpl Ends");
		return param;
	}

	/*
	 * (non-Javadoc)
	 * @see com.caretech.webservice.service.TicketService#uploadAttachments(java.lang.String)
	 */
	public Map<String, Object> uploadAttachments(String incident) throws IncidentException {
		Map<String,Object> param = new HashMap<String, Object>();
		List<Map<String, String>> attachmentList = null;
		 boolean isAttachmentAvailable = false;
		try {   
			LOGGER.info("UploadAttachments ServiceImpl starts");
			Map<String, Object> requestMap = jSONProcessor.getInputJsonAsMap(incident);
			TargetApplicationDTO targetApplication = processor.processDataMapperService(requestMap);
		    
		    Map<String, Object> serviceNowParameters = targetApplication.getRequestParam();
		    String attachmentName = (String)serviceNowParameters.get("name");
		    String sysId = serviceNowConnector.getSysid(targetApplication, (String)serviceNowParameters.get("CTS_Ticket__c"));
		    if(sysId != null) {
			    attachmentList = serviceNowConnector.getAttachmentList(targetApplication, sysId);
			    isAttachmentAvailable = checkAttachmentInSNOW(attachmentList, attachmentName);
		    }
		    
		    if(isAttachmentAvailable){
		    	param.put("Error", "Attachment already exist");
		    	param.put("status", Constants.STATUS_SUCCESS);
		    	param.put("TicketNumber","Attachment already exist");
		    } else if(sysId != null){
		    	serviceNowParameters.put("sysId", sysId);
			    //serviceNowParameters.put("u_attachment_sent_to_remedy", "true");
		    	processAttachmentRequest(serviceNowParameters);
			    String serviceNowParam = jSONProcessor.getInputMapAsJson(serviceNowParameters);
			    param.put("requestParm",serviceNowParam);
				param.put("URL",targetApplication.getUrl());
			    param.put("userName",targetApplication.getUserName());
				param.put("password",targetApplication.getPassword());
		    } else {
		    	param.put("Error", "Error while connecting to ServiceNow api");
		    	param.put("status", Constants.STATUS_FAILED);
		    }
		 
		} catch (InvalidDataMappingXMLException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(e.getErrorCode(), e.getErrorMessage());			
		} catch (MandatoryParameterException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(ErrorCode.ERR_X1001.name(),  "Missing Parameters");
		} catch (HTTPException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(ErrorCode.ERR_X1002.name(), ErrorCode.ERR_X1002.getErrorMessage()+" : "+e.getMessage());
		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(ErrorCode.ERR_X1004.name(), ErrorCode.ERR_X1004.getErrorMessage()+" : "+e.getMessage());
		} catch (BaseException exception) {
		    LOGGER.error(exception.getErrorMessage(), exception);
			throw new IncidentException(ErrorCode.ERR_X1003.name(), ErrorCode.ERR_X1003.getErrorMessage()+" : "+exception.getMessage());
		} catch (Exception exception) {
		    LOGGER.error(exception.getMessage(), exception);
			throw new IncidentException(ErrorCode.ERR_X1005.name(), ErrorCode.ERR_X1005.getErrorMessage()+" : "+exception.getMessage());
		}
		LOGGER.info("UploadAttachments ServiceImpl ends");
		return param;
	}
	
	private boolean checkAttachmentInSNOW(
			List<Map<String, String>> attachmentList, String attachmentName) {
		String snowAttachmentName = null;
		for(Map<String, String> attachmentData : attachmentList){
			snowAttachmentName = attachmentData.get("file_name");
			if(attachmentName.equals(snowAttachmentName))
				return true;
		}
		return false;
	}

	private void processAttachmentRequest(Map<String, Object> serviceNowParameters) {
		String sysId = (String)serviceNowParameters.get("sysId");
		serviceNowParameters.put("source", "incident:"+sysId);
		String name = (String)serviceNowParameters.get("name");
		String fileExtension = name.substring(name.lastIndexOf(".")+1, name.length());
		serviceNowParameters.put("name", name+":"+MimeTypeConstants.getMimeType(fileExtension));
	}

	/*
	 * (non-Javadoc)
	 * @see com.caretech.webservice.service.TicketService#updateIncident(java.lang.String)
	 */
	@Override
	public Response updateIncident(final String incident, final String requestMessageId) throws IncidentException {
		Response restResponse = new Response();
		String response = null;
		try {
			LOGGER.info("UpdateIncidentStatus ServiceImpl starts");
			Map<String, Object> requestMap = jSONProcessor.getInputJsonAsMap(incident);
			if(delayAttachmentTicket(requestMap)) {
				restResponse.setStatus("SUCCESS");
				Output<String> dummyOutput = new Output<String>("Response sent back to ServiceNow for Email attachments");
				restResponse.setOutput(dummyOutput);
				new Thread(new Runnable() {
				    public void run() {
				    	try {
							Thread.sleep(10000);
							asyncUpdateIncident(incident, requestMessageId);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				        
				    }

					
				}).start();
				return restResponse;
			}
			TargetApplicationDTO targetApplication = processor.processDataMapperService(requestMap);
			Constants.WSDL_URL = targetApplication.getUrl();
			Constants.WSDL_AUTHENTICATION_USERNAME = targetApplication.getUserName();
			Constants.WSDL_AUTHENTICATION_PASSWORD = targetApplication.getPassword();
		    Map<String, Object> remedyParameters = targetApplication.getRequestParam();
		    dataTransformer.transformInboundStatus(remedyParameters);
		    dataTransformer.transformInboundEmailTicket(remedyParameters);
		    dataTransformer.transformData(remedyParameters);
		    System.out.println("Remedy mapped params :"+remedyParameters);
		    LOGGER.error("Remedy mapped params :"+remedyParameters);
		    response = remedyConnector.updateTicketStatus(remedyParameters);
		    
			restResponse.setStatus("SUCCESS");
			Output<String> output = new Output<String>(response);
			restResponse.setOutput(output);
		} catch (MandatoryParameterException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(ErrorCode.ERR_X1001.name(),  "Missing Parameters");			
		} catch (InvalidDataMappingXMLException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(e.getErrorCode(), e.getErrorMessage());			
		} catch (HTTPException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(ErrorCode.ERR_X1002.name(), ErrorCode.ERR_X1002.getErrorMessage()+" : "+e.getMessage());
		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(ErrorCode.ERR_X1004.name(), ErrorCode.ERR_X1004.getErrorMessage()+" : "+e.getMessage());
		} catch (BaseException exception) {
		    LOGGER.error(exception.getErrorMessage(), exception);
			throw new IncidentException(ErrorCode.ERR_X1003.name(), ErrorCode.ERR_X1003.getErrorMessage()+" : "+exception.getMessage());
		} catch (Exception exception) {
		    LOGGER.error(exception.getMessage(), exception);
			throw new IncidentException(ErrorCode.ERR_X1005.name(), ErrorCode.ERR_X1005.getErrorMessage()+" : "+exception.getMessage());
		}
		LOGGER.info("UpdateIncidentStatus ServiceImpl ends");
		response = restResponse.toString();
		return restResponse;
	}
	
	private void asyncUpdateIncident(String incident, String requestMessageId) throws Exception {

		Response restResponse = new Response();
		MediatorDAO mediatorDao= new MediatorDAOImpl();
		String response = null;
		try {
			LOGGER.info("UpdateIncidentStatus ServiceImpl starts");
			Map<String, Object> requestMap = jSONProcessor.getInputJsonAsMap(incident);
			TargetApplicationDTO targetApplication = processor.processDataMapperService(requestMap);
			Constants.WSDL_URL = targetApplication.getUrl();
			Constants.WSDL_AUTHENTICATION_USERNAME = targetApplication.getUserName();
			Constants.WSDL_AUTHENTICATION_PASSWORD = targetApplication.getPassword();
		    Map<String, Object> remedyParameters = targetApplication.getRequestParam();
		    dataTransformer.transformInboundStatus(remedyParameters);
		    dataTransformer.transformInboundEmailTicket(remedyParameters);
		    dataTransformer.transformData(remedyParameters);
		    System.out.println("Remedy mapped params :"+remedyParameters);
		    LOGGER.error("Remedy mapped params :"+remedyParameters);
		    response = remedyConnector.updateTicketStatus(remedyParameters);
		    
			restResponse.setStatus("SUCCESS");
			
			
		} catch (MandatoryParameterException e) {
			restResponse.setStatus("FAILED");
			response = e.getMessage();
		} catch (InvalidDataMappingXMLException e) {
			restResponse.setStatus("FAILED");
			response = e.getMessage();
		} catch (HTTPException e) {
			restResponse.setStatus("FAILED");
			response = e.getMessage();
		} catch (IOException e) {
			restResponse.setStatus("FAILED");
			response = e.getMessage();
		} catch (BaseException exception) {
			restResponse.setStatus("FAILED");
			response = exception.getMessage();
		} catch (Exception exception) {
			restResponse.setStatus("FAILED");
			response = exception.getMessage();
		}
		Output<String> output = new Output<String>(response);
		restResponse.setOutput(output);
		Map<String, Object>  responseParam = new HashMap<String, Object>();
		responseParam.put("Status",restResponse.getStatus());
		responseParam.put("Result",restResponse.getOutput().getResult());
		HashMap< String, Object> databaseParams = new HashMap<String, Object>();
		java.util.Date date= new java.util.Date();
		Date sqlDate = new Date((date).getTime());
		Timestamp outTimeFromESB= new Timestamp(sqlDate.getTime()) ;
		databaseParams.put(Constants.PARAM_RESPONSE_MESSAGE_ID, requestMessageId);
		databaseParams.put(Constants.PARAM_OUTTIME_FROM_SNOW, outTimeFromESB);
		databaseParams.put(Constants.PARAM_OUTTIME_FROM_ESB, outTimeFromESB);
		databaseParams.put(Constants.PARAM_REQUEST_MESSAGE_ID, requestMessageId);
		databaseParams.put(Constants.PARAM_STATUS, restResponse.getStatus());		
		databaseParams.put(Constants.PARAM_RESPONSE_PARAMETER,  jSONProcessor.getInputMapAsJson(responseParam));
		mediatorDao.responseUpdateTicketIRLog(databaseParams);
		databaseParams.clear();
		LOGGER.info("UpdateIncidentStatus ServiceImpl ends");
		
	}
	
	private boolean delayAttachmentTicket(Map<String, Object> requestMap) throws InterruptedException {
		
		String openedBy = (String) requestMap.get("opened_by");
		String attachmentName = (String) requestMap.get("attachment_1_attachmentName");
		if(!isNull(openedBy) && !isNull(attachmentName) &&
				Constants.OPENED_BY_INBOUND_EMAIL.equals((openedBy)))
			return true;
		return false;
		
	}
	
	private boolean isNull(String strData) {
		if ((strData != null) && (strData.trim().length() > 0)
				&& (!strData.trim().equalsIgnoreCase("null"))) {
			return false;
		}

		return true;
	}

	public Response createTicket(String incident) throws  IncidentException  {
		Response restResponse = new Response();
		
		String response = null;
		try {
			LOGGER.error("CreateTicketIR ServiceImpl starts");
			LOGGER.error("Before conversion to map : "+incident);
			Map<String, Object> requestMap = jSONProcessor.getInputJsonAsMap(incident);
			LOGGER.error("Converted to map : "+requestMap);
			TargetApplicationDTO targetApplication = processor.processDataMapperService(requestMap);
			Constants.WSDL_URL = targetApplication.getUrl();
			Constants.WSDL_AUTHENTICATION_USERNAME = targetApplication.getUserName();
			Constants.WSDL_AUTHENTICATION_PASSWORD = targetApplication.getPassword();
		    Map<String, Object> remedyParameters = targetApplication.getRequestParam();
		    dataTransformer.transformInboundStatus(remedyParameters);
		    dataTransformer.transformInboundEmailTicket(remedyParameters);
		    dataTransformer.transformData(remedyParameters);
		    processRemedyAttachmentRequest(remedyParameters);
		    System.out.println("Remedy mapped params :"+remedyParameters);
		    LOGGER.error("Remedy mapped params :"+remedyParameters);
		    response = remedyConnectorCreate.createTicket(remedyParameters);
			restResponse.setStatus("SUCCESS");
			Output<String> output = new Output<String>(response);
			restResponse.setOutput(output);
		} catch (MandatoryParameterException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(ErrorCode.ERR_X1001.name(),  "Missing Parameters");			
		} catch (InvalidDataMappingXMLException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(e.getErrorCode(), e.getErrorMessage());			
		} catch (HTTPException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(ErrorCode.ERR_X1002.name(), ErrorCode.ERR_X1002.getErrorMessage()+" : "+e.getMessage());
		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(ErrorCode.ERR_X1004.name(), ErrorCode.ERR_X1004.getErrorMessage()+" : "+e.getMessage());
		} catch (BaseException exception) {
		    LOGGER.error(exception.getErrorMessage(), exception);
			throw new IncidentException(ErrorCode.ERR_X1003.name(), ErrorCode.ERR_X1003.getErrorMessage()+" : "+exception.getMessage());
		} catch (Exception exception) {
		    LOGGER.error(exception.getMessage(), exception);
			throw new IncidentException(ErrorCode.ERR_X1005.name(), ErrorCode.ERR_X1005.getErrorMessage()+" : "+exception.getMessage());
		}
		LOGGER.info("UpdateIncidentStatus ServiceImpl ends");
		response = restResponse.toString();
		return restResponse;
	}
	
	private void processRemedyAttachmentRequest(Map<String, Object> remedyParameters) {
		String attachmentName = "";
		@SuppressWarnings("unused")
		String fileExtension = "";
		if(remedyParameters.get("attachment_1_attachmentName")!=null){
			attachmentName = (String)remedyParameters.get("attachment_1_attachmentName");
			fileExtension = attachmentName.substring(attachmentName.lastIndexOf(".")+1, attachmentName.length());
			remedyParameters.put("attachment_1_attachmentName", attachmentName);
		}
		if(remedyParameters.get("attachment_2_attachmentName")!=null){
			attachmentName = (String)remedyParameters.get("attachment_2_attachmentName");
			fileExtension = attachmentName.substring(attachmentName.lastIndexOf(".")+1, attachmentName.length());
			remedyParameters.put("attachment_2_attachmentName", attachmentName);
		}
		if(remedyParameters.get("attachment_3_attachmentName")!=null){
			attachmentName = (String)remedyParameters.get("attachment_3_attachmentName");
			fileExtension = attachmentName.substring(attachmentName.lastIndexOf(".")+1, attachmentName.length());
			remedyParameters.put("attachment_3_attachmentName", attachmentName);
		}
		if(remedyParameters.get("attachment_4_attachmentName")!=null){
			attachmentName = (String)remedyParameters.get("attachment_4_attachmentName");
			fileExtension = attachmentName.substring(attachmentName.lastIndexOf(".")+1, attachmentName.length());
			remedyParameters.put("attachment_4_attachmentName", attachmentName);
		}
		if(remedyParameters.get("attachment_5_attachmentName")!=null){
			attachmentName = (String)remedyParameters.get("attachment_5_attachmentName");
			fileExtension = attachmentName.substring(attachmentName.lastIndexOf(".")+1, attachmentName.length());
			remedyParameters.put("attachment_5_attachmentName", attachmentName);
		}
	}

	@Override
	public Response createDataSync(String incident) throws IncidentException {
		Response restResponse = new Response();
		String response = null;
		try {
			LOGGER.info("Create Data Sync starts");
			Map<String, Object> requestMap = jSONProcessor.getInputJsonAsMap(incident);
			String serviceName = (String) requestMap.get("ServiceName");
			TargetApplicationDTO targetApplication = processor.processDataMapperService(requestMap);
			System.out.println("after mapping");
			Constants.WSDL_URL = targetApplication.getUrl();
			Constants.WSDL_AUTHENTICATION_USERNAME = targetApplication.getUserName();
			Constants.WSDL_AUTHENTICATION_PASSWORD = targetApplication.getPassword();
		    Map<String, Object> remedyParameters = targetApplication.getRequestParam();
		    //restResponse.setTableName((String)remedyParameters.get("Form_Name"));
		    System.out.println("remedy paramerterssss"+remedyParameters);
		    LOGGER.info("Remedy mapped params :"+remedyParameters);
		    
		    if(serviceName.equals("user_data_sync")){
		    	response = remedyDataSync.userDataSync(remedyParameters);
		    }
		    else if(serviceName.equals("cmdb_ci_data_sync")){
		    	response = remedyDataSync.cmdbDataSync(remedyParameters);
		    }
		    else if(serviceName.equals("group_data_sync")){
		    	response = remedyDataSync.groupDataSync(remedyParameters);
		    }
		    else if(serviceName.equals("choice_data_sync")){
		    	response = remedyDataSync.choiceDataSync(remedyParameters);
		    }
		    else{
		    	response = remedyDataSync.locationDataSync(remedyParameters);
		    }
		    
		    restResponse.setStatus("SUCCESS");
		    System.out.println("response"+response);
		    System.out.println("response"+restResponse.toString());
			Output<String> output = new Output<String>(response);
			restResponse.setOutput(output);
		} catch (MandatoryParameterException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(ErrorCode.ERR_X1001.name(),  "Missing Parameters");			
		} catch (InvalidDataMappingXMLException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(e.getErrorCode(), e.getErrorMessage());			
		} catch (HTTPException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(ErrorCode.ERR_X1002.name(), ErrorCode.ERR_X1002.getErrorMessage()+" : "+e.getMessage());
		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(ErrorCode.ERR_X1004.name(), ErrorCode.ERR_X1004.getErrorMessage()+" : "+e.getMessage());
		} catch (BaseException exception) {
		    LOGGER.error(exception.getErrorMessage(), exception);
			throw new IncidentException(ErrorCode.ERR_X1003.name(), ErrorCode.ERR_X1003.getErrorMessage()+" : "+exception.getMessage());
		} catch (Exception exception) {
		    LOGGER.error(exception.getMessage(), exception);
			throw new IncidentException(ErrorCode.ERR_X1005.name(), ErrorCode.ERR_X1005.getErrorMessage()+" : "+exception.getMessage());
		}
		System.out.println();
		LOGGER.info("UpdateIncidentStatus ServiceImpl ends");
		response = restResponse.toString();
		return restResponse;
	}

	@Override
	public String createIncident(Map<String, Object> requestData)
			throws IncidentException {
		String serviceNowParam = null;
		String responseData = null;
		String response=null;
		 Map<String,Object> param = new HashMap<String, Object>();
		try {  
			LOGGER.info("CreateIncident ServiceImpl starts");
			LOGGER.info("request parameter"+requestData.toString());
		    TargetApplicationDTO targetApplication = processor.processDataMapperService(requestData);
		    Constants.WSDL_URL = targetApplication.getIncidentUrl();
		    Map<String, Object> serviceNowParameters = targetApplication.getRequestParam();
		    serviceNowParameters.put("is_resolved", "false");
		    serviceNowParameters.put("u_remedy_flag", "true");
		    dataTransformer.transformOutboundStatus(serviceNowParameters);
		    dataTransformer.transformOutboundAssignmentGroup(serviceNowParameters);
			dataTransformer.transformData(serviceNowParameters);
			dataTransformer.transformOutboundParentTicket(serviceNowParameters, targetApplication);
		    serviceNowParam = jSONProcessor.getInputMapAsJson(serviceNowParameters);
		    serviceNowParam = serviceNowParam.replace("\\n", "\\r\\n");
		 
		  param.put("requestParm",serviceNowParam);
		  param.put("URL",targetApplication.getIncidentUrl()+ "?sysparm_input_display_value=True");
		  param.put("userName",targetApplication.getUserName());
		  param.put("password",targetApplication.getPassword());
		  targetApplication.setUrl(targetApplication.getIncidentUrl()+ "?sysparm_input_display_value=True");
		  responseData= dataTransformer.transformOutboundTicket(serviceNowParam, targetApplication);
		  
		  JSONParser parser = new JSONParser(); 
			JSONObject json = (JSONObject) parser.parse(responseData);
			Map<String, Object> requestMap=new LinkedHashMap<>();
			if(null!=json){
				JSONProcessor jsonProccessor=new JSONProcessor();
				requestMap=jsonProccessor.getInputJsonAsMap(json.get("result").toString());
			}
		  
	//	 response = remedyConnector.createIncidentStatus(requestMap);
		  
		} catch (InvalidDataMappingXMLException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(e.getErrorCode(), e.getErrorMessage());			
		} catch (MandatoryParameterException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(ErrorCode.ERR_X1001.name(), "Missing Parameters");
		} catch (HttpHostConnectException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(ErrorCode.ERR_X1002.name(), ErrorCode.ERR_X1002.getErrorMessage()+" : "+e.getMessage());
		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
			throw new IncidentException(ErrorCode.ERR_X1004.name(), ErrorCode.ERR_X1004.getErrorMessage()+" : "+e.getMessage());
		} catch (BaseException exception) {
		    LOGGER.error(exception.getErrorMessage(), exception);
			throw new IncidentException(ErrorCode.ERR_X1003.name(), ErrorCode.ERR_X1003.getErrorMessage()+" : "+exception.getMessage());
		} catch (Exception exception) {
		    LOGGER.error(exception.getMessage(), exception);
			throw new IncidentException(ErrorCode.ERR_X1005.name(), ErrorCode.ERR_X1005.getErrorMessage()+" : "+exception.getMessage());
		}
		LOGGER.info("CreateIncident ServiceImpl Ends");
		return responseData;
	}

	

	

}
