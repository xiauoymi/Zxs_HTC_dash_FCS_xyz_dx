/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.caretech.mediator.datamapping.dto;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


/**
 * @author gopinathn
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "object")
public class TargetObjectDTO {

    //Attributes
    @XmlAttribute(name = "id")
    private String targetObjectId;
    @XmlAttribute(name = "name")
    private String name;
    @XmlAttribute(name = "type")
    private String type;
    @XmlAttribute(name = "sourceObject")
    private String sourceObject;
    @XmlElement(name = "field")
    private List<FieldTargetDTO> targetFields;

   

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the sourceObject
     */
    public String getSourceObject() {
        return sourceObject;
    }

    /**
     * @param sourceObject the sourceObject to set
     */
    public void setSourceObject(String sourceObject) {
        this.sourceObject = sourceObject;
    }

    /**
     * @return the targetFields
     */
    public List<FieldTargetDTO> getTargetFields() {
        return targetFields;
    }

    /**
     * @param targetFields the targetFields to set
     */
    public void setTargetFields(List<FieldTargetDTO> targetFields) {
        this.targetFields = targetFields;
    }

    /**
     * @return the targetObjectId
     */
    public String getTargetObjectId() {
        return targetObjectId;
    }

    /**
     * @param targetObjectId the targetObjectId to set
     */
    public void setTargetObjectId(String targetObjectId) {
        this.targetObjectId = targetObjectId;
    }

   
    
}
