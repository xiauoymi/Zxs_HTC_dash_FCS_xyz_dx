/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.caretech.ticket.datamapping.processor;

import java.util.HashMap;
import java.util.Map;

import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;

public class JSONProcessor {
	
	private static JSONProcessor jsonProcessor;
	
	private JSONProcessor(){}
	
	public static JSONProcessor getInstance(){
		if(jsonProcessor == null)
			jsonProcessor = new JSONProcessor();
		return jsonProcessor;
	}

	/**
	 * Convert JSON string to Map<String, Object>
	 *
	 * @param receivedJsonString
	 * @return Map<String, Object>
	 * @throws Exception
	 */
	public Map<String, Object> getInputJsonAsMap(String json) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(DeserializationConfig.Feature.USE_BIG_DECIMAL_FOR_FLOATS);
		mapper.enable(DeserializationConfig.Feature.USE_BIG_INTEGER_FOR_INTS);
		json = json.replaceAll("(\\r|\\n|\\r\\n)+", "\\\\n");
		Map<String, Object> map = mapper.readValue(json, new TypeReference<HashMap<String, Object>>() {
		});
		return map;
	}

	/**
	 * Convert  Map<String, Object> to JSON string
	 *
	 * @param receivedMap<String, Object>
	 * @return convertedJsonString
	 * @throws Exception
	 */
	public String getInputMapAsJson(Map<String, Object> map) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(DeserializationConfig.Feature.USE_BIG_DECIMAL_FOR_FLOATS);
		mapper.enable(DeserializationConfig.Feature.USE_BIG_INTEGER_FOR_INTS);
		String jsonString = mapper.writeValueAsString(map);
		return jsonString;
	}
}
