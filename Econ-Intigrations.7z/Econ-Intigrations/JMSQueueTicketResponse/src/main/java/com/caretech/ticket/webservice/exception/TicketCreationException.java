package com.caretech.ticket.webservice.exception;

public class TicketCreationException extends BaseException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 * @param errorCode
	 * @param errorMessage
	 */
	public TicketCreationException(String errorCode, String errorMessage) {
        super(errorCode, errorMessage);
    }
	
}
