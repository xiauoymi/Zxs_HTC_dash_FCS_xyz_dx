/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.caretech.mediator.datamapping.enums;

import java.text.MessageFormat;


public enum InvalidDataMappingXMLErrCode {

    ERR_X1001("SAX Parse Exception"),
    ERR_X1002("Data mapper XML file not found"),
    ERR_X1003("Invalid Data Mapping XML Configuration"),
    ERR_X1004("Invalid Translate Mapping XML Configuration"),
    ERR_X1005("Operation {0} not listed in the Translation Configuration"),
    ERR_X1006("Translation configuration file for operation {0} not found");
    private String errorMessage;

    private InvalidDataMappingXMLErrCode(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public String getErrorMessage(String... args) {
        return MessageFormat.format(errorMessage, (Object[]) args);
    }
}
