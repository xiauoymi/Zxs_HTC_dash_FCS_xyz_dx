package com.caretech.mediator.model;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

/**
 * @author gopinathn
 *
 */
@JsonInclude(Include.NON_NULL)
@JsonTypeName(value="ComplexItem")
@XmlRootElement(name="ComplexItem")
@XStreamAlias("ComplexItem")
public class ComplexItem {
	
	@XStreamAsAttribute
	private String ID;
	
	@XStreamAsAttribute
	private String Type;
	
	@XStreamAsAttribute
	private Item Item;
	

	@JsonProperty
	@XmlAttribute
	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	@JsonProperty
	@XmlElement
	public Item getItem() {
		return Item;
	}

	public void setItem(Item Item) {
		this.Item = Item;
	}
	
	

}
