
package com.caretech.webservice.datasync;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for InputMapping1 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="InputMapping1">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Submitter" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Assigned_To" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Status" type="{urn:CMN:IntegrationFoundationDataSync_WS}StatusType"/>
 *         &lt;element name="Short_Description" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Form_Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Client_Field_1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Client_Field_2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Client_Field_4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Client_Field_5" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Client_Field_4_Label" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Client_Field_1_Label" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Client_Field_2_Label" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Client_Field_5_Label" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Client_Field_3_Label" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Client_Field_3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Transaction_Type" type="{urn:CMN:IntegrationFoundationDataSync_WS}Transaction_TypeType" minOccurs="0"/>
 *         &lt;element name="Client" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Primary_Key" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InputMapping1", propOrder = {
    "submitter",
    "assignedTo",
    "status",
    "shortDescription",
    "formName",
    "clientField1",
    "clientField2",
    "clientField4",
    "clientField5",
    "clientField4Label",
    "clientField1Label",
    "clientField2Label",
    "clientField5Label",
    "clientField3Label",
    "clientField3",
    "transactionType",
    "client",
    "primaryKey"
})
public class InputMapping1 {

    @XmlElement(name = "Submitter", required = true)
    protected String submitter;
    @XmlElement(name = "Assigned_To")
    protected String assignedTo;
    @XmlElement(name = "Status", required = true)
    @XmlSchemaType(name = "string")
    protected StatusType status;
    @XmlElement(name = "Short_Description", required = true)
    protected String shortDescription;
    @XmlElement(name = "Form_Name")
    protected String formName;
    @XmlElement(name = "Client_Field_1")
    protected String clientField1;
    @XmlElement(name = "Client_Field_2")
    protected String clientField2;
    @XmlElement(name = "Client_Field_4")
    protected String clientField4;
    @XmlElement(name = "Client_Field_5")
    protected String clientField5;
    @XmlElement(name = "Client_Field_4_Label")
    protected String clientField4Label;
    @XmlElement(name = "Client_Field_1_Label")
    protected String clientField1Label;
    @XmlElement(name = "Client_Field_2_Label")
    protected String clientField2Label;
    @XmlElement(name = "Client_Field_5_Label")
    protected String clientField5Label;
    @XmlElement(name = "Client_Field_3_Label")
    protected String clientField3Label;
    @XmlElement(name = "Client_Field_3")
    protected String clientField3;
    @XmlElementRef(name = "Transaction_Type", namespace = "urn:CMN:IntegrationFoundationDataSync_WS", type = JAXBElement.class, required = false)
    protected JAXBElement<TransactionTypeType> transactionType;
    @XmlElement(name = "Client")
    protected String client;
    @XmlElement(name = "Primary_Key")
    protected String primaryKey;

    /**
     * Gets the value of the submitter property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubmitter() {
        return submitter;
    }

    /**
     * Sets the value of the submitter property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubmitter(String value) {
        this.submitter = value;
    }

    /**
     * Gets the value of the assignedTo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssignedTo() {
        return assignedTo;
    }

    /**
     * Sets the value of the assignedTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssignedTo(String value) {
        this.assignedTo = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link StatusType }
     *     
     */
    public StatusType getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusType }
     *     
     */
    public void setStatus(StatusType value) {
        this.status = value;
    }

    /**
     * Gets the value of the shortDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShortDescription() {
        return shortDescription;
    }

    /**
     * Sets the value of the shortDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShortDescription(String value) {
        this.shortDescription = value;
    }

    /**
     * Gets the value of the formName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormName() {
        return formName;
    }

    /**
     * Sets the value of the formName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormName(String value) {
        this.formName = value;
    }

    /**
     * Gets the value of the clientField1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientField1() {
        return clientField1;
    }

    /**
     * Sets the value of the clientField1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientField1(String value) {
        this.clientField1 = value;
    }

    /**
     * Gets the value of the clientField2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientField2() {
        return clientField2;
    }

    /**
     * Sets the value of the clientField2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientField2(String value) {
        this.clientField2 = value;
    }

    /**
     * Gets the value of the clientField4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientField4() {
        return clientField4;
    }

    /**
     * Sets the value of the clientField4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientField4(String value) {
        this.clientField4 = value;
    }

    /**
     * Gets the value of the clientField5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientField5() {
        return clientField5;
    }

    /**
     * Sets the value of the clientField5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientField5(String value) {
        this.clientField5 = value;
    }

    /**
     * Gets the value of the clientField4Label property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientField4Label() {
        return clientField4Label;
    }

    /**
     * Sets the value of the clientField4Label property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientField4Label(String value) {
        this.clientField4Label = value;
    }

    /**
     * Gets the value of the clientField1Label property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientField1Label() {
        return clientField1Label;
    }

    /**
     * Sets the value of the clientField1Label property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientField1Label(String value) {
        this.clientField1Label = value;
    }

    /**
     * Gets the value of the clientField2Label property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientField2Label() {
        return clientField2Label;
    }

    /**
     * Sets the value of the clientField2Label property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientField2Label(String value) {
        this.clientField2Label = value;
    }

    /**
     * Gets the value of the clientField5Label property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientField5Label() {
        return clientField5Label;
    }

    /**
     * Sets the value of the clientField5Label property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientField5Label(String value) {
        this.clientField5Label = value;
    }

    /**
     * Gets the value of the clientField3Label property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientField3Label() {
        return clientField3Label;
    }

    /**
     * Sets the value of the clientField3Label property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientField3Label(String value) {
        this.clientField3Label = value;
    }

    /**
     * Gets the value of the clientField3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientField3() {
        return clientField3;
    }

    /**
     * Sets the value of the clientField3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientField3(String value) {
        this.clientField3 = value;
    }

    /**
     * Gets the value of the transactionType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link TransactionTypeType }{@code >}
     *     
     */
    public JAXBElement<TransactionTypeType> getTransactionType() {
        return transactionType;
    }

    /**
     * Sets the value of the transactionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link TransactionTypeType }{@code >}
     *     
     */
    public void setTransactionType(JAXBElement<TransactionTypeType> value) {
        this.transactionType = value;
    }

    /**
     * Gets the value of the client property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClient() {
        return client;
    }

    /**
     * Sets the value of the client property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClient(String value) {
        this.client = value;
    }

    /**
     * Gets the value of the primaryKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrimaryKey() {
        return primaryKey;
    }

    /**
     * Sets the value of the primaryKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrimaryKey(String value) {
        this.primaryKey = value;
    }

}
