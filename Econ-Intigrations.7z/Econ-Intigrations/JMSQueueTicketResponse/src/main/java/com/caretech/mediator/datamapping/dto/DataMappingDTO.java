/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.caretech.mediator.datamapping.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;


/**
 * @author gopinathn
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "data-mapping")
public class DataMappingDTO {

	
	@XmlElement(name = "target-application")
	private TargetApplicationDTO targetApplication;
    @XmlElementWrapper(name = "source-objects")
    @XmlElement(name = "object")
    private List<SourceObjectDTO> sourceObjects;
    @XmlElementWrapper(name = "target-objects")
    @XmlElement(name = "object")
    private List<TargetObjectDTO> targetObjects;

    /**
     * @return the sourceObjects
     */
    public List<SourceObjectDTO> getSourceObjects() {
        return sourceObjects;
    }

    /**
     * @param sourceObjects the sourceObjects to set
     */
    public void setSourceObjects(List<SourceObjectDTO> sourceObjects) {
        this.sourceObjects = sourceObjects;
    }

    /**
     * @return the targetObjects
     */
    public List<TargetObjectDTO> getTargetObjects() {
        return targetObjects;
    }

    /**
     * @param targetObjects the targetObjects to set
     */
    public void setTargetObjects(List<TargetObjectDTO> targetObjects) {
        this.targetObjects = targetObjects;
    }

	/**
	 * @return the targetApplication
	 */
	public TargetApplicationDTO getTargetApplication() {
		return targetApplication;
	}

	/**
	 * @param targetApplication the targetApplication to set
	 */
	public void setTargetApplication(TargetApplicationDTO targetApplication) {
		this.targetApplication = targetApplication;
	}

    

}
