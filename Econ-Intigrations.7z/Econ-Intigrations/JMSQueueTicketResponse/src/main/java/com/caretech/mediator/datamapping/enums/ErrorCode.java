/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.caretech.mediator.datamapping.enums;

import java.text.MessageFormat;


public enum ErrorCode {

	ERR_X1001("Missing Mandatory Parameter"),
	ERR_X1002("Connection Failed"),
    ERR_X1003("Base Exception Occured"), 
    ERR_X1004("File Not Found"),
    ERR_X1005("Exception occured due to the following reason");
	
    
    private String errorMessage;

    private ErrorCode(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public String getErrorMessage(String... args) {
        return MessageFormat.format(errorMessage, (Object[]) args);
    }
}
