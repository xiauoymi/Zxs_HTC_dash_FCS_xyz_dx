package com.caretech.ticket.webservice.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "client")
public class Client {
	
	@XmlAttribute(name = "id")
    private String id;
	@XmlAttribute(name = "serviceName")
    private String serviceName;
	@XmlAttribute(name = "mappingFileName")
    private String mappingFileName;
	@XmlAttribute(name = "targetMapping")
    private String targetMapping;
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the serviceName
	 */
	public String getServiceName() {
		return serviceName;
	}
	/**
	 * @param serviceName the serviceName to set
	 */
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	/**
	 * @return the mappingFileName
	 */
	public String getMappingFileName() {
		return mappingFileName;
	}
	/**
	 * @param mappingFileName the mappingFileName to set
	 */
	public void setMappingFileName(String mappingFileName) {
		this.mappingFileName = mappingFileName;
	}
	/**
	 * @return the targetMapping
	 */
	public String getTargetMapping() {
		return targetMapping;
	}
	/**
	 * @param targetMapping the targetMapping to set
	 */
	public void setTargetMapping(String targetMapping) {
		this.targetMapping = targetMapping;
	}
	
	

}
