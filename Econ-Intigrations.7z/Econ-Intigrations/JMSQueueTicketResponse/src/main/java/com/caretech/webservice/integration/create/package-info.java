@javax.xml.bind.annotation.XmlSchema(namespace = "urn:CMN:Integration:CreateInBoundNewTicket_WB", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.caretech.webservice.integration.create;
