package com.caretech.ticket.webservice.service;

import com.caretech.ticket.webservice.exception.TicketCreationException;
import com.caretech.ticket.webservice.model.Response;
import com.htc.mediator.jmsqueueticket.model.Ticket;

public interface TicketService {
	
	public Response createTicket(Ticket ticket) throws TicketCreationException;

//	public Response uploadAttachment(TicketAttachment attachment) throws TicketCreationException;

//	public Response updateTicket(Ticket ticket) throws TicketCreationException;

}
