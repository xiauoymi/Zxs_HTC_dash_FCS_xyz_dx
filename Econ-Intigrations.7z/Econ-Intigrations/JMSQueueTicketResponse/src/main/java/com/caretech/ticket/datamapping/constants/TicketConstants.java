package com.caretech.ticket.datamapping.constants;

public class TicketConstants {
	
	public static final Object SERVICE_NAME = "ServiceName";
	
	public static final Object PARAM_CLIENT_ID = "Client_ID";
	
	public static final String DATA_MAPPING_XML_FILE_PATH = "/com/caretech/ticket/webservice/resources/";
	
	public static final String AUTHENTICATION_FILE_PATH = System.getenv("CATALINA_HOME") + "/conf/authentication.properties";

	public static final String AUTHENTICATION_FAILED = "Failed while Authorizing User";

	public static final String UNAUTHORIZED_USER = "UnAuthorized User";
	
	public static final String RESPONSE_STATUS_SUCCESS = "SUCCESS";
	
	public static final String RESPONSE_STATUS_FAILED = "FAILED";
	
	public static final String XML_CLIENT_AUTHENTICATION = "client_authentication";
	
	public static final String AUTHENTICATION_REQUIRED_FLAG = "Y";
	
	public static final String STATUS_SUCCESS = "SUCCESS";
	
	public static final String STATUS_FAILED = "FAILED";

}
