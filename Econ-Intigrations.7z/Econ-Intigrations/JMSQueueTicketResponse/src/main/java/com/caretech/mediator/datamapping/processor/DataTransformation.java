package com.caretech.mediator.datamapping.processor;

import java.io.IOException;
import java.util.Map;

import org.apache.http.conn.HttpHostConnectException;

import com.caretech.mediator.datamapping.dto.TargetApplicationDTO;

public interface DataTransformation {
	
	public void transformData(Map<String, Object> requestParameters);
	
	public void transformInboundStatus(Map<String, Object> requestParameters);
	
	public void transformOutboundStatus(Map<String, Object> requestParameters);
	
	public void transformOutboundParentTicket(Map<String, Object> requestParameters, 
			TargetApplicationDTO targetApplication) throws HttpHostConnectException, IOException;

}
