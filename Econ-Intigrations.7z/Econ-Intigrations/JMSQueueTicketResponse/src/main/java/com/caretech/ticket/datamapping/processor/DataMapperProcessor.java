/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.caretech.ticket.datamapping.processor;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.caretech.ticket.datamapping.constants.TicketConstants;
import com.caretech.ticket.datamapping.enums.ErrorCode;
import com.caretech.ticket.datamapping.parser.DataMappingXMLParser;
import com.caretech.ticket.webservice.exception.InvalidDataMappingXMLException;
import com.caretech.ticket.webservice.exception.MandatoryParameterException;
import com.caretech.ticket.webservice.model.Client;
import com.caretech.ticket.webservice.model.ClientAuthenticationDTO;
import com.caretech.ticket.webservice.model.ClientMapping;
import com.caretech.ticket.webservice.model.DataMappingDTO;
import com.caretech.ticket.webservice.model.FieldSourceDTO;
import com.caretech.ticket.webservice.model.SourceObjectDTO;
import com.caretech.ticket.webservice.model.TargetApplicationDTO;

/**
 * @author gopinathn
 *
 */
public class DataMapperProcessor {
	
	private static DataMapperProcessor dataMappingProcessor;
	
	private DataMapperProcessor(){}
	
	public static DataMapperProcessor getInstance(){
		if(dataMappingProcessor == null)
			dataMappingProcessor = new DataMapperProcessor();
		return dataMappingProcessor;
	}
	
	
	/**
	 * Helper method for converting the request parameters using the data mapping xml.
	 * @param parameters Request parameters as map.
	 * @return
	 * @throws Exception
	 */
	public TargetApplicationDTO processDataMapperService(Map<String, Object> parameters) throws Exception {
		TargetApplicationDTO targetApplication = new TargetApplicationDTO();
		Client client = new Client();
		String serviceName = (String) parameters.get(TicketConstants.SERVICE_NAME);
		String clientID = (String) parameters.get(TicketConstants.PARAM_CLIENT_ID);
		if(clientID != null){
			URL mappingUrl = this.getClass().getResource(TicketConstants.DATA_MAPPING_XML_FILE_PATH + "client_mapping.xml");
			if(mappingUrl != null) {
			File file = new File(mappingUrl.getPath());
				if (file.exists()) {
					client = getClientMapping(file.getAbsolutePath(), clientID, serviceName);
					if(client != null)
					serviceName = client.getMappingFileName();
				}
			} else {
				throw new InvalidDataMappingXMLException(ErrorCode.ERR_X1002.name(),
						ErrorCode.ERR_X1002.getErrorMessage()+ " for client ID "+clientID);
			}
		}
		URL url = this.getClass().getResource(TicketConstants.DATA_MAPPING_XML_FILE_PATH + serviceName + ".xml");
		if(url != null) {
		File file = new File(url.getPath());
		DataMappingDTO dataMappingDTO = null;
		if (file.exists()) {
			dataMappingDTO = getDataMapping(file.getAbsolutePath());
			ArrayList<String> mandatoryParamList = getMandatoryParams(dataMappingDTO);
			String missingParameters = validateMandatoryParams(parameters, mandatoryParamList);
			if(missingParameters != null){
				throw new MandatoryParameterException(missingParameters);
			}
			targetApplication = dataMappingDTO.getTargetApplication();
			if (dataMappingDTO != null && "Y".equals(targetApplication.getMappingRequired())) {
				Map<String, Object> fieldSources = getFieldSources(dataMappingDTO);
				Map<String, Object> mappedValues = getMappedColumns(parameters, fieldSources);
				targetApplication.setRequest(convertMapToEntry(mappedValues, client));
				return targetApplication;
			}
		} else {
			throw new InvalidDataMappingXMLException(ErrorCode.ERR_X1003.name(),
					ErrorCode.ERR_X1003.getErrorMessage());
		}
		} else {
			throw new InvalidDataMappingXMLException(ErrorCode.ERR_X1002.name(),
					ErrorCode.ERR_X1002.getErrorMessage()+ " for service name "+serviceName);
		}
		return targetApplication;
	}
	
	private ArrayList<String> getMandatoryParams(DataMappingDTO dataMappingDTO) {
		ArrayList<String> fieldSources = new ArrayList<String>();
		for (SourceObjectDTO sourceObjectDTO : dataMappingDTO.getSourceObjects()) {
			for (FieldSourceDTO fieldSourceDTO : sourceObjectDTO.getSourceFields()) {
				if(fieldSourceDTO.getSourceFieldId() != null && "Y".equals(fieldSourceDTO.getMandatory()))
				fieldSources.add(fieldSourceDTO.getSourceFieldId());
			}
		}
		return fieldSources;
	}
	
	private String validateMandatoryParams(Map<String, Object> requestValues, ArrayList<String> mandatoryParamList) {
		List<String> params = new ArrayList<String>();
		for(String mandatoryParam : mandatoryParamList)
			if(!requestValues.containsKey(mandatoryParam))
				params.add(mandatoryParam);
		if (params.size() > 0) {
			return params.toString().replace("[", "").replace("]", "");
		}else{
			return null;
		}
	}
	
	/**
	 * Helper method to convert Map to Entry string. 
	 * @param entryItems
	 * @return
	 * @throws Exception 
	 */
	public String convertMapToEntry(Map<String,Object> entryItems, Client client) throws Exception{
		/*StringBuffer entryString = new StringBuffer();
		entryString.append("<request><serviceName>create_incident</serviceName><parameters><Entry>");
		Iterator<Entry<String, Object>> it = entryItems.entrySet().iterator();
        
        while (it.hasNext()) {
	        Entry<String, Object> pair = it.next();
	        if(!pair.getKey().equals("1") && pair.getValue() != null)
	        	entryString.append("<EntryItem ID=\""+pair.getKey()+"\" >"+pair.getValue()+"</EntryItem>");
        }
        entryString.append("</Entry></parameters></request>");*/
		if (client != null && client.getTargetMapping() != null)
			entryItems.put("ServiceName", client.getTargetMapping());
		else
			entryItems.put("ServiceName", "create_incident");
		String entryString = JSONProcessor.getInstance().getInputMapAsJson(entryItems);
		return entryString;
	}

	/**
	 * @param dataMappingXMLPath
	 * @return
	 * @throws Exception
	 */
	private DataMappingDTO getDataMapping(String dataMappingXMLPath) throws Exception {
		return DataMappingXMLParser.getDataMapping(dataMappingXMLPath);
	}
	
	/**
	 * @param dataMappingXMLPath
	 * @param clientID
	 * @param serviceName
	 * @return
	 * @throws Exception
	 */
	private Client getClientMapping(String dataMappingXMLPath, String clientID, String serviceName) throws Exception {
		ClientMapping clientMapping = DataMappingXMLParser.getClientMapping(dataMappingXMLPath);
		for(Client client : clientMapping.getClientList()){
			if(client.getId().equals(clientID) && client.getServiceName().equals(serviceName))
				return client;
		}
		return null;
	}
	
	/**
	 * Helper method to form a Map of source field and its corresponding target field.
	 * @param dataMappingDTO <code>DataMappingDTO</code>.
	 * @return <code>Map<String, String></code>.
	 * @throws Exception
	 */
	private Map<String, Object> getFieldSources(DataMappingDTO dataMappingDTO) throws Exception {
		Map<String, Object> fieldSources = new HashMap<String, Object>();
		for (SourceObjectDTO sourceObjectDTO : dataMappingDTO.getSourceObjects()) {
			for (FieldSourceDTO fieldSourceDTO : sourceObjectDTO.getSourceFields()) {
				fieldSources.put(fieldSourceDTO.getName(), fieldSourceDTO.getSourceFieldId());
			}
		}
		return fieldSources;
	}


	/**
     * Helper method to map the value of source field to the target field.
     * @param receivedInput Holds the request with field name and value as map.
     * @param fieldSources Holds the map of source field and corresponding target field name.
     * @return Map of target field name and field value.
     * @throws Exception
     */
	private Map<String, Object> getMappedColumns(Map<String, Object> receivedInput,
			Map<String, Object> fieldSources) throws Exception {
		Map<String, Object> mappedTargetValues = new HashMap<String, Object>();
        
        Iterator<Entry<String, Object>> it = receivedInput.entrySet().iterator();
        
        while (it.hasNext()) {
	        Entry<String, Object> pair = it.next();
	        if(fieldSources.get(pair.getKey()) != null)
	        	mappedTargetValues.put((String)fieldSources.get(pair.getKey()), pair.getValue());
        }
		return mappedTargetValues;
	}
	
	/**
	 * Helper method for converting to ClientAuthenticationDTO using the client authentication xml.
	 * @param serviceName.
	 * @return
	 * @throws Exception
	 */
	public ClientAuthenticationDTO processClientAuthenticationService(String serviceName) throws Exception {
		URL url = DataMappingXMLParser.class.getResource(TicketConstants.DATA_MAPPING_XML_FILE_PATH + serviceName + ".xml");
		File file = new File(url.getPath());
		ClientAuthenticationDTO clientAuthenticationDTO = null;
		if (file.exists()) {
			clientAuthenticationDTO = DataMappingXMLParser.getClientAuthenticationObject(file.getAbsolutePath());
		}else {
			throw new InvalidDataMappingXMLException(ErrorCode.ERR_X1002.name(),
					ErrorCode.ERR_X1002.getErrorMessage());
		}
		return clientAuthenticationDTO;
	}
}
