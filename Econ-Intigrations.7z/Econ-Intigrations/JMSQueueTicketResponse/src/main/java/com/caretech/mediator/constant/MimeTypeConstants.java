package com.caretech.mediator.constant;

import java.util.HashMap;
/**
 * @author gopinathn
 *
 */
@SuppressWarnings("serial")
public class MimeTypeConstants {
	
	

	/**
	 * Map file extensions to MIME types. Based on the Apache mime.types file.
	 */

	  private static final String MIME_APPLICATION_ZIP       = "application/zip";
	  private static final String MIME_APPLICATION_MSWORD      = "application/msword";
	  private static final String MIME_APPLICATION_MS_WORD = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
	  private static final String MIME_APPLICATION_PDF       = "application/pdf";
	  private static final String MIME_APPLICATION_VND_MSEXCEL   = "application/vnd.ms-excel";
	  private static final String MIME_APPLICATION_VND_MS_EXCEL   = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	  private static final String MIME_APPLICATION_VND_MSPOWERPOINT= "application/vnd.ms-powerpoint";
	  private static final String MIME_APPLICATION_VND_MS_POWERPOINT= "application/vnd.openxmlformats-officedocument.presentationml.presentation";
	  private static final String MIME_APPLICATION_VND_RNREALMEDIA = "application/vnd.rn-realmedia";
	  private static final String MIME_APPLICATION_XML       = "application/xml";
	  private static final String MIME_APPLICATION_XML_DTD     = "application/xml-dtd";
	  private static final String MIME_IMAGE_BMP         = "image/bmp";
	  private static final String MIME_IMAGE_CGM         = "image/cgm";
	  private static final String MIME_IMAGE_GIF         = "image/gif";
	  private static final String MIME_IMAGE_IEF         = "image/ief";
	  private static final String MIME_IMAGE_JPEG          = "image/jpeg";
	  private static final String MIME_IMAGE_TIFF          = "image/tiff";
	  private static final String MIME_IMAGE_PNG         = "image/png";
	  private static final String MIME_TEXT_PLAIN          = "text/plain";
	  private static final String MIME_TEXT_RICHTEXT       = "text/richtext";
	  private static final String MIME_TEXT_RTF          = "text/rtf";
	  private static final String MIME_TEXT_HTML         = "text/html";
	  private static final String MIME_APPLICATION_OCTET_STREAM  = "application/octet-stream";
	  
	  private static HashMap<String, String> mimeTypeMapping;

	  static {
	    mimeTypeMapping = new HashMap<String, String>(200) {
	      private void put1(String key, String value) {
	        if (put(key, value) != null) {
	          throw new IllegalArgumentException("Duplicated extension: " + key);
	        }
	      }
	      {
	      put1("ief", MIME_IMAGE_IEF);
	      put1("cgm", MIME_IMAGE_CGM);
	      put1("bmp", MIME_IMAGE_BMP);
	      put1("dtd", MIME_APPLICATION_XML_DTD);
	      put1("xsl", MIME_APPLICATION_XML);
	      put1("xml", MIME_APPLICATION_XML);
	      put1("rm", MIME_APPLICATION_VND_RNREALMEDIA);
	      put1("ppt", MIME_APPLICATION_VND_MSPOWERPOINT);
	      put1("pptx", MIME_APPLICATION_VND_MS_POWERPOINT);
	      put1("txt", MIME_TEXT_PLAIN);
	      put1("ini", MIME_TEXT_PLAIN);
	      put1("c", MIME_TEXT_PLAIN);
	      put1("h", MIME_TEXT_PLAIN);
	      put1("cpp", MIME_TEXT_PLAIN);
	      put1("cxx", MIME_TEXT_PLAIN);
	      put1("cc", MIME_TEXT_PLAIN);
	      put1("chh", MIME_TEXT_PLAIN);
	      put1("java", MIME_TEXT_PLAIN);
	      put1("csv", MIME_TEXT_PLAIN);
	      put1("bat", MIME_TEXT_PLAIN);
	      put1("cmd", MIME_TEXT_PLAIN);
	      put1("asc", MIME_TEXT_PLAIN);
	      put1("rtf", MIME_TEXT_RTF);
	      put1("rtx", MIME_TEXT_RICHTEXT);
	      put1("html", MIME_TEXT_HTML);
	      put1("htm", MIME_TEXT_HTML);
	      put1("zip", MIME_APPLICATION_ZIP);
	      put1("gif", MIME_IMAGE_GIF);
	      put1("jpeg", MIME_IMAGE_JPEG);
	      put1("jpg", MIME_IMAGE_JPEG);
	      put1("jpe", MIME_IMAGE_JPEG);
	      put1("tiff", MIME_IMAGE_TIFF);
	      put1("tif", MIME_IMAGE_TIFF);
	      put1("png", MIME_IMAGE_PNG);
	      put1("doc", MIME_APPLICATION_MSWORD);
	      put1("docx", MIME_APPLICATION_MS_WORD);
	      put1("xls", MIME_APPLICATION_VND_MSEXCEL);
	      put1("xlsx", MIME_APPLICATION_VND_MS_EXCEL);
	      put1("pdf", MIME_APPLICATION_PDF);
	    }};
	  }


	  /**
	   * Registers MIME type for provided extension. Existing extension type will be overriden.
	   */
	  public static void registerMimeType(String ext, String mimeType) {
	    mimeTypeMapping.put(ext, mimeType);
	  }

	  /**
	   * Returns the corresponding MIME type to the given extension.
	   * If no MIME type was found it returns 'application/octet-stream' type.
	   */
	  public static String getMimeType(String ext) {
	    String mimeType = lookupMimeType(ext);
	    if (mimeType == null) {
	      mimeType = MIME_APPLICATION_OCTET_STREAM;
	    }
	    return mimeType;
	  }

	  /**
	   * Simply returns MIME type or <code>null</code> if no type is found.
	   */
	  public static String lookupMimeType(String ext) {
	    return mimeTypeMapping.get(ext.toLowerCase());
	  }
	

}
