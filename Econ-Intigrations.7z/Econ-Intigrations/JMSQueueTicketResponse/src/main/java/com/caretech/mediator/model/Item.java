package com.caretech.mediator.model;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamConverter;
import com.thoughtworks.xstream.converters.extended.ToAttributedValueConverter;

/**
 * @author gopinathn
 *
 */
@XStreamAlias("Item")
@XStreamConverter(value = ToAttributedValueConverter.class, strings = { "value" })
public class Item {
	
	@XStreamAsAttribute
	private String Type;
	
	private String value;

	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	

}
