@javax.xml.bind.annotation.XmlSchema(namespace = "urn:CMN:Integration:ReturnAcknowledgement_WS", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.caretech.webservice.integration.create.acknowledge;
