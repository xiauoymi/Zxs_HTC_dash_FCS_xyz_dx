package com.caretech.mediator.model;

import javax.xml.bind.annotation.XmlAnyElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeName;

/**
 * @author gopinathn
 *
 */
@XmlRootElement
@JsonInclude(Include.NON_NULL)
@JsonTypeName(value="output")
public class Output<T> {
	
	
	private T result;

	public Output(T result) {
		this.result = result;
	}

	@XmlAnyElement
	@JsonProperty("output")
	@JsonTypeInfo(use = JsonTypeInfo.Id.NAME,include=As.WRAPPER_OBJECT,property="type")
	public T getResult() {
		return result;
	}
	
	public void setResult(T result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return "Output [result=" + result + "]";
	}

}