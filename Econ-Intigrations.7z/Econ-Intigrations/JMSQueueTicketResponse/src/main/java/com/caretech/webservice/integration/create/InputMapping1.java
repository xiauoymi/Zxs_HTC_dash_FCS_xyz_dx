
package com.caretech.webservice.integration.create;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for InputMapping1 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="InputMapping1">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Submitter" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Assigned_To" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Status" type="{urn:CMN:Integration:CreateInBoundNewTicket_WB}StatusType"/>
 *         &lt;element name="Short_Description" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Department" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Building" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Client" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Asset_Tag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Processed" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Integration_Attribute_08" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Integration_Attribute_01" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Error_Message" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Phone_Test" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Temp01" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="Temp02" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Temp03" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Additional_Comments" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Integration_Attribute_07" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Integration_Attribute_05" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Network_Login" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Resolution" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Computer_Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Root_Cause_Category" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Title" type="{urn:CMN:Integration:CreateInBoundNewTicket_WB}TitleType" minOccurs="0"/>
 *         &lt;element name="Phone-Work" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Email_Address" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Category" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Type" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Item" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Assigned_Group" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Work_Log" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Assigned_Individual" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Priority" type="{urn:CMN:Integration:CreateInBoundNewTicket_WB}PriorityType" minOccurs="0"/>
 *         &lt;element name="Pending_Reason" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="First_Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Last_Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Vendors" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Attachment_1_attachmentName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Attachment_1_attachmentData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="Attachment_1_attachmentOrigSize" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="Attachment_2_attachmentName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Attachment_2_attachmentData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="Attachment_2_attachmentOrigSize" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="Attachment_3_attachmentName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Attachment_3_attachmentData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="Attachment_3_attachmentOrigSize" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="Attachment_4_attachmentName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Attachment_4_attachmentData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="Attachment_4_attachmentOrigSize" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="Attachment_5_attachmentName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Attachment_5_attachmentData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="Attachment_5_attachmentOrigSize" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="Vendor_Ref_" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Secure_Patient_Information" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CTS_Ticket" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Patient_Attachment1_attachmentName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Patient_Attachment1_attachmentData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="Patient_Attachment1_attachmentOrigSize" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="Patient_Attachment2_attachmentName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Patient_Attachment2_attachmentData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="Patient_Attachment2_attachmentOrigSize" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="Patient_Attachment3_attachmentName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Patient_Attachment3_attachmentData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="Patient_Attachment3_attachmentOrigSize" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="Patient_Attachment4_attachmentName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Patient_Attachment4_attachmentData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="Patient_Attachment4_attachmentOrigSize" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="Patient_Attachment5_attachmentName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Patient_Attachment5_attachmentData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="Patient_Attachment5_attachmentOrigSize" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="Customer_Ticket" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Integration_Attribute_02" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Integration_Attribute_03" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Foreign_Parent_Key" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Integration_Attribute_04" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Integration_Attribute_06" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Integration_Customer_Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Ticket_Submitter" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Ticket_Status" type="{urn:CMN:Integration:CreateInBoundNewTicket_WB}Ticket_StatusType" minOccurs="0"/>
 *         &lt;element name="Summary" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Floor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Suite" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Office" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Phone_Ext" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Pager-Numeric" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Pager_Pin" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Source" type="{urn:CMN:Integration:CreateInBoundNewTicket_WB}SourceType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InputMapping1", propOrder = {
    "submitter",
    "assignedTo",
    "status",
    "shortDescription",
    "department",
    "building",
    "client",
    "assetTag",
    "processed",
    "integrationAttribute08",
    "integrationAttribute01",
    "errorMessage",
    "phoneTest",
    "temp01",
    "temp02",
    "temp03",
    "additionalComments",
    "integrationAttribute07",
    "integrationAttribute05",
    "networkLogin",
    "resolution",
    "computerName",
    "rootCauseCategory",
    "title",
    "phoneWork",
    "emailAddress",
    "category",
    "type",
    "item",
    "assignedGroup",
    "description",
    "workLog",
    "assignedIndividual",
    "priority",
    "pendingReason",
    "firstName",
    "lastName",
    "vendors",
    "attachment1AttachmentName",
    "attachment1AttachmentData",
    "attachment1AttachmentOrigSize",
    "attachment2AttachmentName",
    "attachment2AttachmentData",
    "attachment2AttachmentOrigSize",
    "attachment3AttachmentName",
    "attachment3AttachmentData",
    "attachment3AttachmentOrigSize",
    "attachment4AttachmentName",
    "attachment4AttachmentData",
    "attachment4AttachmentOrigSize",
    "attachment5AttachmentName",
    "attachment5AttachmentData",
    "attachment5AttachmentOrigSize",
    "vendorRef",
    "securePatientInformation",
    "ctsTicket",
    "patientAttachment1AttachmentName",
    "patientAttachment1AttachmentData",
    "patientAttachment1AttachmentOrigSize",
    "patientAttachment2AttachmentName",
    "patientAttachment2AttachmentData",
    "patientAttachment2AttachmentOrigSize",
    "patientAttachment3AttachmentName",
    "patientAttachment3AttachmentData",
    "patientAttachment3AttachmentOrigSize",
    "patientAttachment4AttachmentName",
    "patientAttachment4AttachmentData",
    "patientAttachment4AttachmentOrigSize",
    "patientAttachment5AttachmentName",
    "patientAttachment5AttachmentData",
    "patientAttachment5AttachmentOrigSize",
    "customerTicket",
    "integrationAttribute02",
    "integrationAttribute03",
    "foreignParentKey",
    "integrationAttribute04",
    "integrationAttribute06",
    "integrationCustomerName",
    "ticketSubmitter",
    "ticketStatus",
    "summary",
    "floor",
    "suite",
    "office",
    "phoneExt",
    "pagerNumeric",
    "pagerPin",
    "source"
})
public class InputMapping1 {

    @XmlElement(name = "Submitter", required = true)
    protected String submitter;
    @XmlElement(name = "Assigned_To")
    protected String assignedTo;
    @XmlElement(name = "Status", required = true)
    @XmlSchemaType(name = "string")
    protected StatusType status;
    @XmlElement(name = "Short_Description", required = true)
    protected String shortDescription;
    @XmlElement(name = "Department")
    protected String department;
    @XmlElement(name = "Building")
    protected String building;
    @XmlElement(name = "Client")
    protected String client;
    @XmlElement(name = "Asset_Tag")
    protected String assetTag;
    @XmlElement(name = "Processed")
    protected String processed;
    @XmlElement(name = "Integration_Attribute_08")
    protected String integrationAttribute08;
    @XmlElement(name = "Integration_Attribute_01")
    protected String integrationAttribute01;
    @XmlElement(name = "Error_Message")
    protected String errorMessage;
    @XmlElement(name = "Phone_Test")
    protected String phoneTest;
    @XmlElement(name = "Temp01")
    protected Integer temp01;
    @XmlElement(name = "Temp02")
    protected String temp02;
    @XmlElement(name = "Temp03")
    protected String temp03;
    @XmlElement(name = "Additional_Comments")
    protected String additionalComments;
    @XmlElement(name = "Integration_Attribute_07")
    protected String integrationAttribute07;
    @XmlElement(name = "Integration_Attribute_05")
    protected String integrationAttribute05;
    @XmlElement(name = "Network_Login")
    protected String networkLogin;
    @XmlElement(name = "Resolution")
    protected String resolution;
    @XmlElement(name = "Computer_Name")
    protected String computerName;
    @XmlElement(name = "Root_Cause_Category")
    protected String rootCauseCategory;
    @XmlElementRef(name = "Title", namespace = "urn:CMN:Integration:CreateInBoundNewTicket_WB", type = JAXBElement.class, required = false)
    protected JAXBElement<TitleType> title;
    @XmlElement(name = "Phone-Work")
    protected String phoneWork;
    @XmlElement(name = "Email_Address")
    protected String emailAddress;
    @XmlElement(name = "Category")
    protected String category;
    @XmlElement(name = "Type")
    protected String type;
    @XmlElement(name = "Item")
    protected String item;
    @XmlElement(name = "Assigned_Group")
    protected String assignedGroup;
    @XmlElement(name = "Description")
    protected String description;
    @XmlElement(name = "Work_Log")
    protected String workLog;
    @XmlElement(name = "Assigned_Individual")
    protected String assignedIndividual;
    @XmlElementRef(name = "Priority", namespace = "urn:CMN:Integration:CreateInBoundNewTicket_WB", type = JAXBElement.class, required = false)
    protected JAXBElement<PriorityType> priority;
    @XmlElement(name = "Pending_Reason")
    protected String pendingReason;
    @XmlElement(name = "First_Name")
    protected String firstName;
    @XmlElement(name = "Last_Name")
    protected String lastName;
    @XmlElement(name = "Vendors")
    protected String vendors;
    @XmlElement(name = "Attachment_1_attachmentName")
    protected String attachment1AttachmentName;
    @XmlElement(name = "Attachment_1_attachmentData")
    protected byte[] attachment1AttachmentData;
    @XmlElement(name = "Attachment_1_attachmentOrigSize")
    protected Integer attachment1AttachmentOrigSize;
    @XmlElement(name = "Attachment_2_attachmentName")
    protected String attachment2AttachmentName;
    @XmlElement(name = "Attachment_2_attachmentData")
    protected byte[] attachment2AttachmentData;
    @XmlElement(name = "Attachment_2_attachmentOrigSize")
    protected Integer attachment2AttachmentOrigSize;
    @XmlElement(name = "Attachment_3_attachmentName")
    protected String attachment3AttachmentName;
    @XmlElement(name = "Attachment_3_attachmentData")
    protected byte[] attachment3AttachmentData;
    @XmlElement(name = "Attachment_3_attachmentOrigSize")
    protected Integer attachment3AttachmentOrigSize;
    @XmlElement(name = "Attachment_4_attachmentName")
    protected String attachment4AttachmentName;
    @XmlElement(name = "Attachment_4_attachmentData")
    protected byte[] attachment4AttachmentData;
    @XmlElement(name = "Attachment_4_attachmentOrigSize")
    protected Integer attachment4AttachmentOrigSize;
    @XmlElement(name = "Attachment_5_attachmentName")
    protected String attachment5AttachmentName;
    @XmlElement(name = "Attachment_5_attachmentData")
    protected byte[] attachment5AttachmentData;
    @XmlElement(name = "Attachment_5_attachmentOrigSize")
    protected Integer attachment5AttachmentOrigSize;
    @XmlElement(name = "Vendor_Ref_")
    protected String vendorRef;
    @XmlElement(name = "Secure_Patient_Information")
    protected String securePatientInformation;
    @XmlElement(name = "CTS_Ticket")
    protected String ctsTicket;
    @XmlElement(name = "Patient_Attachment1_attachmentName")
    protected String patientAttachment1AttachmentName;
    @XmlElement(name = "Patient_Attachment1_attachmentData")
    protected byte[] patientAttachment1AttachmentData;
    @XmlElement(name = "Patient_Attachment1_attachmentOrigSize")
    protected Integer patientAttachment1AttachmentOrigSize;
    @XmlElement(name = "Patient_Attachment2_attachmentName")
    protected String patientAttachment2AttachmentName;
    @XmlElement(name = "Patient_Attachment2_attachmentData")
    protected byte[] patientAttachment2AttachmentData;
    @XmlElement(name = "Patient_Attachment2_attachmentOrigSize")
    protected Integer patientAttachment2AttachmentOrigSize;
    @XmlElement(name = "Patient_Attachment3_attachmentName")
    protected String patientAttachment3AttachmentName;
    @XmlElement(name = "Patient_Attachment3_attachmentData")
    protected byte[] patientAttachment3AttachmentData;
    @XmlElement(name = "Patient_Attachment3_attachmentOrigSize")
    protected Integer patientAttachment3AttachmentOrigSize;
    @XmlElement(name = "Patient_Attachment4_attachmentName")
    protected String patientAttachment4AttachmentName;
    @XmlElement(name = "Patient_Attachment4_attachmentData")
    protected byte[] patientAttachment4AttachmentData;
    @XmlElement(name = "Patient_Attachment4_attachmentOrigSize")
    protected Integer patientAttachment4AttachmentOrigSize;
    @XmlElement(name = "Patient_Attachment5_attachmentName")
    protected String patientAttachment5AttachmentName;
    @XmlElement(name = "Patient_Attachment5_attachmentData")
    protected byte[] patientAttachment5AttachmentData;
    @XmlElement(name = "Patient_Attachment5_attachmentOrigSize")
    protected Integer patientAttachment5AttachmentOrigSize;
    @XmlElement(name = "Customer_Ticket")
    protected String customerTicket;
    @XmlElement(name = "Integration_Attribute_02")
    protected String integrationAttribute02;
    @XmlElement(name = "Integration_Attribute_03")
    protected String integrationAttribute03;
    @XmlElement(name = "Foreign_Parent_Key")
    protected String foreignParentKey;
    @XmlElement(name = "Integration_Attribute_04")
    protected String integrationAttribute04;
    @XmlElement(name = "Integration_Attribute_06")
    protected String integrationAttribute06;
    @XmlElement(name = "Integration_Customer_Name")
    protected String integrationCustomerName;
    @XmlElement(name = "Ticket_Submitter", defaultValue = "$USER$")
    protected String ticketSubmitter;
    @XmlElementRef(name = "Ticket_Status", namespace = "urn:CMN:Integration:CreateInBoundNewTicket_WB", type = JAXBElement.class, required = false)
    protected JAXBElement<TicketStatusType> ticketStatus;
    @XmlElement(name = "Summary")
    protected String summary;
    @XmlElement(name = "Floor")
    protected String floor;
    @XmlElement(name = "Suite")
    protected String suite;
    @XmlElement(name = "Office")
    protected String office;
    @XmlElement(name = "Phone_Ext")
    protected String phoneExt;
    @XmlElement(name = "Pager-Numeric")
    protected String pagerNumeric;
    @XmlElement(name = "Pager_Pin")
    protected String pagerPin;
    @XmlElementRef(name = "Source", namespace = "urn:CMN:Integration:CreateInBoundNewTicket_WB", type = JAXBElement.class, required = false)
    protected JAXBElement<SourceType> source;

    /**
     * Gets the value of the submitter property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubmitter() {
        return submitter;
    }

    /**
     * Sets the value of the submitter property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubmitter(String value) {
        this.submitter = value;
    }

    /**
     * Gets the value of the assignedTo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssignedTo() {
        return assignedTo;
    }

    /**
     * Sets the value of the assignedTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssignedTo(String value) {
        this.assignedTo = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link StatusType }
     *     
     */
    public StatusType getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusType }
     *     
     */
    public void setStatus(StatusType value) {
        this.status = value;
    }

    /**
     * Gets the value of the shortDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShortDescription() {
        return shortDescription;
    }

    /**
     * Sets the value of the shortDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShortDescription(String value) {
        this.shortDescription = value;
    }

    /**
     * Gets the value of the department property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDepartment() {
        return department;
    }

    /**
     * Sets the value of the department property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDepartment(String value) {
        this.department = value;
    }

    /**
     * Gets the value of the building property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBuilding() {
        return building;
    }

    /**
     * Sets the value of the building property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBuilding(String value) {
        this.building = value;
    }

    /**
     * Gets the value of the client property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClient() {
        return client;
    }

    /**
     * Sets the value of the client property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClient(String value) {
        this.client = value;
    }

    /**
     * Gets the value of the assetTag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssetTag() {
        return assetTag;
    }

    /**
     * Sets the value of the assetTag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssetTag(String value) {
        this.assetTag = value;
    }

    /**
     * Gets the value of the processed property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProcessed() {
        return processed;
    }

    /**
     * Sets the value of the processed property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProcessed(String value) {
        this.processed = value;
    }

    /**
     * Gets the value of the integrationAttribute08 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntegrationAttribute08() {
        return integrationAttribute08;
    }

    /**
     * Sets the value of the integrationAttribute08 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntegrationAttribute08(String value) {
        this.integrationAttribute08 = value;
    }

    /**
     * Gets the value of the integrationAttribute01 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntegrationAttribute01() {
        return integrationAttribute01;
    }

    /**
     * Sets the value of the integrationAttribute01 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntegrationAttribute01(String value) {
        this.integrationAttribute01 = value;
    }

    /**
     * Gets the value of the errorMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     * Sets the value of the errorMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorMessage(String value) {
        this.errorMessage = value;
    }

    /**
     * Gets the value of the phoneTest property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhoneTest() {
        return phoneTest;
    }

    /**
     * Sets the value of the phoneTest property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhoneTest(String value) {
        this.phoneTest = value;
    }

    /**
     * Gets the value of the temp01 property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTemp01() {
        return temp01;
    }

    /**
     * Sets the value of the temp01 property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTemp01(Integer value) {
        this.temp01 = value;
    }

    /**
     * Gets the value of the temp02 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTemp02() {
        return temp02;
    }

    /**
     * Sets the value of the temp02 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTemp02(String value) {
        this.temp02 = value;
    }

    /**
     * Gets the value of the temp03 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTemp03() {
        return temp03;
    }

    /**
     * Sets the value of the temp03 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTemp03(String value) {
        this.temp03 = value;
    }

    /**
     * Gets the value of the additionalComments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdditionalComments() {
        return additionalComments;
    }

    /**
     * Sets the value of the additionalComments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdditionalComments(String value) {
        this.additionalComments = value;
    }

    /**
     * Gets the value of the integrationAttribute07 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntegrationAttribute07() {
        return integrationAttribute07;
    }

    /**
     * Sets the value of the integrationAttribute07 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntegrationAttribute07(String value) {
        this.integrationAttribute07 = value;
    }

    /**
     * Gets the value of the integrationAttribute05 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntegrationAttribute05() {
        return integrationAttribute05;
    }

    /**
     * Sets the value of the integrationAttribute05 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntegrationAttribute05(String value) {
        this.integrationAttribute05 = value;
    }

    /**
     * Gets the value of the networkLogin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNetworkLogin() {
        return networkLogin;
    }

    /**
     * Sets the value of the networkLogin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNetworkLogin(String value) {
        this.networkLogin = value;
    }

    /**
     * Gets the value of the resolution property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResolution() {
        return resolution;
    }

    /**
     * Sets the value of the resolution property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResolution(String value) {
        this.resolution = value;
    }

    /**
     * Gets the value of the computerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComputerName() {
        return computerName;
    }

    /**
     * Sets the value of the computerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComputerName(String value) {
        this.computerName = value;
    }

    /**
     * Gets the value of the rootCauseCategory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRootCauseCategory() {
        return rootCauseCategory;
    }

    /**
     * Sets the value of the rootCauseCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRootCauseCategory(String value) {
        this.rootCauseCategory = value;
    }

    /**
     * Gets the value of the title property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link TitleType }{@code >}
     *     
     */
    public JAXBElement<TitleType> getTitle() {
        return title;
    }

    /**
     * Sets the value of the title property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link TitleType }{@code >}
     *     
     */
    public void setTitle(JAXBElement<TitleType> value) {
        this.title = value;
    }

    /**
     * Gets the value of the phoneWork property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhoneWork() {
        return phoneWork;
    }

    /**
     * Sets the value of the phoneWork property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhoneWork(String value) {
        this.phoneWork = value;
    }

    /**
     * Gets the value of the emailAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * Sets the value of the emailAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailAddress(String value) {
        this.emailAddress = value;
    }

    /**
     * Gets the value of the category property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCategory() {
        return category;
    }

    /**
     * Sets the value of the category property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCategory(String value) {
        this.category = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the item property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItem() {
        return item;
    }

    /**
     * Sets the value of the item property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItem(String value) {
        this.item = value;
    }

    /**
     * Gets the value of the assignedGroup property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssignedGroup() {
        return assignedGroup;
    }

    /**
     * Sets the value of the assignedGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssignedGroup(String value) {
        this.assignedGroup = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the workLog property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWorkLog() {
        return workLog;
    }

    /**
     * Sets the value of the workLog property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWorkLog(String value) {
        this.workLog = value;
    }

    /**
     * Gets the value of the assignedIndividual property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssignedIndividual() {
        return assignedIndividual;
    }

    /**
     * Sets the value of the assignedIndividual property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssignedIndividual(String value) {
        this.assignedIndividual = value;
    }

    /**
     * Gets the value of the priority property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link PriorityType }{@code >}
     *     
     */
    public JAXBElement<PriorityType> getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link PriorityType }{@code >}
     *     
     */
    public void setPriority(JAXBElement<PriorityType> value) {
        this.priority = value;
    }

    /**
     * Gets the value of the pendingReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPendingReason() {
        return pendingReason;
    }

    /**
     * Sets the value of the pendingReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPendingReason(String value) {
        this.pendingReason = value;
    }

    /**
     * Gets the value of the firstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the value of the firstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirstName(String value) {
        this.firstName = value;
    }

    /**
     * Gets the value of the lastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    /**
     * Gets the value of the vendors property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVendors() {
        return vendors;
    }

    /**
     * Sets the value of the vendors property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVendors(String value) {
        this.vendors = value;
    }

    /**
     * Gets the value of the attachment1AttachmentName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAttachment1AttachmentName() {
        return attachment1AttachmentName;
    }

    /**
     * Sets the value of the attachment1AttachmentName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAttachment1AttachmentName(String value) {
        this.attachment1AttachmentName = value;
    }

    /**
     * Gets the value of the attachment1AttachmentData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getAttachment1AttachmentData() {
        return attachment1AttachmentData;
    }

    /**
     * Sets the value of the attachment1AttachmentData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setAttachment1AttachmentData(byte[] value) {
        this.attachment1AttachmentData = value;
    }

    /**
     * Gets the value of the attachment1AttachmentOrigSize property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAttachment1AttachmentOrigSize() {
        return attachment1AttachmentOrigSize;
    }

    /**
     * Sets the value of the attachment1AttachmentOrigSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAttachment1AttachmentOrigSize(Integer value) {
        this.attachment1AttachmentOrigSize = value;
    }

    /**
     * Gets the value of the attachment2AttachmentName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAttachment2AttachmentName() {
        return attachment2AttachmentName;
    }

    /**
     * Sets the value of the attachment2AttachmentName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAttachment2AttachmentName(String value) {
        this.attachment2AttachmentName = value;
    }

    /**
     * Gets the value of the attachment2AttachmentData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getAttachment2AttachmentData() {
        return attachment2AttachmentData;
    }

    /**
     * Sets the value of the attachment2AttachmentData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setAttachment2AttachmentData(byte[] value) {
        this.attachment2AttachmentData = value;
    }

    /**
     * Gets the value of the attachment2AttachmentOrigSize property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAttachment2AttachmentOrigSize() {
        return attachment2AttachmentOrigSize;
    }

    /**
     * Sets the value of the attachment2AttachmentOrigSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAttachment2AttachmentOrigSize(Integer value) {
        this.attachment2AttachmentOrigSize = value;
    }

    /**
     * Gets the value of the attachment3AttachmentName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAttachment3AttachmentName() {
        return attachment3AttachmentName;
    }

    /**
     * Sets the value of the attachment3AttachmentName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAttachment3AttachmentName(String value) {
        this.attachment3AttachmentName = value;
    }

    /**
     * Gets the value of the attachment3AttachmentData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getAttachment3AttachmentData() {
        return attachment3AttachmentData;
    }

    /**
     * Sets the value of the attachment3AttachmentData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setAttachment3AttachmentData(byte[] value) {
        this.attachment3AttachmentData = value;
    }

    /**
     * Gets the value of the attachment3AttachmentOrigSize property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAttachment3AttachmentOrigSize() {
        return attachment3AttachmentOrigSize;
    }

    /**
     * Sets the value of the attachment3AttachmentOrigSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAttachment3AttachmentOrigSize(Integer value) {
        this.attachment3AttachmentOrigSize = value;
    }

    /**
     * Gets the value of the attachment4AttachmentName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAttachment4AttachmentName() {
        return attachment4AttachmentName;
    }

    /**
     * Sets the value of the attachment4AttachmentName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAttachment4AttachmentName(String value) {
        this.attachment4AttachmentName = value;
    }

    /**
     * Gets the value of the attachment4AttachmentData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getAttachment4AttachmentData() {
        return attachment4AttachmentData;
    }

    /**
     * Sets the value of the attachment4AttachmentData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setAttachment4AttachmentData(byte[] value) {
        this.attachment4AttachmentData = value;
    }

    /**
     * Gets the value of the attachment4AttachmentOrigSize property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAttachment4AttachmentOrigSize() {
        return attachment4AttachmentOrigSize;
    }

    /**
     * Sets the value of the attachment4AttachmentOrigSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAttachment4AttachmentOrigSize(Integer value) {
        this.attachment4AttachmentOrigSize = value;
    }

    /**
     * Gets the value of the attachment5AttachmentName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAttachment5AttachmentName() {
        return attachment5AttachmentName;
    }

    /**
     * Sets the value of the attachment5AttachmentName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAttachment5AttachmentName(String value) {
        this.attachment5AttachmentName = value;
    }

    /**
     * Gets the value of the attachment5AttachmentData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getAttachment5AttachmentData() {
        return attachment5AttachmentData;
    }

    /**
     * Sets the value of the attachment5AttachmentData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setAttachment5AttachmentData(byte[] value) {
        this.attachment5AttachmentData = value;
    }

    /**
     * Gets the value of the attachment5AttachmentOrigSize property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAttachment5AttachmentOrigSize() {
        return attachment5AttachmentOrigSize;
    }

    /**
     * Sets the value of the attachment5AttachmentOrigSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAttachment5AttachmentOrigSize(Integer value) {
        this.attachment5AttachmentOrigSize = value;
    }

    /**
     * Gets the value of the vendorRef property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVendorRef() {
        return vendorRef;
    }

    /**
     * Sets the value of the vendorRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVendorRef(String value) {
        this.vendorRef = value;
    }

    /**
     * Gets the value of the securePatientInformation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSecurePatientInformation() {
        return securePatientInformation;
    }

    /**
     * Sets the value of the securePatientInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSecurePatientInformation(String value) {
        this.securePatientInformation = value;
    }

    /**
     * Gets the value of the ctsTicket property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCTSTicket() {
        return ctsTicket;
    }

    /**
     * Sets the value of the ctsTicket property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCTSTicket(String value) {
        this.ctsTicket = value;
    }

    /**
     * Gets the value of the patientAttachment1AttachmentName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPatientAttachment1AttachmentName() {
        return patientAttachment1AttachmentName;
    }

    /**
     * Sets the value of the patientAttachment1AttachmentName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPatientAttachment1AttachmentName(String value) {
        this.patientAttachment1AttachmentName = value;
    }

    /**
     * Gets the value of the patientAttachment1AttachmentData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getPatientAttachment1AttachmentData() {
        return patientAttachment1AttachmentData;
    }

    /**
     * Sets the value of the patientAttachment1AttachmentData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setPatientAttachment1AttachmentData(byte[] value) {
        this.patientAttachment1AttachmentData = value;
    }

    /**
     * Gets the value of the patientAttachment1AttachmentOrigSize property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPatientAttachment1AttachmentOrigSize() {
        return patientAttachment1AttachmentOrigSize;
    }

    /**
     * Sets the value of the patientAttachment1AttachmentOrigSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPatientAttachment1AttachmentOrigSize(Integer value) {
        this.patientAttachment1AttachmentOrigSize = value;
    }

    /**
     * Gets the value of the patientAttachment2AttachmentName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPatientAttachment2AttachmentName() {
        return patientAttachment2AttachmentName;
    }

    /**
     * Sets the value of the patientAttachment2AttachmentName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPatientAttachment2AttachmentName(String value) {
        this.patientAttachment2AttachmentName = value;
    }

    /**
     * Gets the value of the patientAttachment2AttachmentData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getPatientAttachment2AttachmentData() {
        return patientAttachment2AttachmentData;
    }

    /**
     * Sets the value of the patientAttachment2AttachmentData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setPatientAttachment2AttachmentData(byte[] value) {
        this.patientAttachment2AttachmentData = value;
    }

    /**
     * Gets the value of the patientAttachment2AttachmentOrigSize property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPatientAttachment2AttachmentOrigSize() {
        return patientAttachment2AttachmentOrigSize;
    }

    /**
     * Sets the value of the patientAttachment2AttachmentOrigSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPatientAttachment2AttachmentOrigSize(Integer value) {
        this.patientAttachment2AttachmentOrigSize = value;
    }

    /**
     * Gets the value of the patientAttachment3AttachmentName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPatientAttachment3AttachmentName() {
        return patientAttachment3AttachmentName;
    }

    /**
     * Sets the value of the patientAttachment3AttachmentName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPatientAttachment3AttachmentName(String value) {
        this.patientAttachment3AttachmentName = value;
    }

    /**
     * Gets the value of the patientAttachment3AttachmentData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getPatientAttachment3AttachmentData() {
        return patientAttachment3AttachmentData;
    }

    /**
     * Sets the value of the patientAttachment3AttachmentData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setPatientAttachment3AttachmentData(byte[] value) {
        this.patientAttachment3AttachmentData = value;
    }

    /**
     * Gets the value of the patientAttachment3AttachmentOrigSize property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPatientAttachment3AttachmentOrigSize() {
        return patientAttachment3AttachmentOrigSize;
    }

    /**
     * Sets the value of the patientAttachment3AttachmentOrigSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPatientAttachment3AttachmentOrigSize(Integer value) {
        this.patientAttachment3AttachmentOrigSize = value;
    }

    /**
     * Gets the value of the patientAttachment4AttachmentName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPatientAttachment4AttachmentName() {
        return patientAttachment4AttachmentName;
    }

    /**
     * Sets the value of the patientAttachment4AttachmentName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPatientAttachment4AttachmentName(String value) {
        this.patientAttachment4AttachmentName = value;
    }

    /**
     * Gets the value of the patientAttachment4AttachmentData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getPatientAttachment4AttachmentData() {
        return patientAttachment4AttachmentData;
    }

    /**
     * Sets the value of the patientAttachment4AttachmentData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setPatientAttachment4AttachmentData(byte[] value) {
        this.patientAttachment4AttachmentData = value;
    }

    /**
     * Gets the value of the patientAttachment4AttachmentOrigSize property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPatientAttachment4AttachmentOrigSize() {
        return patientAttachment4AttachmentOrigSize;
    }

    /**
     * Sets the value of the patientAttachment4AttachmentOrigSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPatientAttachment4AttachmentOrigSize(Integer value) {
        this.patientAttachment4AttachmentOrigSize = value;
    }

    /**
     * Gets the value of the patientAttachment5AttachmentName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPatientAttachment5AttachmentName() {
        return patientAttachment5AttachmentName;
    }

    /**
     * Sets the value of the patientAttachment5AttachmentName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPatientAttachment5AttachmentName(String value) {
        this.patientAttachment5AttachmentName = value;
    }

    /**
     * Gets the value of the patientAttachment5AttachmentData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getPatientAttachment5AttachmentData() {
        return patientAttachment5AttachmentData;
    }

    /**
     * Sets the value of the patientAttachment5AttachmentData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setPatientAttachment5AttachmentData(byte[] value) {
        this.patientAttachment5AttachmentData = value;
    }

    /**
     * Gets the value of the patientAttachment5AttachmentOrigSize property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPatientAttachment5AttachmentOrigSize() {
        return patientAttachment5AttachmentOrigSize;
    }

    /**
     * Sets the value of the patientAttachment5AttachmentOrigSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPatientAttachment5AttachmentOrigSize(Integer value) {
        this.patientAttachment5AttachmentOrigSize = value;
    }

    /**
     * Gets the value of the customerTicket property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerTicket() {
        return customerTicket;
    }

    /**
     * Sets the value of the customerTicket property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerTicket(String value) {
        this.customerTicket = value;
    }

    /**
     * Gets the value of the integrationAttribute02 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntegrationAttribute02() {
        return integrationAttribute02;
    }

    /**
     * Sets the value of the integrationAttribute02 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntegrationAttribute02(String value) {
        this.integrationAttribute02 = value;
    }

    /**
     * Gets the value of the integrationAttribute03 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntegrationAttribute03() {
        return integrationAttribute03;
    }

    /**
     * Sets the value of the integrationAttribute03 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntegrationAttribute03(String value) {
        this.integrationAttribute03 = value;
    }

    /**
     * Gets the value of the foreignParentKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getForeignParentKey() {
        return foreignParentKey;
    }

    /**
     * Sets the value of the foreignParentKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setForeignParentKey(String value) {
        this.foreignParentKey = value;
    }

    /**
     * Gets the value of the integrationAttribute04 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntegrationAttribute04() {
        return integrationAttribute04;
    }

    /**
     * Sets the value of the integrationAttribute04 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntegrationAttribute04(String value) {
        this.integrationAttribute04 = value;
    }

    /**
     * Gets the value of the integrationAttribute06 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntegrationAttribute06() {
        return integrationAttribute06;
    }

    /**
     * Sets the value of the integrationAttribute06 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntegrationAttribute06(String value) {
        this.integrationAttribute06 = value;
    }

    /**
     * Gets the value of the integrationCustomerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntegrationCustomerName() {
        return integrationCustomerName;
    }

    /**
     * Sets the value of the integrationCustomerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntegrationCustomerName(String value) {
        this.integrationCustomerName = value;
    }

    /**
     * Gets the value of the ticketSubmitter property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTicketSubmitter() {
        return ticketSubmitter;
    }

    /**
     * Sets the value of the ticketSubmitter property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTicketSubmitter(String value) {
        this.ticketSubmitter = value;
    }

    /**
     * Gets the value of the ticketStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link TicketStatusType }{@code >}
     *     
     */
    public JAXBElement<TicketStatusType> getTicketStatus() {
        return ticketStatus;
    }

    /**
     * Sets the value of the ticketStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link TicketStatusType }{@code >}
     *     
     */
    public void setTicketStatus(JAXBElement<TicketStatusType> value) {
        this.ticketStatus = value;
    }

    /**
     * Gets the value of the summary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSummary() {
        return summary;
    }

    /**
     * Sets the value of the summary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSummary(String value) {
        this.summary = value;
    }

    /**
     * Gets the value of the floor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFloor() {
        return floor;
    }

    /**
     * Sets the value of the floor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFloor(String value) {
        this.floor = value;
    }

    /**
     * Gets the value of the suite property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuite() {
        return suite;
    }

    /**
     * Sets the value of the suite property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuite(String value) {
        this.suite = value;
    }

    /**
     * Gets the value of the office property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOffice() {
        return office;
    }

    /**
     * Sets the value of the office property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOffice(String value) {
        this.office = value;
    }

    /**
     * Gets the value of the phoneExt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhoneExt() {
        return phoneExt;
    }

    /**
     * Sets the value of the phoneExt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhoneExt(String value) {
        this.phoneExt = value;
    }

    /**
     * Gets the value of the pagerNumeric property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPagerNumeric() {
        return pagerNumeric;
    }

    /**
     * Sets the value of the pagerNumeric property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPagerNumeric(String value) {
        this.pagerNumeric = value;
    }

    /**
     * Gets the value of the pagerPin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPagerPin() {
        return pagerPin;
    }

    /**
     * Sets the value of the pagerPin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPagerPin(String value) {
        this.pagerPin = value;
    }

    /**
     * Gets the value of the source property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link SourceType }{@code >}
     *     
     */
    public JAXBElement<SourceType> getSource() {
        return source;
    }

    /**
     * Sets the value of the source property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link SourceType }{@code >}
     *     
     */
    public void setSource(JAXBElement<SourceType> value) {
        this.source = value;
    }

}
