/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.caretech.ticket.webservice.exception;


public class InvalidDataMappingXMLException extends BaseException {

    /**
	 * 
	 */
	private static final long serialVersionUID = 3855797499214402076L;

	/**
     *
     * @param errorCode
     * @param errorMessage
     */
    public InvalidDataMappingXMLException(String errorCode, String errorMessage) {
        super(errorCode, errorMessage);
    }
}
