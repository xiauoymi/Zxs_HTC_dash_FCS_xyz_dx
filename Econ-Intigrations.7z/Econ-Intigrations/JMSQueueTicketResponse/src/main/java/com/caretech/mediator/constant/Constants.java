package com.caretech.mediator.constant;

/**
 * @author gopinathn
 *
 */ 
public class Constants {
	
	public static final String REQUEST_PRODUCES="application/xml";
	public static final String REQUEST_HEADERS="content-type=application/x-www-form-urlencoded";
	public static final String MANDATORY_PARAMETER_XML_FILE_PATH = "/com/caretech/webservice/resource/url-mandatory-parameters.xml";
	public static final String DATA_MAPPING_XML_FILE_PATH = "/com/caretech/webservice/resource/";
	public static final String EMPTY_STRING=" ";
	public static final String PRODUCE_JSON ="application/json";
	public static final String PRODUCE_XML = "application/xml";
	public static final Object SERVICE_NAME = "ServiceName";
	public static final String DATA_TRANSFORMATION_XML = "data_transformation";
	public static String WSDL_URL = "https://supportws.ctsmartdesk.com/arsys/WSDL/public/ars.ctsmartdesk.com/CMN:Integration:CreateInBoundTicket_WB";
	public static String WSDL_AUTHENTICATION_USERNAME = "CTS-WEBSERVICE";
	public static String WSDL_AUTHENTICATION_PASSWORD = "w3bs3rvice";
	public static String USERNAME = "admin";
	public static String PASSWORD = "123Welcome";
    public static final String STATUS_FAILED = "FAILED";
    public static final String STATUS_PASSED = "PASSED";
    public static final String STATUS_SUCCESS = "SUCCESS";
    public static final String ASSIGNMENT_GROUP_CARETECH_FIRST_LEVEL = "CTS-RES CTR-1ST LEVEL";
    public static final String CATEGORY_CLINICAL_SOFTWARE = "clinical software";
    public static final String STATE_CLOSED = "Closed";
    public static final String STATE_RESOLVED = "Resolved";
    public static final String NULL_STRING = "NULL";
    public static final String OPENED_BY_INBOUND_EMAIL = "Inbound Email";
    
    
    public static final String PARAM_SOURCE = "source";
    public static final String PARAM_DESTINATION = "destination";
    public static final String PARAM_REQUEST_PARAMETER = "requestParameter";
    public static final String PARAM_REQUEST_MESSAGE_ID = "requestMessageId";
    public static final String PARAM_ESB_OUT_TIME = "esbInTime";
    public static final String PARAM_SNOW_OUT_TIME = "snowOutTime";
    public static final String PARAM_RESPONSE_PARAMETER = "responseParameter";
    public static final String PARAM_RESPONSE_MESSAGE_ID = "responseMessageId";
    public static final String PARAM_REMEDY_TICKET_NUMBER = "remedyNumber";
    public static final String PARAM_SNOW_TICKET_NUMBER = "snowTicket";
    public static final String PARAM_INTIME_TO_ESB = "inTimeToESB";
    public static final String PARAM_INTIME_TO_SNOW = "inTimeToSnow";
    public static final String STATUS = "STATUS";
    public static final String MESSAGE = "MESSAGE";
    public static final String MODE = "mode";
    public static final String DATE = "date";
    public static final String CREATE = "Create";
    public static final String UPDATE = "Update";
    public static final String PARAM_OUTTIME_FROM_ESB = "outTimeFromESB";
    public static final String PARAM_OUTTIME_FROM_SNOW = "outTimeFromSnow";
    public static final String PARAM_STATUS = "status";
}
