/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.caretech.ticket.webservice.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author viswanathane
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "client")
public class ClientDTO {

	@XmlElement(name = "clientKey")
    private String clientKey;
	@XmlElement(name = "clientSecret")
    private String clientSecret;
	
	/**
	 * @return the clientKey
	 */
	public String getClientKey() {
		return clientKey;
	}
	/**
	 * @param clientKey the clientKey to set
	 */
	public void setClientKey(String clientKey) {
		this.clientKey = clientKey;
	}
	/**
	 * @return the clientSecret
	 */
	public String getClientSecret() {
		return clientSecret;
	}
	/**
	 * @param clientSecret the clientSecret to set
	 */
	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}
	
	
}
