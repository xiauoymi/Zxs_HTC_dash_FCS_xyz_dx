/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.caretech.ticket.webservice.exception;


public class BaseException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -873465820296266673L;
	private String errorCode, errorMessage;

    /**
     *
     * @param errorCode
     * @param errorMessage
     */
    public BaseException(String errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    /**
     *
     * @return
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     *
     * @param errorCode
     */
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    /**
     *
     * @return
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     *
     * @param errorMessage
     */
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
