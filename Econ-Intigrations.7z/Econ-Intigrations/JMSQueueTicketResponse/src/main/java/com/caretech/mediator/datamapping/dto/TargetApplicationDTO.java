/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.caretech.mediator.datamapping.dto;

import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author gopinathn
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "object")
public class TargetApplicationDTO {

    //Attributes
	@XmlElement(name = "url")
    private String url;
	@XmlElement(name = "host")
    private String host;
	@XmlElement(name = "credentialRequired")
    private String credentialRequired;
	@XmlElement(name = "userName")
    private String userName;
	@XmlElement(name = "password")
    private String password;
    @XmlElement(name = "contentType")
    private String contentType;
    @XmlElement(name = "targetSystem")
    private String targetSystem;
    @XmlElement(name = "convertor")
    private String convertor;
    @XmlElement(name = "incidentUrl")
    private String incidentUrl;
    @XmlElement(name = "attachmentUrl")
    private String attachmentUrl;
    
    private Map<String, Object> requestParam;
	/**
	 * @return the requestParam
	 */
	public Map<String, Object> getRequestParam() {
		return requestParam;
	}
	/**
	 * @param requestParam the requestParam to set
	 */
	public void setRequestParam(Map<String, Object> requestParam) {
		this.requestParam = requestParam;
	}
	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}
	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}
	/**
	 * @return the host
	 */
	public String getHost() {
		return host;
	}
	/**
	 * @param host the host to set
	 */
	public void setHost(String host) {
		this.host = host;
	}
	/**
	 * @return the credentialRequired
	 */
	public String getCredentialRequired() {
		return credentialRequired;
	}
	/**
	 * @param credentialRequired the credentialRequired to set
	 */
	public void setCredentialRequired(String credentialRequired) {
		this.credentialRequired = credentialRequired;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the contentType
	 */
	public String getContentType() {
		return contentType;
	}
	/**
	 * @param contentType the contentType to set
	 */
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	/**
	 * @return the targetSystem
	 */
	public String getTargetSystem() {
		return targetSystem;
	}
	/**
	 * @param targetSystem the targetSystem to set
	 */
	public void setTargetSystem(String targetSystem) {
		this.targetSystem = targetSystem;
	}
	/**
	 * @return the convertor
	 */
	public String getConvertor() {
		return convertor;
	}
	/**
	 * @param convertor the convertor to set
	 */
	public void setConvertor(String convertor) {
		this.convertor = convertor;
	}
	/**
	 * @return the incidentUrl
	 */
	public String getIncidentUrl() {
		return incidentUrl;
	}
	/**
	 * @param incidentUrl the incidentUrl to set
	 */
	public void setIncidentUrl(String incidentUrl) {
		this.incidentUrl = incidentUrl;
	}
	public String getAttachmentUrl() {
		return attachmentUrl;
	}
	public void setAttachmentUrl(String attachmentUrl) {
		this.attachmentUrl = attachmentUrl;
	}

	
}
