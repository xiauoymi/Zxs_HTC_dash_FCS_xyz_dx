package com.caretech.mediator.processor;

import java.util.Date;
import java.util.Map;

import java.util.logging.Logger;

import com.caretech.mediator.constant.Constants;
import com.caretech.webservice.datasync.CMNIntegrationFoundationDataSyncWSService;
import com.caretech.webservice.datasync.FoundationDataPortType;
import com.caretech.webservice.datasync.TransactionTypeType;
import com.caretech.webservice.integration.create.AuthenticationInfo;
import com.caretech.webservice.integration.create.StatusType;
import com.caretech.mediator.utils.Utilities;

public class RemedyDataSyncProcessor {
	
	private Logger LOGGER = Logger.getLogger(RemedyDataSyncProcessor.class.getName());
	private  String submitter;
	private  String assignedTo;
	private  StatusType status;  
    private  String shortDescription;
    private  String formName;
	private  String clientField1;
    private  String clientField2;
    private  String primaryKey;
    private  String clientField3;
    private TransactionTypeType transactionType;
    private String client = "MIA1";
    private  String clientField4;
    private  String clientField5;
    private  String clientFieldLabel1;
    private  String clientFieldLabel2;
    private  String clientFieldLabel3;
    private  String clientFieldLabel4;
    private  String clientFieldLabel5;
    private  AuthenticationInfo parameters = new AuthenticationInfo(Constants.WSDL_AUTHENTICATION_USERNAME, 
    						Constants.WSDL_AUTHENTICATION_PASSWORD, "", "", "");

		
	public String userDataSync(Map<String, Object> remedyParameters)throws Exception {
		System.out.println("in user data sync!!!!!!!!!!!!");
		String response = null;
		//synchronized (remedyParameters) {
			
			Date startTime = new Date();
			LOGGER.info("Remedy Data Sync call starts :"+Utilities.getCurrentDateTime(startTime));
			submitter = "NA";
			formName = (String)remedyParameters.get("Form_Name");
			primaryKey = (String)remedyParameters.get("Primary_Key");
			formName = (String)remedyParameters.get("Form_Name");
			//client = (String)remedyParameters.get("Client");
			shortDescription = "NA";
			status = remedyParameters.get("Status") != null ? StatusType.fromValue((String)remedyParameters.get("Status")) : null;
			clientField1 = (remedyParameters.get("Client_Field_1") != null &&
					!Constants.NULL_STRING.equals((String)remedyParameters.get("Client_Field_1")))? (String)remedyParameters.get("Client_Field_1") : "";
			clientField2 = (remedyParameters.get("Client_Field_2") != null &&
					!Constants.NULL_STRING.equals((String)remedyParameters.get("Client_Field_2")))? (String)remedyParameters.get("Client_Field_2") : "";
			clientField3 = (remedyParameters.get("Client_Field_3") != null &&
					!Constants.NULL_STRING.equals((String)remedyParameters.get("Client_Field_3")))? (String)remedyParameters.get("Client_Field_3") : "";
			clientField4 = (remedyParameters.get("Client_Field_4") != null &&
					!Constants.NULL_STRING.equals((String)remedyParameters.get("Client_Field_4")))? (String)remedyParameters.get("Client_Field_4") : "";
			
			CMNIntegrationFoundationDataSyncWSService createService = new CMNIntegrationFoundationDataSyncWSService();
			FoundationDataPortType dataSyncCreate = createService.getFoundationDataSoap();
			LOGGER.info("Field mapping value : ");
			LOGGER.info("clientField1 : "+clientField1);
			LOGGER.info("clientField2 : "+clientField2);
			LOGGER.info("clientField3 : "+clientField3);
			LOGGER.info("clientField4 : "+clientField4);
			LOGGER.info("primaryKey : "+primaryKey);
			LOGGER.info("FormName : "+formName);
			LOGGER.info("Client : "+client);
			
			response = dataSyncCreate.newCreateOperation0(submitter, 
					assignedTo, 
					status, 
					shortDescription, 
					formName, 
					clientField1,
					clientField2,
					clientField4,
					clientField5,
					clientFieldLabel4,
					clientFieldLabel1,
					clientFieldLabel2,
					clientFieldLabel5,
					clientFieldLabel3,
					clientField3,
					transactionType,
					client,
					primaryKey,
					parameters);		
			LOGGER.info("Response : "+response);
			Date endTime = new Date();
			LOGGER.info("Remedy Data Sync call ends :"+Utilities.getCurrentDateTime(endTime));
			LOGGER.info("Remedy Data Sync call duration :"+Utilities.getTimeDifference(startTime, endTime));
		//}
		return response;

	}
	
	public String cmdbDataSync(Map<String, Object> remedyParameters)throws Exception {
		Date startTime = new Date();
		LOGGER.info("Remedy Data Sync call starts :"+Utilities.getCurrentDateTime(startTime));
		status = StatusType.fromValue((String)remedyParameters.get("Status"));
		submitter = "NA";
		shortDescription = "NA";
		//client = (String)remedyParameters.get("Client");
		clientField1 = (String)remedyParameters.get("Client_Field_1");
		clientField3 = (String)remedyParameters.get("Client_Field_3");
		primaryKey = (String)remedyParameters.get("Primary_Key");
		formName = (String)remedyParameters.get("Form_Name");
		clientField2 = formName;
		
		CMNIntegrationFoundationDataSyncWSService createService = new CMNIntegrationFoundationDataSyncWSService();
		FoundationDataPortType dataSyncCreate = createService.getFoundationDataSoap();
		LOGGER.info("Field mapping value : ");
		LOGGER.info("clientField1 : "+clientField1);
		LOGGER.info("clientField2 : "+clientField2);
		LOGGER.info("clientField3 : "+clientField3);
		LOGGER.info("primaryKey : "+primaryKey);
		LOGGER.info("Client : "+client);
		
		String response = dataSyncCreate.newCreateOperation0(submitter, 
				assignedTo, 
				status, 
				shortDescription, 
				formName, 
				clientField1,
				clientField2,
				clientField4,
				clientField5,
				clientFieldLabel4,
				clientFieldLabel1,
				clientFieldLabel2,
				clientFieldLabel5,
				clientFieldLabel3,
				clientField3,
				transactionType,
				client,
				primaryKey,
				parameters);		
		LOGGER.info("Response : "+response);
		Date endTime = new Date();
		LOGGER.info("Remedy Data Sync call ends :"+Utilities.getCurrentDateTime(endTime));
		LOGGER.info("Remedy Data Sync call duration :"+Utilities.getTimeDifference(startTime, endTime));
		return response;

	}

	public String locationDataSync(Map<String, Object> remedyParameters)throws Exception {
	
	Date startTime = new Date();
	LOGGER.info("Remedy Data Sync call starts :"+Utilities.getCurrentDateTime(startTime));
	submitter = "NA";
	shortDescription = "NA";
	//client = (String)remedyParameters.get("Client");
	status = StatusType.fromValue((String)remedyParameters.get("Status"));
	clientField1 = (String)remedyParameters.get("Client_Field_1");
	clientField3 = (String)remedyParameters.get("Client_Field_3");
	//clientField2 = (String)remedyParameters.get("Form_Name");
	primaryKey = (String)remedyParameters.get("Primary_Key");
	formName = (String)remedyParameters.get("Form_Name");
	clientField2 = formName;
	
	CMNIntegrationFoundationDataSyncWSService createService = new CMNIntegrationFoundationDataSyncWSService();
	FoundationDataPortType dataSyncCreate = createService.getFoundationDataSoap();
	LOGGER.info("Field mapping value : ");
	LOGGER.info("clientField1 : "+clientField1);
	LOGGER.info("clientField2 : "+clientField2);
	LOGGER.info("clientField3 : "+clientField3);
	LOGGER.info("primaryKey : "+primaryKey);
	LOGGER.info("FormName : "+formName);
	LOGGER.info("Status : "+status);
	LOGGER.info("Client : "+client);
	
	String response = dataSyncCreate.newCreateOperation0(submitter, 
			assignedTo, 
			status, 
			shortDescription, 
			formName, 
			clientField1,
			clientField2,
			clientField4,
			clientField5,
			clientFieldLabel4,
			clientFieldLabel1,
			clientFieldLabel2,
			clientFieldLabel5,
			clientFieldLabel3,
			clientField3,
			transactionType,
			client,
			primaryKey,
			parameters);		
	LOGGER.info("Response : "+response);
	Date endTime = new Date();
	LOGGER.info("Remedy Data Sync call ends :"+Utilities.getCurrentDateTime(endTime));
	LOGGER.info("Remedy Data Sync call duration :"+Utilities.getTimeDifference(startTime, endTime));
	return response;

}
	public String choiceDataSync(Map<String, Object> remedyParameters)throws Exception {
		
		Date startTime = new Date();
		LOGGER.info("Remedy Data Sync call starts :"+Utilities.getCurrentDateTime(startTime));
		status = StatusType.fromValue((String)remedyParameters.get("Status"));
		submitter = "NA";
		shortDescription = "NA";
		//client = (String)remedyParameters.get("Client");
		clientField1 = (String)remedyParameters.get("Client_Field_1");
		clientField2 = (String)remedyParameters.get("Client_Field_2");
		clientField3 = (String)remedyParameters.get("Client_Field_3");
		primaryKey = (String)remedyParameters.get("Primary_Key");
		formName = (String)remedyParameters.get("Form_Name");
		
		CMNIntegrationFoundationDataSyncWSService createService = new CMNIntegrationFoundationDataSyncWSService();
		FoundationDataPortType dataSyncCreate = createService.getFoundationDataSoap();
		LOGGER.info("Field mapping value : ");
		LOGGER.info("clientField1 : "+clientField1);
		LOGGER.info("clientField2 : "+clientField2);
		LOGGER.info("clientField2 : "+clientField2);
		LOGGER.info("primaryKey : "+primaryKey);
		LOGGER.info("FormName : "+formName);
		LOGGER.info("Client : "+client);
		
		String response = dataSyncCreate.newCreateOperation0(submitter, 
				assignedTo, 
				status, 
				shortDescription, 
				formName, 
				clientField1,
				clientField2,
				clientField4,
				clientField5,
				clientFieldLabel4,
				clientFieldLabel1,
				clientFieldLabel2,
				clientFieldLabel5,
				clientFieldLabel3,
				clientField3,
				transactionType,
				client,
				primaryKey,
				parameters);		
		LOGGER.info("Response : "+response);
		Date endTime = new Date();
		LOGGER.info("Remedy Data Sync call ends :"+Utilities.getCurrentDateTime(endTime));
		LOGGER.info("Remedy Data Sync call duration :"+Utilities.getTimeDifference(startTime, endTime));
		return response;

	}
	public String groupDataSync(Map<String, Object> remedyParameters)throws Exception {
		
		Date startTime = new Date();
		LOGGER.info("Remedy Data Sync call starts :"+Utilities.getCurrentDateTime(startTime));
		status = StatusType.fromValue((String)remedyParameters.get("Status"));
		submitter = "NA";
		shortDescription = "NA";
		//client = (String)remedyParameters.get("Client");
		clientField1 = (String)remedyParameters.get("Client_Field_1");
		clientField2 = (String)remedyParameters.get("Client_Field_2");
		primaryKey = (String)remedyParameters.get("Primary_Key");
		//clientField3 = (String)remedyParameters.get("Client_Field_3");
		formName = (String)remedyParameters.get("Form_Name");
		//clientField3 = formName;
		
		CMNIntegrationFoundationDataSyncWSService createService = new CMNIntegrationFoundationDataSyncWSService();
		FoundationDataPortType dataSyncCreate = createService.getFoundationDataSoap();
		LOGGER.info("Field mapping value : ");
		LOGGER.info("clientField1 : "+clientField1);
		LOGGER.info("clientField2 : "+clientField2);
		LOGGER.info("primaryKey : "+primaryKey);
		LOGGER.info("FormName : "+formName);
		
		
		String response = dataSyncCreate.newCreateOperation0(submitter, 
				assignedTo, 
				status, 
				shortDescription, 
				formName, 
				clientField1,
				clientField2,
				clientField4,
				clientField5,
				clientFieldLabel4,
				clientFieldLabel1,
				clientFieldLabel2,
				clientFieldLabel5,
				clientFieldLabel3,
				clientField3,
				transactionType,
				client,
				primaryKey,
				parameters);		
		LOGGER.info("Response : "+response);
		Date endTime = new Date();
		LOGGER.info("Remedy Data Sync call ends :"+Utilities.getCurrentDateTime(endTime));
		LOGGER.info("Remedy Data Sync call duration :"+Utilities.getTimeDifference(startTime, endTime));
		return response;

	}
}
