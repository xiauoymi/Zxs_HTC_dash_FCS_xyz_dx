/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.caretech.mediator.datamapping.dto;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author gopinathn
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "object")
public class SourceObjectDTO {

    //Attributes
    @XmlAttribute(name="id")
    private String sourceObjectId;
    @XmlAttribute(name = "name")
    private String name;
    @XmlAttribute(name = "type")
    private String type;
    @XmlAttribute(name = "dynamic")
    private boolean dynamic;   
    @XmlElement(name = "field")
    private List<FieldSourceDTO> sourceFields;

    

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the sourceFields
     */
    public List<FieldSourceDTO> getSourceFields() {
        return sourceFields;
    }

    /**
     * @param sourceFields the sourceFields to set
     */
    public void setSourceFields(List<FieldSourceDTO> sourceFields) {
        this.sourceFields = sourceFields;
    }

    /**
     * @return the sourceObjectId
     */
    public String getSourceObjectId() {
        return sourceObjectId;
    }

    /**
     * @param sourceObjectId the sourceObjectId to set
     */
    public void setSourceObjectId(String sourceObjectId) {
        this.sourceObjectId = sourceObjectId;
    }

    /**
     * @return the dynamic
     */
    public boolean isDynamic() {
        return dynamic;
    }

    /**
     * @param dynamic the dynamic to set
     */
    public void setDynamic(boolean dynamic) {
        this.dynamic = dynamic;
    }
   

}
