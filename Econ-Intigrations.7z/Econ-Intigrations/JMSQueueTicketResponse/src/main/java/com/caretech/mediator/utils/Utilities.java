package com.caretech.mediator.utils;

import java.io.BufferedInputStream;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import org.apache.axis2.databinding.types.xsd.Base64Binary;

import javax.activation.DataHandler;

import org.apache.commons.codec.binary.Base64;

import com.caretech.ticket.datamapping.enums.ErrorCode;
import com.caretech.ticket.webservice.exception.TicketCreationException;
import com.htc.mediator.MessageRequestLog;

public class Utilities {
	
	public static String getCurrentDateTime() {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		return dateFormat.format(cal.getTime());
	}
	
	public static String getCurrentDateTime(Date currentTime) {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		return dateFormat.format(currentTime.getTime());
	}
	
	public static String getTimeDifference(Date startTime, Date endTime) {
		long difference = endTime.getTime()-startTime.getTime();
		long dsecs = difference / 1000;
	    //long dminutes = difference / (60 * 1000);
		return String.valueOf(dsecs) + " Seconds";
	}
	
	public static String getCurrentSNOWDateTime() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		return dateFormat.format(cal.getTime());
	}
	
	public static String escapeSpecialCharacter(Map<String, Object> remedyParameters,
			String fieldName) {
		String fieldValue = remedyParameters.get(fieldName) != null ? String.valueOf(fieldName) : null;
		if(fieldValue != null){
			fieldValue = fieldValue.replace("â€“", "–");
		}
		return fieldValue;
	}
    
	
	public static  Map<String, Object> convertObjectToMap(Object obj) throws TicketCreationException {
		Method[] methods = obj.getClass().getMethods();

		Map<String, Object> map = new HashMap<String, Object>();
		try {
			for (Method m : methods) {
				if (m.getName().startsWith("get") && !m.getName().startsWith("getClass")) {
					Object value;
					value = (Object) m.invoke(obj);
					if(value != null)
					if(m.getName().equalsIgnoreCase("getAttachment_1_attachmentData") ||
							m.getName().equalsIgnoreCase("getPatient_Attachment_1_attachmentData")) {
						DataHandler data =  ((Base64Binary)value).getBase64Binary();
						if(data != null) {
						BufferedInputStream in = new BufferedInputStream(data.getInputStream());
						byte[] byteArray=org.apache.commons.io.IOUtils.toByteArray(in);
						byte[] encoded = Base64.encodeBase64(byteArray);
						//String encodedString = new String(encoded);
						map.put("Attachment_1_attachmentData", (Object) new String(encoded));
						}
					} else if(m.getName().equalsIgnoreCase("getAttachment_1_attachmentName") ||
							m.getName().equalsIgnoreCase("getPatient_Attachment_1_attachmentName")) {
						
						if(((String) value).lastIndexOf("\\") > 0) {
						String fileName = ((String) value).substring(((String) value).lastIndexOf("\\")+1, ((String) value).length());
						map.put("Attachment_1_attachmentName", (Object) fileName);
						
						}else{
							map.put("Attachment_1_attachmentName", (Object) value);
						}
					} else
						map.put(m.getName().substring(3), (Object) value);
				}
			}
		} catch (Exception e) {
			throw new TicketCreationException(ErrorCode.ERR_X1009.name(), ErrorCode.ERR_X1009.getErrorMessage());
		} 
		return map;
	}
	
}
