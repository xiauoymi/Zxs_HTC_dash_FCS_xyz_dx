package com.caretech.mediator.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

/**
 * @author gopinathn
 *
 */
@XmlRootElement(name="request")
@XStreamAlias("request")
public class Request {
	
	@XStreamAlias("serviceName")
	private String serviceName;
	
	@XStreamAsAttribute
	private Parameter parameters;

	@XmlElement
	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	@XmlElement
	public Parameter getParameters() {
		return parameters;
	}

	public void setParameters(Parameter parameters) {
		this.parameters = parameters;
	}
	
	

}
