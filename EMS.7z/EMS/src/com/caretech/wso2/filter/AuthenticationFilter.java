package com.caretech.wso2.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.caretech.wso2.vo.UserProfile;

public class AuthenticationFilter implements Filter{

	private ArrayList<String> urlList;
    
    public void destroy() {
    }
 
    public void doFilter(ServletRequest req, ServletResponse res,
            FilterChain chain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;
        String url = request.getServletPath();       
        boolean allowedRequest = false;
		if (urlList.contains(url) || url.indexOf("/css/") >= 0
				|| url.indexOf("/images/") >= 0 || url.indexOf("/js/") >= 0) {
			allowedRequest = true;
		}
             
        if (!allowedRequest) {
        	HttpSession session = request.getSession(false);
        	
            if (null == session) {
                response.sendRedirect("/EMS/login");
                return;
            }else{
            	UserProfile userProfile = (UserProfile)session.getAttribute("ct.ems.profile");
            	if(userProfile == null){
            		response.sendRedirect("/EMS/login");
                    return;
            	}
            }
            
        }
        chain.doFilter(req, res);
    }
 
    public void init(FilterConfig config) throws ServletException {
        String urls = config.getInitParameter("avoid-urls");
        StringTokenizer token = new StringTokenizer(urls, ",");
 
        urlList = new ArrayList<String>();
 
        while (token.hasMoreTokens()) {
            urlList.add(token.nextToken());
 
        }
    }
}
