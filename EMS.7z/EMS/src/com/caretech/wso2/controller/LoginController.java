package com.caretech.wso2.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.caretech.wso2.entity.EmsClient;
import com.caretech.wso2.entity.User;
import com.caretech.wso2.service.MonitoringService;
import com.caretech.wso2.service.UserService;
import com.caretech.wso2.vo.UserProfile;

/**
 * 
 * @author himasreev
 *
 */
@Controller
public class LoginController {

	@SuppressWarnings("unused")
	private Logger log = Logger.getLogger(LoginController.class.getName());

	@Autowired
	private UserService userService;

	@Autowired
	private MonitoringService monitoringService;

	/**
	 * 
	 * @return
	 */
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String loginPage(Model model) {
		model.addAttribute("user", new User());
		return "loginPage";
	}

	/**
	 * 
	 * @param user
	 * @param result
	 * @return
	 */
	@RequestMapping(value = "login", method = RequestMethod.POST)
	public ModelAndView login(@ModelAttribute User user, BindingResult result, Model model, HttpServletRequest request) {
		ModelAndView view = new ModelAndView("loginPage");
		if (!result.hasFieldErrors()) {
			if (!userService.authenticateUser(user)) {
				result.addError(new ObjectError("err", "Invalid Credentials!"));
			} else {			
				UserProfile userProfile = new UserProfile();
				userProfile.setUserName(user.getUsername());				
				request.getSession(true).setAttribute("ct.ems.profile", userProfile);				
				view.setViewName("redirect:homepage"); 
			}
		}
		return view;
	}
	
	/**
	 * 
	 * @param user
	 * @param result
	 * @return
	 */
	@RequestMapping(value = "homepage", method = RequestMethod.GET)
	public ModelAndView homePage(Model model, HttpServletRequest request) {
		ModelAndView view = new ModelAndView("loginPage");
		List<EmsClient> clientList = monitoringService.getClientDetails();
		UserProfile userProfile = (UserProfile)request.getSession(false).getAttribute("ct.ems.profile");
		model.addAttribute("username", userProfile!=null?userProfile.getUserName():"");
		model.addAttribute("clientList", clientList);					
		view.setViewName("monitoringPage"); 
		return view;
	}
	
	@RequestMapping(value = "foundation", method = RequestMethod.GET)
	public ModelAndView foundationData(Model model, HttpServletRequest request) {
		ModelAndView view = new ModelAndView("loginPage");
		List<EmsClient> clientList = monitoringService.getClientDetails();
		UserProfile userProfile = (UserProfile)request.getSession(false).getAttribute("ct.ems.profile");
		model.addAttribute("username", userProfile!=null?userProfile.getUserName():"");
		model.addAttribute("clientList", clientList);					
		view.setViewName("foundationMonitor"); 
		return view;
	}

	/**
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "logout", method = RequestMethod.GET)
	public String logOut(Model model ,HttpSession session) {
		model.addAttribute("user", new User());
		model.addAttribute("logout", "You have been logged out successfully.");
		session.removeAttribute("ct.ems.profile");
		session.invalidate();
		return "loginPage";

	}
	
}
