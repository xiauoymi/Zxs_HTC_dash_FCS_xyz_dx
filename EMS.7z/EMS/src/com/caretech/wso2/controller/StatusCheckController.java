package com.caretech.wso2.controller;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.caretech.wso2.entity.EmsClient;
import com.caretech.wso2.service.MonitoringService;
import com.caretech.wso2.service.StatusCheckService;
import com.caretech.wso2.service.UserService;
@Controller
public class StatusCheckController {
	

	@SuppressWarnings("unused")
	private Logger log = Logger.getLogger(LoginController.class.getName());

	@Autowired
	private UserService userService;

	@Autowired
	private MonitoringService monitoringService;
	
	@Autowired
	private StatusCheckService statusCheckService;
	
	
	@RequestMapping(value = "/checkServiceHealth", method = RequestMethod.POST)
	@ResponseBody
	public HashMap<String, Boolean> checkServiceHealth(String clientName) {	
		return statusCheckService.getServices(clientName);
	}
	
	@RequestMapping(value = "/getClientName", method = RequestMethod.POST)
	@ResponseBody
	public List<EmsClient> getClientName() {
		return monitoringService.getClientDetails();
	}
	
	@RequestMapping(value = "/checkStatus", method = RequestMethod.POST)
	@ResponseBody
	public List<Object>  checkStatus(String fromDate, String toDate, String clientName) throws ParseException{
		return statusCheckService.getStatusReport(fromDate,toDate,clientName);
		
		
	}
	@RequestMapping(value = "/checkFoundationStatus", method = RequestMethod.POST)
	@ResponseBody
	public List<Object>  checkFoundationStatus(String fromDate, String toDate, String clientName) throws ParseException{
		return statusCheckService.getStatusFoundationReport(fromDate,toDate,clientName);
		
		
	}

}
