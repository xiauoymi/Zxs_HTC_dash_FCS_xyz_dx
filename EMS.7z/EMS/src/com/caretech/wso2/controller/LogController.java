package com.caretech.wso2.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.caretech.wso2.entity.EsbDataSychronization;
import com.caretech.wso2.entity.EsbLogObject;
import com.caretech.wso2.entity.EsbLogSummary;
import com.caretech.wso2.entity.SearchCriteria;
import com.caretech.wso2.entity.User;
import com.caretech.wso2.service.MonitoringService;
import com.caretech.wso2.utils.ExportUtils;
import com.caretech.wso2.vo.FoundationVo;
import com.caretech.wso2.vo.LogSummaryVO;
import com.caretech.wso2.vo.RequestParameterVO;
import com.fasterxml.jackson.core.JsonProcessingException;

@Controller
public class LogController {

	@SuppressWarnings("unused")
	private Logger log = Logger.getLogger(LogController.class);

	@Autowired
	private MonitoringService monitoringService;
	
	@Autowired
	private ExportUtils exportUtils;

	/**
	 * 
	 * @param user
	 * @param result
	 * @return
	 * @throws JsonProcessingException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/fetchLogData", method = RequestMethod.POST)
	@ResponseBody
	public LogSummaryVO fetchData(@RequestBody SearchCriteria searchCriteria, BindingResult result, Model model,
			HttpServletRequest request) {
		ModelAndView view = new ModelAndView("loginPage");
		LogSummaryVO summaryVO = new LogSummaryVO();
		ArrayList<EsbLogSummary> summaryList = (ArrayList) monitoringService.getLogSummaryByPage(searchCriteria);
		Integer totalCount = monitoringService.getTotalCount(searchCriteria);
		summaryVO.setSummaryList(summaryList);
		summaryVO.setTotalCount(totalCount);
		view.setViewName("monitoringPage");

		return summaryVO;
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/fetchfoundationData", method = RequestMethod.POST)
	@ResponseBody
	public FoundationVo fetchFoundation(@RequestBody SearchCriteria searchCriteria, BindingResult result, Model model,
			HttpServletRequest request) {
		ModelAndView view = new ModelAndView("loginPage");
		FoundationVo summaryVO = new FoundationVo();
		ArrayList<EsbDataSychronization> summaryList = (ArrayList) monitoringService.getFoundationDataByPage(searchCriteria);
		System.out.println("after summary List!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		Integer totalCount = monitoringService.getTotalCountForFoundation(searchCriteria);
		summaryVO.setSummaryList(summaryList);
		summaryVO.setTotalCount(totalCount);
		view.setViewName("foundationMonitor");

		return summaryVO;
	}
	/**
	 * 
	 * @param user
	 * @param result
	 * @return
	 * @throws JsonProcessingException
	 */
	@RequestMapping(value = "/fetchDetail", method = RequestMethod.POST)
	@ResponseBody
	public EsbLogObject fetchDetail(@ModelAttribute User user, BindingResult result, Model model,
			HttpServletRequest request) {
		String transactionId = request.getParameter("transactionId") != null ? request.getParameter("transactionId")
				: "";
		EsbLogObject logDetail = monitoringService.getLogObject(transactionId);
		return logDetail;
	}
	
	@RequestMapping(value = "/fetchFoundationDetail", method = RequestMethod.POST)
	@ResponseBody
	public EsbLogObject fetchFoundationDetail(@ModelAttribute User user, BindingResult result, Model model,
			HttpServletRequest request) {
		String transactionId = request.getParameter("transactionId") != null ? request.getParameter("transactionId")
				: "";
		EsbLogObject logDetail = monitoringService.getFoundationLogObject(transactionId);
		return logDetail;
	}

	@RequestMapping(value = "/fetchRequestParameter", method = RequestMethod.POST)
	@ResponseBody
	public List<RequestParameterVO> fetchRequestParameter(@ModelAttribute User user, BindingResult result, Model model,
			HttpServletRequest request) {
		String sourceTicketNumber = request.getParameter("sourceTicketNumber") != null ? request
				.getParameter("sourceTicketNumber") : "";
		String destinationTicketNumber = request.getParameter("destinationTicketNumber") != null ? request
				.getParameter("destinationTicketNumber") : "";
		List<RequestParameterVO> paramList = monitoringService.getRequestParameter(sourceTicketNumber,
				destinationTicketNumber);
		return paramList;
	}
	
	@RequestMapping(value = "/exportToExcel", method = RequestMethod.GET)
	public  void exportToExcel(HttpServletRequest request, HttpServletResponse response, ModelMap modelMap)  {
		exportUtils.exportExcel(response);
	}
	@RequestMapping(value = "/exportFoundationToExcel", method = RequestMethod.GET)
	public  void exportFoundationDataToExcel(HttpServletRequest request, HttpServletResponse response, ModelMap modelMap)  {
		exportUtils.exportFoundationExcel(response);
	}
}
