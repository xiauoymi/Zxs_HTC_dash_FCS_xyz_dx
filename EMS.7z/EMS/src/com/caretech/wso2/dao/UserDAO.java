package com.caretech.wso2.dao;

import com.caretech.wso2.entity.User;

/**
 * 
 * @author himasreev
 * This interface is used to communicate with the Database
 *
 */
public interface UserDAO {
    
	/**
	 * 
	 * @param login
	 * @return
	 */
    public User getUser(String login);

    /**
     * 
     * @param user
     * @return
     */
	public boolean authenticateUser(User user);
 
}