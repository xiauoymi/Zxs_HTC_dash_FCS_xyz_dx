package com.caretech.wso2.dao;

import java.text.ParseException;
import java.util.List;

import com.caretech.wso2.entity.Services;

public interface StatusCheckDAO {
	
	public List<Object> getStatusReport(String fromDate, String toDate, String clientName) throws ParseException;
	
	public List<Object> getFoundationStatusReport(String fromDate, String toDate, String clientName) throws ParseException;
	
	public List<Services> getServices(String clientName);

}
