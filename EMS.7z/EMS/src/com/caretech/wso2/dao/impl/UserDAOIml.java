package com.caretech.wso2.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.caretech.wso2.dao.UserDAO;
import com.caretech.wso2.entity.User;

/**
 * 
 * @author himasreev
 *
 */
@Repository
public class UserDAOIml implements UserDAO {

	@Autowired
	private SessionFactory sessionFactory;

	private Session openSession() {
		return sessionFactory.getCurrentSession();
	}

	/*
	 * (non-Javadoc)
	 * @see com.caretech.wso2.dao.UserDAO#getUser(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public User getUser(String userName) {
		List<User>  userList= new ArrayList<User>();
		Criteria criteria = openSession().createCriteria(User.class);
		criteria.add(Restrictions.eq("username",userName));
		userList = criteria.list();
		if (userList.size() > 0)
			return userList.get(0);
		else
			return null;

	}

	@Override
	public boolean authenticateUser(User user){
		List<User>  userList= new ArrayList<User>();
		Criteria criteria = openSession().createCriteria(User.class);
		criteria.add(Restrictions.eq("username",user.getUsername()));
		criteria.add(Restrictions.eq("password",user.getPassword()));
		userList = criteria.list();
		if (userList.size() == 1)
			return true;
		else
			return false;

	}
}