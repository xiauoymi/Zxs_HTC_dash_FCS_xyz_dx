package com.caretech.wso2.dao.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.caretech.wso2.constants.MonitoringConstants;
import com.caretech.wso2.dao.MonitoringDAO;
import com.caretech.wso2.entity.DateCriteria;
import com.caretech.wso2.entity.EmsClient;
import com.caretech.wso2.entity.EsbDataSychronization;
import com.caretech.wso2.entity.EsbLogDetails;
import com.caretech.wso2.entity.EsbLogSummary;
import com.caretech.wso2.entity.FoundationTransactionSummary;
import com.caretech.wso2.entity.SearchCriteria;
import com.caretech.wso2.entity.TransactionSummary;
import com.caretech.wso2.processor.RequestProcessor;
import com.caretech.wso2.utils.ExportUtils;
import com.caretech.wso2.utils.Utilities;
import com.caretech.wso2.vo.RequestParameterVO;

@Repository
@Transactional
public class MonitoringDAOImpl implements MonitoringDAO {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	private RequestProcessor requestProcessor;
	
	@Autowired
	private ExportUtils exportUtils;

	private Session openSession() {
		return sessionFactory.getCurrentSession();
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.caretech.wso2.dao.LoggingDAO#getLogSummaryByPage(com.caretech.wso2.entity.SearchCriteria)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<EsbLogSummary> getLogSummaryByPage(
			SearchCriteria searchCriteria) {
		Criteria criteria = openSession().createCriteria(EsbLogSummary.class);
		if(!searchCriteria.getLength().equals("-1"))
			criteria.setMaxResults(Integer.parseInt(searchCriteria.getLength()));
		criteria.setFirstResult(Integer.parseInt(searchCriteria.getStart())); 
		if(searchCriteria.getOrder() != null && "asc".equals(searchCriteria.getDirection()))
			criteria.addOrder(Order.asc(searchCriteria.getOrder()));
		else if(searchCriteria.getOrder() != null && "desc".equals(searchCriteria.getDirection()))
			criteria.addOrder(Order.desc(searchCriteria.getOrder()));
		else if(searchCriteria.getOrder() != null)
			criteria.addOrder(Order.asc(searchCriteria.getOrder()));
		if(searchCriteria.getSearch() != null) {
			Iterator<Entry<String, String>> it = searchCriteria.getSearch().entrySet().iterator();
	        
	        while (it.hasNext()) {
		        Entry<String, String> pair = it.next();
		        if(pair.getValue()!=null && pair.getValue()!=""){
		        	Criterion condition= Restrictions.like(pair.getKey(), "%"+pair.getValue()+"%");
		        	criteria.add(condition);
		        }
	        }
		}
		appendCriteriaCondition(criteria, searchCriteria);
		return criteria.list();
	}
	
	@SuppressWarnings("unused")
	private void appendCriteriaCondition(Criteria criteria,SearchCriteria searchCriteria){
		try {
			//criteria.addOrder(Order.asc(searchCriteria.getOrder()));
			if(searchCriteria.getClientName() != null){
				criteria.add(Restrictions.eq("clientName", searchCriteria.getClientName()));
			}
			
				Criterion conditionSource1 = null;
				Criterion conditionSource2 = null;
				if(searchCriteria.getSnowTicket() != null && searchCriteria.getSnowTicket() != ""){
					conditionSource1= Restrictions.eq("sourceTicketNumber", searchCriteria.getSnowTicket());
					conditionSource2 = Restrictions.eq("destinationTicketNumber", searchCriteria.getSnowTicket());
					//criteria.add(Restrictions.or(conditionSource1,conditionSource2));
				}
				
			
				Criterion conditionRemdey1 = null;
				Criterion conditionRemedy2 = null;
				if(searchCriteria.getRemedyTicket() != null && searchCriteria.getRemedyTicket() != ""){
					conditionRemdey1= Restrictions.eq("sourceTicketNumber", searchCriteria.getRemedyTicket());
					conditionRemedy2 =Restrictions.eq("destinationTicketNumber", searchCriteria.getRemedyTicket());
					//criteria.add(Restrictions.or(conditionRemdey1,conditionRemedy2));
				}
				if(searchCriteria.getSnowTicket() != null && searchCriteria.getSnowTicket() != "" && searchCriteria.getRemedyTicket() != null && searchCriteria.getRemedyTicket() != ""){
					criteria.add(Restrictions.or(conditionRemdey1, conditionRemdey1,conditionSource1,conditionSource2));
				}else if(searchCriteria.getSnowTicket() != null && searchCriteria.getSnowTicket() != ""){
					criteria.add(Restrictions.or(conditionSource1,conditionSource2));
				} else if(searchCriteria.getRemedyTicket() != null && searchCriteria.getRemedyTicket() != ""){
					criteria.add(Restrictions.or(conditionRemdey1,conditionRemedy2));
				}
		
			List<DateCriteria> dateCriteriaList = searchCriteria.getDateSearchCriteria();
			if(dateCriteriaList != null && dateCriteriaList.size()>0) {
				for(DateCriteria dateCriteria : dateCriteriaList) {
					System.out.println("date criteria++++++++++++++++++++++++++++++++++++++++++++++++++"+dateCriteria.toString());
					if(MonitoringConstants.OPERATOR_BETWEEN.equals(dateCriteria.getOperator())){
						criteria.add(Restrictions.between(dateCriteria.getField(), Utilities.convertStringToSqlDate(dateCriteria.getFromDate()),
								Utilities.getFormattedToDate(dateCriteria.getToDate())));
					}else if(MonitoringConstants.OPERATOR_EQUAL.equals(dateCriteria.getOperator())){
						criteria.add(Restrictions.between(dateCriteria.getField(), Utilities.convertStringToSqlDate(dateCriteria.getFromDate()),
								Utilities.getFormattedToDate(dateCriteria.getFromDate())));
					}else if(MonitoringConstants.OPERATOR_GREATER_THAN.equals(dateCriteria.getOperator())){
						criteria.add(Restrictions.gt(dateCriteria.getField(), Utilities.getFormattedToDate(dateCriteria.getFromDate())));
					}else if(MonitoringConstants.OPERATOR_GREATER_THAN_OR_EQUAL.equals(dateCriteria.getOperator())){
						criteria.add(Restrictions.ge(dateCriteria.getField(), Utilities.convertStringToSqlDate(dateCriteria.getFromDate())));
					}else if(MonitoringConstants.OPERATOR_LESS_THAN.equals(dateCriteria.getOperator())){
						criteria.add(Restrictions.lt(dateCriteria.getField(), Utilities.convertStringToSqlDate(dateCriteria.getFromDate())));
					}else if(MonitoringConstants.OPERATOR_LESS_THAN_OR_EQUAL.equals(dateCriteria.getOperator())){
						criteria.add(Restrictions.le(dateCriteria.getField(), Utilities.getFormattedToDate(dateCriteria.getFromDate())));
					}
				}
				
				
			}
			} catch (Exception e) {
				e.printStackTrace();
			}
	}
	
	private void appendCriteriaConditionForFoundation(Criteria criteria,SearchCriteria searchCriteria){
		try {
			//criteria.addOrder(Order.asc(searchCriteria.getOrder()));
			if(searchCriteria.getClientName() != null){
				criteria.add(Restrictions.eq("clientName", searchCriteria.getClientName()));
			}
			if(searchCriteria.getTableName() != null){
				criteria.add(Restrictions.eq("source", searchCriteria.getTableName()));
			}
			List<DateCriteria> dateCriteriaList = searchCriteria.getDateSearchCriteria();
			if(dateCriteriaList != null && dateCriteriaList.size()>0) {
				for(DateCriteria dateCriteria : dateCriteriaList) {
					System.out.println("date criteria++++++++++++++++++++++++++++++++++++++++++++++++++"+dateCriteria.toString());
					if(MonitoringConstants.OPERATOR_BETWEEN.equals(dateCriteria.getOperator())){
						criteria.add(Restrictions.between(dateCriteria.getField(), Utilities.convertStringToSqlDate(dateCriteria.getFromDate()),
								Utilities.getFormattedToDate(dateCriteria.getToDate())));
					}else if(MonitoringConstants.OPERATOR_EQUAL.equals(dateCriteria.getOperator())){
						criteria.add(Restrictions.between(dateCriteria.getField(), Utilities.convertStringToSqlDate(dateCriteria.getFromDate()),
								Utilities.getFormattedToDate(dateCriteria.getFromDate())));
					}else if(MonitoringConstants.OPERATOR_GREATER_THAN.equals(dateCriteria.getOperator())){
						criteria.add(Restrictions.gt(dateCriteria.getField(), Utilities.getFormattedToDate(dateCriteria.getFromDate())));
					}else if(MonitoringConstants.OPERATOR_GREATER_THAN_OR_EQUAL.equals(dateCriteria.getOperator())){
						criteria.add(Restrictions.ge(dateCriteria.getField(), Utilities.convertStringToSqlDate(dateCriteria.getFromDate())));
					}else if(MonitoringConstants.OPERATOR_LESS_THAN.equals(dateCriteria.getOperator())){
						criteria.add(Restrictions.lt(dateCriteria.getField(), Utilities.convertStringToSqlDate(dateCriteria.getFromDate())));
					}else if(MonitoringConstants.OPERATOR_LESS_THAN_OR_EQUAL.equals(dateCriteria.getOperator())){
						criteria.add(Restrictions.le(dateCriteria.getField(), Utilities.getFormattedToDate(dateCriteria.getFromDate())));
					}
				}
				
				
			}
			} catch (Exception e) {
				e.printStackTrace();
			}
	}
	
	/* (non-Javadoc)
	 * @see com.caretech.wso2.dao.LoggingDAO#getTotalCount(com.caretech.wso2.entity.SearchCriteria)
	 */
	@Override
	public Integer getTotalCount(SearchCriteria searchCriteria) {
		Criteria criteria = openSession().createCriteria(EsbLogSummary.class);
		if(searchCriteria.getSearch() != null) {
			Iterator<Entry<String, String>> it = searchCriteria.getSearch().entrySet().iterator();
	        
	        while (it.hasNext()) {
		        Entry<String, String> pair = it.next();
		        if(pair.getValue()!=null && pair.getValue()!=""){
		        	Criterion condition= Restrictions.like(pair.getKey(), "%"+pair.getValue()+"%");
		        	criteria.add(condition);
		        	
		        	
		        }
	        }
		}
		appendCriteriaCondition(criteria, searchCriteria);
		criteria.setProjection(Projections.rowCount());
		exportUtils.setSearchCriteria(searchCriteria);
		Integer count = (int)(long) criteria.uniqueResult();
		return  count;
	}

	
	@SuppressWarnings("unchecked")
	@Override
	public List<EsbLogSummary> getTotalData(SearchCriteria searchCriteria) {
		Criteria criteria = openSession().createCriteria(EsbLogSummary.class);
		if(searchCriteria.getSearch() != null) {
			Iterator<Entry<String, String>> it = searchCriteria.getSearch().entrySet().iterator();
	        
	        while (it.hasNext()) {
		        Entry<String, String> pair = it.next();
		        if(pair.getValue()!=null && pair.getValue()!=""){
		        	Criterion condition= Restrictions.like(pair.getKey(), "%"+pair.getValue()+"%");
		        	criteria.add(condition);
		        }
	        }
		}
		appendCriteriaCondition(criteria, searchCriteria);
		return criteria.list();
	}

	@Override
	public EsbLogDetails getLogDetails(String transactionId) {
		EsbLogDetails logDetail = (EsbLogDetails) openSession().get(EsbLogDetails.class,Long.valueOf(transactionId));
		return logDetail;
	}
	
	@Override
	public TransactionSummary getLogSummary(String transactionId) {
		TransactionSummary logDetail = (TransactionSummary) openSession().get(TransactionSummary.class,Long.valueOf(transactionId));
		return logDetail;
	}
	
	
	
	@SuppressWarnings("unchecked")
	@Override	
	public List<EmsClient> getClientDetails() {
		List<EmsClient> clients = openSession().createCriteria(EmsClient.class).list();
		return clients;
	}

	@Override
	public List<RequestParameterVO> getRequestParameter(String sourceTicketNumber, String destinationTicketNumber) {
		List<String> ticketList = new ArrayList<String>();
		if(sourceTicketNumber != null && !"".equals(sourceTicketNumber))
		ticketList.add(sourceTicketNumber);
		if(destinationTicketNumber != null && !"".equals(destinationTicketNumber))
		ticketList.add(destinationTicketNumber);
		Criteria criteria = openSession().createCriteria(EsbLogSummary.class);
		Criterion condition1= Restrictions.in(MonitoringConstants.PARAM_SOURCE_TICKET_NUMBER, ticketList);
		Criterion condition2= Restrictions.in(MonitoringConstants.PARAM_DESTINATION_TICKET_NUMBER, ticketList);
		criteria.add(Restrictions.or(condition1, condition2));
		criteria.addOrder(Order.asc(MonitoringConstants.PARAM_TRANSACTION_ID));
		List<EsbLogSummary> logSummaryList = criteria.list();
		List<RequestParameterVO> requestParamList = new ArrayList<RequestParameterVO>();
		HashMap<String,Object> requestMap = null;
		for(EsbLogSummary summary : logSummaryList){
			if(summary!=null){
				requestMap = new HashMap<String, Object>();
				RequestParameterVO paramVO = new RequestParameterVO();
				String serviceName = summary.getSource();
				requestMap.put("Service Name", serviceName);
				paramVO.setServiceName(serviceName);
				paramVO.setRequestTime(new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(summary.getEsbInTime()));
				requestMap.put("Request Time", paramVO.getRequestTime());
				EsbLogDetails logDetail = getLogDetails(String.valueOf(summary.getTransactionId()));
				if(logDetail!=null){
					if(serviceName != null && (MonitoringConstants.PARAM_CREATE_TICKET_OR.equals(serviceName) ||
							MonitoringConstants.PARAM_UPDATE_TICKET_OR.equals(serviceName)))
						paramVO.setRequestParamJson(requestProcessor.processRemedyRequest(logDetail.getRequestParameter(),requestMap));
					else if(serviceName != null && (MonitoringConstants.PARAM_UPDATE_TICKET_IR.equals(serviceName)||
							MonitoringConstants.PARAM_CREATE_TICKET_IR.equals(serviceName)))
						paramVO.setRequestParamJson(requestProcessor.processSNOWRequest(logDetail.getRequestParameter(),requestMap));
				}
				requestParamList.add(paramVO);
			}
		}
		return requestParamList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<EsbDataSychronization> getFoundationDataByPage(
			SearchCriteria searchCriteria) {
		Criteria criteria = openSession().createCriteria(EsbDataSychronization.class);
		if(!searchCriteria.getLength().equals("-1"))
			criteria.setMaxResults(Integer.parseInt(searchCriteria.getLength()));
		criteria.setFirstResult(Integer.parseInt(searchCriteria.getStart())); 
		if(searchCriteria.getOrder() != null && "asc".equals(searchCriteria.getDirection()))
			criteria.addOrder(Order.asc(searchCriteria.getOrder()));
		else if(searchCriteria.getOrder() != null && "desc".equals(searchCriteria.getDirection()))
			criteria.addOrder(Order.desc(searchCriteria.getOrder()));
		else if(searchCriteria.getOrder() != null)
			criteria.addOrder(Order.asc(searchCriteria.getOrder()));
		if(searchCriteria.getSearch() != null) {
			Iterator<Entry<String, String>> it = searchCriteria.getSearch().entrySet().iterator();
	        
	        while (it.hasNext()) {
		        Entry<String, String> pair = it.next();
		        if(pair.getValue()!=null && pair.getValue()!=""){
		        	Criterion condition= Restrictions.like(pair.getKey(), "%"+pair.getValue()+"%");
		        	criteria.add(condition);
		        }
	        }
		}
		System.out.println("before append %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
		appendCriteriaConditionForFoundation(criteria, searchCriteria);
		System.out.println("after append $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
		return criteria.list();
	}

	@Override
	public Integer getTotalCountForFoundation(SearchCriteria searchCriteria) {
		System.out.println("in total coundt################################");
		Criteria criteria = openSession().createCriteria(EsbDataSychronization.class);
		if(searchCriteria.getSearch() != null) {
			Iterator<Entry<String, String>> it = searchCriteria.getSearch().entrySet().iterator();
	        
	        while (it.hasNext()) {
		        Entry<String, String> pair = it.next();
		        if(pair.getValue()!=null && pair.getValue()!=""){
		        	Criterion condition= Restrictions.like(pair.getKey(), "%"+pair.getValue()+"%");
		        	criteria.add(condition);
		        	
		        	
		        }
	        }
		}
		appendCriteriaConditionForFoundation(criteria, searchCriteria);
		criteria.setProjection(Projections.rowCount());
		exportUtils.setSearchCriteria(searchCriteria);
		Integer count = (int)(long) criteria.uniqueResult();
		
		return  count;
	}

	@Override
	public EsbDataSychronization getFoundationLogDetails(String transactionId) {
		EsbDataSychronization logDetail = (EsbDataSychronization) openSession().get(EsbDataSychronization.class,Long.valueOf(transactionId));
		return logDetail;
	}

	@Override
	public FoundationTransactionSummary getFoundationLogSummary(
			String transactionId) {
		FoundationTransactionSummary logDetail = (FoundationTransactionSummary) openSession().get(FoundationTransactionSummary.class,Long.valueOf(transactionId));
		return logDetail;
	}

	@Override
	public List<EsbDataSychronization> getTotalFoundationData(
			SearchCriteria searchCriteria) {
		Criteria criteria = openSession().createCriteria(EsbDataSychronization.class);
		if(searchCriteria.getSearch() != null) {
			Iterator<Entry<String, String>> it = searchCriteria.getSearch().entrySet().iterator();
	        
	        while (it.hasNext()) {
		        Entry<String, String> pair = it.next();
		        if(pair.getValue()!=null && pair.getValue()!=""){
		        	Criterion condition= Restrictions.like(pair.getKey(), "%"+pair.getValue()+"%");
		        	criteria.add(condition);
		        }
	        }
		}
		appendCriteriaConditionForFoundation(criteria, searchCriteria);
		return criteria.list();
	}
	
	
}
