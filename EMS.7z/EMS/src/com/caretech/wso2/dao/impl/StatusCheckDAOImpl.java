package com.caretech.wso2.dao.impl;

import java.text.ParseException;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.caretech.wso2.dao.StatusCheckDAO;
import com.caretech.wso2.entity.FoundationTransactionSummary;
import com.caretech.wso2.entity.Services;
import com.caretech.wso2.entity.TransactionSummary;
import com.caretech.wso2.utils.Utilities;


@Repository
@Transactional
public class StatusCheckDAOImpl implements StatusCheckDAO {

	@Autowired
	private SessionFactory sessionFactory;
	

	private Session openSession() {
		return sessionFactory.getCurrentSession();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Object> getStatusReport(String fromDate, String toDate, String clientName) throws ParseException{
		
		Criteria criteria = openSession().createCriteria(TransactionSummary.class);       
			criteria.add(Restrictions.between("esbInTime", Utilities.convertStringToSqlDate(fromDate), Utilities.getFormattedToDate(toDate)));	
			criteria.add(Restrictions.eq("clientName", clientName));
				criteria.setProjection(Projections.projectionList()
                        .add(Projections.groupProperty("source"))
                        .add(Projections.groupProperty("status"))
                        .add(Projections.count("source"))           
                );
		List<Object> result = criteria.list();		
		return result;
		
	}
	@Override
	public List<Object> getFoundationStatusReport(String fromDate,
			String toDate, String clientName) throws ParseException {
		
		Criteria criteria = openSession().createCriteria(FoundationTransactionSummary.class);       
			criteria.add(Restrictions.between("esbInTime", Utilities.convertStringToSqlDate(fromDate), Utilities.getFormattedToDate(toDate)));	
			criteria.add(Restrictions.eq("clientName", clientName));
				criteria.setProjection(Projections.projectionList()
                        .add(Projections.groupProperty("source"))
                        .add(Projections.groupProperty("status"))
                        .add(Projections.count("source"))           
                );
		List<Object> result = criteria.list();		
		return result;
		
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Services> getServices(String clientName){
		Criteria criteria = openSession().createCriteria(Services.class);
		criteria.add(Restrictions.eq("clientName", clientName));
		List<Services> services = criteria.list();		
		return services;		
	}



}
