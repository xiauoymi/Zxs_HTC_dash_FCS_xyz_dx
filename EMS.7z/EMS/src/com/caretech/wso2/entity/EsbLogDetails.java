package com.caretech.wso2.entity;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the logging database table.
 * 
 */
@Entity
@Table(name="esb_log_details")
@NamedQuery(name="EsbLogDetails.findAll", query="SELECT l FROM EsbLogDetails l")
public class EsbLogDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="transaction_id")
	private Long transactionId;
	
	@Column(name="request_parameter")
	private String requestParameter;

	@Column(name="response_parameter")
	private String responseParameter;

	public EsbLogDetails() {
	}

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	public String getRequestParameter() {
		return requestParameter;
	}

	public void setRequestParameter(String requestParameter) {
		this.requestParameter = requestParameter;
	}

	public String getResponseParameter() {
		return responseParameter;
	}

	public void setResponseParameter(String responseParameter) {
		this.responseParameter = responseParameter;
	}

}