package com.caretech.wso2.entity;
import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the logging database table.
 * 
 */
@Entity
@Table(name="esb_data_synchronization")
@NamedQuery(name="FoundationTransactionSummary.findAll", query="SELECT l FROM FoundationTransactionSummary l")
public class FoundationTransactionSummary implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="transaction_id")
	private Long transactionId;
	
	@Column(name="request_message_id")
	private String requestMessageId;

	
	@Column(name="request_parameter")
	private String requestParameter;

	
	@Column(name="response_parameter")
	private String responseParameter;
	
	
	@Column(name="status")
	private String status;
	

	@Column(name="client_name")
	private String clientName;
	
	
	@Column(name="server_ip")
	private String serverIp;
	
	@Column(name="in_time_to_esb")
	private Timestamp esbInTime;
	
	@Column(name="in_time_to_snow")
	private Timestamp snowInTime;
	
	
	@Column(name="out_time_from_snow")
	private Timestamp snowOutTime;
	
	@Column(name="mode")
	private String mode;
	
	
	@Column(name="out_time_from_esb")
	private Timestamp esbOutTime;
	
	
	@Column(name="source")
	private String source;
	
	@Column(name="destination")
	private String destination;

	
	@Transient
	private String displayEsbInTime;

	
	@Transient
	private String displayEsbOutTime;
	
	@Transient
	private String displaysnowInTime;
	
	@Transient
	private String displaysnowOutTime;

	
	public FoundationTransactionSummary() {
	}

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}
	
	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}
	
	public String getRequestMessageId() {
		return requestMessageId;
	}

	public void setRequestMessageId(String requestMessageId) {
		this.requestMessageId = requestMessageId;
	}

	public Timestamp getEsbInTime() {
		return esbInTime;
	}

	public void setEsbInTime(Timestamp esbInTime) {
		this.esbInTime = esbInTime;
	}

	public Timestamp getEsbOutTime() {
		return esbOutTime;
	}

	public void setEsbOutTime(Timestamp esbOutTime) {
		this.esbOutTime = esbOutTime;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRequestParameter() {
		return requestParameter;
	}

	public void setRequestParameter(String requestParameter) {
		this.requestParameter = requestParameter;
	}

	public String getResponseParameter() {
		return responseParameter;
	}

	public void setResponseParameter(String responseParameter) {
		this.responseParameter = responseParameter;
	}

	public String getServerIp() {
		return serverIp;
	}

	public void setServerIp(String serverIp) {
		this.serverIp = serverIp;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getDisplayEsbInTime() {
		return displayEsbInTime;
	}

	public void setDisplayEsbInTime(String displayEsbInTime) {
		this.displayEsbInTime = displayEsbInTime;
	}

	public String getDisplayEsbOutTime() {
		return displayEsbOutTime;
	}

	public void setDisplayEsbOutTime(String displayEsbOutTime) {
		this.displayEsbOutTime = displayEsbOutTime;
	}

	public Timestamp getSnowInTime() {
		return snowInTime;
	}

	public void setSnowInTime(Timestamp snowInTime) {
		this.snowInTime = snowInTime;
	}

	public Timestamp getSnowOutTime() {
		return snowOutTime;
	}

	public void setSnowOutTime(Timestamp snowOutTime) {
		this.snowOutTime = snowOutTime;
	}

	public String getDisplaysnowInTime() {
		return displaysnowInTime;
	}

	public void setDisplaysnowInTime(String displaysnowInTime) {
		this.displaysnowInTime = displaysnowInTime;
	}

	public String getDisplaysnowOutTime() {
		return displaysnowOutTime;
	}

	public void setDisplaysnowOutTime(String displaysnowOutTime) {
		this.displaysnowOutTime = displaysnowOutTime;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	
	
	
	
}