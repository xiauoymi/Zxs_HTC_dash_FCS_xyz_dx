package com.caretech.wso2.entity;
import java.io.Serializable;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.caretech.wso2.utils.Utilities;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * The persistent class for the logging database table.
 * 
 */
@Entity
@Table(name="esb_data_synchronization")
@NamedQuery(name="EsbDataSychronization.findAll", query="SELECT l FROM EsbDataSychronization l")
public class EsbDataSychronization implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Transient
	private SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss") ;
	
	

	@JsonIgnore
	@Id
	@Column(name="transaction_id")
	private Long transactionId;
	
	
	
	@JsonIgnore
	@Column(name="request_message_id")
	private String requestMessageId;

	@JsonIgnore
	@Column(name="request_parameter")
	private String requestParameter;

	@JsonIgnore
	@Column(name="response_parameter")
	private String responseParameter;
	
	@JsonProperty("Status")
	@Column(name="status")
	private String status;
	
	@JsonIgnore
	@Column(name="client_name")
	private String clientName;
	
	@JsonIgnore
	@Column(name="server_ip")
	private String serverIp;
	
	@Column(name="in_time_to_esb")
	@JsonIgnore
	private Timestamp esbInTime;
	
	@JsonIgnore
	@Column(name="mode")
	private String mode;
	
	@JsonIgnore
	@Column(name="in_time_to_snow")
	private Timestamp snowInTime;
	
	@JsonIgnore
	@Column(name="out_time_from_snow")
	private Timestamp snowOutTime;
	
	@JsonIgnore
	@Column(name="out_time_from_esb")
	private Timestamp esbOutTime;
	
	@JsonProperty("Service")
	@Column(name="source")
	private String source;
	
	@Column(name="destination")
	private String destination;

	@JsonProperty("Intime to eConnector")
	@Transient
	private String displayEsbInTime;

	@JsonProperty("Out Time From eConnector")
	@Transient
	private String displayEsbOutTime;
	
	@JsonProperty("In Time From Destination")
	@Transient
	private String displaySnowInTime;
	
	@JsonProperty("Out Time From Destination")
	@Transient
	private String displaySnowOutTime;

	@JsonProperty("Time Taken")
	@Transient
	private String timeDuration;
	
	
	
	@JsonProperty("Details")
	@Transient
	private String viewDetails;
	
	public String getViewDetails() {
		return "<input class=btn type=\"button\" name=\"btnView\" id=\"btnView\" value=\"View\" onClick=\"loadPopup(" + this.transactionId + ");\"/>";
	}

	public void setViewDetails(String viewDetails) {
		this.viewDetails = viewDetails;
	}

	@JsonProperty("Request History")
	@Transient
	private String viewHistory; 
	
	public EsbDataSychronization() {
	}

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}
	
	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}
	
	public String getRequestMessageId() {
		return requestMessageId;
	}

	public void setRequestMessageId(String requestMessageId) {
		this.requestMessageId = requestMessageId;
	}

	public Timestamp getEsbInTime() {
		return esbInTime;
	}

	public void setEsbInTime(Timestamp esbInTime) {
		this.esbInTime = esbInTime;
	}

	public Timestamp getEsbOutTime() {
		return esbOutTime;
	}

	public void setEsbOutTime(Timestamp esbOutTime) {
		this.esbOutTime = esbOutTime;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDisplayEsbInTime() {
		if(this.esbInTime != null)
			return dateFormat.format(this.esbInTime);
		else
			return displayEsbInTime;
	}

	public void setDisplayEsbInTime(String displayEsbInTime) {
		this.displayEsbInTime = displayEsbInTime;
	}


	

	public String getDisplayEsbOutTime() {
		if(esbOutTime != null)
			return dateFormat.format(esbOutTime);
		else
			return displayEsbOutTime;
	}

	public void setDisplayEsbOutTime(String displayesbOutTime) {
		this.displayEsbOutTime = displayesbOutTime;
	}



	public String getTimeDuration() {
		if(esbInTime != null && esbOutTime != null)
			return Utilities.getTimeDifference(esbInTime, esbOutTime);
		else
			return timeDuration;
	}

	public void setTimeDuration(String timeDuration) {
		this.timeDuration = timeDuration;
	}

	

	public String getRequestParameter() {
		return requestParameter;
	}

	public void setRequestParameter(String requestParameter) {
		this.requestParameter = requestParameter;
	}

	public String getResponseParameter() {
		return responseParameter;
	}

	public void setResponseParameter(String responseParameter) {
		this.responseParameter = responseParameter;
	}

	public String getServerIp() {
		return serverIp;
	}

	public void setServerIp(String serverIp) {
		this.serverIp = serverIp;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getViewHistory() {
		return viewHistory;
	}

	public void setViewHistory(String viewHistory) {
		this.viewHistory = viewHistory;
	}
	
	public String getDisplaySnowOutTime() {
		if(snowOutTime != null)
			return dateFormat.format(snowOutTime);
		else
			return displaySnowOutTime;
	}

	public void setDisplaySnowOutTime(String displaysnowOutTime) {
		this.displaySnowOutTime = displaysnowOutTime;
	}
	
	public String getDisplaySnowInTime() {
		if(snowInTime != null)
			return dateFormat.format(snowInTime);
		else
			return displaySnowInTime;
	}

	public void setDisplaySnowInTime(String displaysnowInTime) {
		this.displaySnowInTime = displaysnowInTime;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}
	
	
	
}