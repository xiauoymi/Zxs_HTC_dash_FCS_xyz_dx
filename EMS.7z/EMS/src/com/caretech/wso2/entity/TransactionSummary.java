package com.caretech.wso2.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="esb_log_summary")
@NamedQuery(name="TransactionSummary.findAll", query="SELECT l FROM TransactionSummary l")
public class TransactionSummary {
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="transaction_id")
	private Long transactionId;
	
	@Column(name="source")
	private String source;

	@Column(name="request_message_id")
	private String requestMessageId;

	@Column(name="in_time_to_esb")
	private Timestamp esbInTime;

	@Column(name="in_time_to_snow")
	private Timestamp snowInTime;

	@Column(name="destination")
	private String destination;

	@Column(name="response_message_id")
	private String responseMessageId;

	@Column(name="out_time_from_esb")
	private Timestamp esbOutTime;

	@Column(name="out_time_from_snow")
	private Timestamp snowOutTime;
	
	@Column(name="source_ticket_number")
	private String sourceTicketNumber;

	@Column(name="destination_ticket_number")
	private String destinationTicketNumber;

	@Column(name="client_name")
	private String clientName;
	
	@Column(name="server_ip")
	private String serverIp;
	
	@Column(name="status")
	private String status;

	@Transient
	private String displayEsbInTime;
	
	@Transient
	private String displaysnowInTime;
	
	@Transient
	private String displayesbOutTime;
	
	@Transient
	private String displaysnowOutTime;
	
	public TransactionSummary() {
	}

	
	public String getServerIp() {
		return serverIp;
	}


	public void setServerIp(String serverIp) {
		this.serverIp = serverIp;
	}


	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getRequestMessageId() {
		return requestMessageId;
	}

	public void setRequestMessageId(String requestMessageId) {
		this.requestMessageId = requestMessageId;
	}

	public Timestamp getEsbInTime() {
		return esbInTime;
	}

	public void setEsbInTime(Timestamp esbInTime) {
		this.esbInTime = esbInTime;
	}

	public Timestamp getSnowInTime() {
		return snowInTime;
	}

	public void setSnowInTime(Timestamp snowInTime) {
		this.snowInTime = snowInTime;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getResponseMessageId() {
		return responseMessageId;
	}

	public void setResponseMessageId(String responseMessageId) {
		this.responseMessageId = responseMessageId;
	}

	public Timestamp getEsbOutTime() {
		return esbOutTime;
	}

	public void setEsbOutTime(Timestamp esbOutTime) {
		this.esbOutTime = esbOutTime;
	}

	public Timestamp getSnowOutTime() {
		return snowOutTime;
	}

	public void setSnowOutTime(Timestamp snowOutTime) {
		this.snowOutTime = snowOutTime;
	}


	public String getSourceTicketNumber() {
		return sourceTicketNumber;
	}

	public void setSourceTicketNumber(String sourceTicketNumber) {
		this.sourceTicketNumber = sourceTicketNumber;
	}

	public String getDestinationTicketNumber() {
		return destinationTicketNumber;
	}

	public void setDestinationTicketNumber(String destinationTicketNumber) {
		this.destinationTicketNumber = destinationTicketNumber;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDisplayEsbInTime() {
		return displayEsbInTime;
	}

	public void setDisplayEsbInTime(String displayEsbInTime) {
		this.displayEsbInTime = displayEsbInTime;
	}
	
	public String getDisplaySnowInTime() {
		return displaysnowInTime;
	}

	public void setDisplaySnowInTime(String displaysnowInTime) {
		this.displaysnowInTime = displaysnowInTime;
	}

	public String getDisplayEsbOutTime() {
		return displayesbOutTime;
	}

	public void setDisplayEsbOutTime(String displayesbOutTime) {
		this.displayesbOutTime = displayesbOutTime;
	}

	public String getDisplaySnowOutTime() {
		return displaysnowOutTime;
	}

	public void setDisplaySnowOutTime(String displaysnowOutTime) {
		this.displaysnowOutTime = displaysnowOutTime;
	}
	

}
