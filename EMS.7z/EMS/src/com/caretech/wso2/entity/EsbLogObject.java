package com.caretech.wso2.entity;


public class EsbLogObject {
	private EsbLogDetails details;
	private EsbDataSychronization foundationDetails;
	private TransactionSummary summary;
	private FoundationTransactionSummary foundationSummary;
	private String totalDuration;
	
	
	
	public FoundationTransactionSummary getFoundationSummary() {
		return foundationSummary;
	}
	public void setFoundationSummary(FoundationTransactionSummary foundationSummary) {
		this.foundationSummary = foundationSummary;
	}
	public EsbDataSychronization getFoundationDetails() {
		return foundationDetails;
	}
	public void setFoundationDetails(EsbDataSychronization foundationDetails) {
		this.foundationDetails = foundationDetails;
	}
	public EsbLogDetails getDetails() {
		return details;
	}
	public void setDetails(EsbLogDetails details) {
		this.details = details;
	}
	public TransactionSummary getSummary() {
		return summary;
	}
	public void setSummary(TransactionSummary summary) {
		this.summary = summary;
	}
	public String getTotalDuration() {
		return totalDuration;
	}
	public void setTotalDuration(String totalDuration) {		
		this.totalDuration = totalDuration;
	}
		
}
