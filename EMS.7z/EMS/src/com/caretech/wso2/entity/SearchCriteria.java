package com.caretech.wso2.entity;

import java.util.HashMap;
import java.util.List;

public class SearchCriteria {
	
	private String start;
	
	private String length;
	
	private String order;
	
	private String direction;
	
	private HashMap<String,String> search;
	
	private String clientName;
	
	private String tableName;
	
	private String snowTicket;
	
	private String remedyTicket;

	private List<DateCriteria> dateSearchCriteria;
	
	
	
	
	

	public String getSnowTicket() {
		return snowTicket;
	}

	public void setSnowTicket(String snowTicket) {
		this.snowTicket = snowTicket;
	}

	public String getRemedyTicket() {
		return remedyTicket;
	}

	public void setRemedyTicket(String remedyTicket) {
		this.remedyTicket = remedyTicket;
	}

	/**
	 * @return the start
	 */
	public String getStart() {
		return start;
	}

	/**
	 * @param start the start to set
	 */
	public void setStart(String start) {
		this.start = start;
	}


	/**
	 * @return the length
	 */
	public String getLength() {
		return length;
	}

	/**
	 * @param length the length to set
	 */
	public void setLength(String length) {
		this.length = length;
	}

	/**
	 * @return the order
	 */
	public String getOrder() {
		return order;
	}

	/**
	 * @param order the order to set
	 */
	public void setOrder(String order) {
		this.order = order;
	}

	/**
	 * @return the direction
	 */
	public String getDirection() {
		return direction;
	}

	/**
	 * @param direction the direction to set
	 */
	public void setDirection(String direction) {
		this.direction = direction;
	}

	/**
	 * @return the search
	 */
	public HashMap<String,String> getSearch() {
		return search;
	}

	/**
	 * @param search the search to set
	 */
	public void setSearch(HashMap<String,String> search) {
		this.search = search;
	}

	/**
	 * @return the clientName
	 */
	public String getClientName() {
		return clientName;
	}

	/**
	 * @param clientName the clientName to set
	 */
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	/**
	 * @return dateSearchCriteria
	 */
	public List<DateCriteria> getDateSearchCriteria() {
		return dateSearchCriteria;
	}

	/**
	 * @param dateSearchCriteria
	 */
	public void setDateSearchCriteria(List<DateCriteria> dateSearchCriteria) {
		this.dateSearchCriteria = dateSearchCriteria;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	
	

}
