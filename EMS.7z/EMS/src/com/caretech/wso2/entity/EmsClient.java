package com.caretech.wso2.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * 
 * @author viswanathane
 *
 */
@Entity
@Table(name="ems_client")
@NamedQuery(name="EmsClient.findAll", query="SELECT client FROM EmsClient client")
public class EmsClient implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ems_client_sk")
	private int clientSk;
	
	@Column(name="client_id")
	private String clientId;
	
	@Column(name="client_name")
	private String clientName;

	public int getClientSk() {
		return clientSk;
	}

	public void setClientSk(int clientSk) {
		this.clientSk = clientSk;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	
	
	
}
