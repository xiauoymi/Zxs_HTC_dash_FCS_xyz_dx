package com.caretech.wso2.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="esb_services")
@NamedQuery(name="Services.findAll", query="SELECT l FROM Services l")
public class Services {
	
	@Id
	@Column(name="service_sk")
	private int serviceSk;
	
	@Column(name="service_name")
	private String serviceName;
		

	@Column(name="client_name")
	private String clientName;

	@Column(name="url")
	private String url;

	public int getServiceSk() {
		return serviceSk;
	}

	public void setServiceSk(int serviceSk) {
		this.serviceSk = serviceSk;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}


}
