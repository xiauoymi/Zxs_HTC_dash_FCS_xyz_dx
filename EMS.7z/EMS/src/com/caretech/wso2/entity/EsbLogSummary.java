package com.caretech.wso2.entity;
import java.io.Serializable;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.caretech.wso2.utils.Utilities;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * The persistent class for the logging database table.
 * 
 */
@Entity
@Table(name="esb_log_summary")
@NamedQuery(name="EsbLogSummary.findAll", query="SELECT l FROM EsbLogSummary l")
public class EsbLogSummary implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Transient
	private SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss") ;

	@JsonIgnore
	@Id
	@Column(name="transaction_id")
	private Long transactionId;
	
	@JsonProperty("Service")
	@Column(name="source")
	private String source;

	@JsonIgnore
	@Column(name="request_message_id")
	private String requestMessageId;

	
	@Column(name="in_time_to_esb")
	@JsonIgnore
	private Timestamp esbInTime;

	@JsonIgnore
	@Column(name="in_time_to_snow")
	private Timestamp snowInTime;

	@JsonIgnore
	@Column(name="destination") 
	private String destination;

	@JsonIgnore
	@Column(name="response_message_id")
	private String responseMessageId;

	@JsonIgnore
	@Column(name="out_time_from_esb")
	private Timestamp esbOutTime;

	@JsonIgnore
	@Column(name="out_time_from_snow")
	private Timestamp snowOutTime;
	
	@JsonProperty("Source Ticket Number")
	@Column(name="source_ticket_number")
	private String sourceTicketNumber;

	@JsonProperty("Destination Ticket Number")
	@Column(name="destination_ticket_number")
	private String destinationTicketNumber;

	@JsonIgnore
	@Column(name="client_name")
	private String clientName;
	
	@JsonProperty("Server IP")
	@Column(name="server_ip")
	private String serverIp;
	
	@JsonProperty("Status")
	@Column(name="status")
	private String status;

	@JsonProperty("Intime to eConnector")
	@Transient
	private String displayEsbInTime;
	
	@JsonProperty("Out Time To Destination")
	@Transient
	private String displaySnowInTime;
	
	@JsonProperty("Out Time From eConnector")
	@Transient
	private String displayEsbOutTime;
	
	@JsonProperty("In Time From Destination")
	@Transient
	private String displaySnowOutTime;
	
	@JsonProperty("Time Taken")
	@Transient
	private String timeDuration;
	
	@JsonProperty("Details")
	@Transient
	private String viewDetails;
	
	public String getViewDetails() {
		return "<input class=btn type=\"button\" name=\"btnView\" id=\"btnView\" value=\"View\" onClick=\"loadPopup(" + this.transactionId + ");\"/>";
	}

	public void setViewDetails(String viewDetails) {
		this.viewDetails = viewDetails;
	}

	public String getViewHistory() {
		if(!"UploadAttachment".equals(this.source))
		return "<input class=btn type=\"button\" name=\"btnView\" id=\"btnView\" value=\"View\" onClick=\"loadComparePopup('" + this.sourceTicketNumber+ "\','" + this.destinationTicketNumber+ "\');\"/>";
		else
			return "";
	}

	public void setViewHistory(String viewHistory) {
		this.viewHistory = viewHistory;
	}

	@JsonProperty("Request History")
	@Transient
	private String viewHistory; 
	
	public EsbLogSummary() {
	}

	
	public String getServerIp() {
		return serverIp;
	}

	public void setServerIp(String serverIp) {
		this.serverIp = serverIp;
	}

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getRequestMessageId() {
		return requestMessageId;
	}

	public void setRequestMessageId(String requestMessageId) {
		this.requestMessageId = requestMessageId;
	}

	public Timestamp getEsbInTime() {
		return esbInTime;
	}

	public void setEsbInTime(Timestamp esbInTime) {
		this.esbInTime = esbInTime;
	}

	public Timestamp getSnowInTime() {
		return snowInTime;
	}

	public void setSnowInTime(Timestamp snowInTime) {
		this.snowInTime = snowInTime;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getResponseMessageId() {
		return responseMessageId;
	}

	public void setResponseMessageId(String responseMessageId) {
		this.responseMessageId = responseMessageId;
	}

	public Timestamp getEsbOutTime() {
		return esbOutTime;
	}

	public void setEsbOutTime(Timestamp esbOutTime) {
		this.esbOutTime = esbOutTime;
	}

	public Timestamp getSnowOutTime() {
		return snowOutTime;
	}

	public void setSnowOutTime(Timestamp snowOutTime) {
		this.snowOutTime = snowOutTime;
	}


	public String getSourceTicketNumber() {
		return sourceTicketNumber;
	}

	public void setSourceTicketNumber(String sourceTicketNumber) {
		this.sourceTicketNumber = sourceTicketNumber;
	}

	public String getDestinationTicketNumber() {
		return destinationTicketNumber;
	}

	public void setDestinationTicketNumber(String destinationTicketNumber) {
		this.destinationTicketNumber = destinationTicketNumber;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDisplayEsbInTime() {
		if(this.esbInTime != null)
			return dateFormat.format(this.esbInTime);
		else
			return displayEsbInTime;
	}

	public void setDisplayEsbInTime(String displayEsbInTime) {
		this.displayEsbInTime = displayEsbInTime;
	}
	
	public String getDisplaySnowInTime() {
		if(snowInTime != null)
			return dateFormat.format(snowInTime);
		else
			return displaySnowInTime;
	}

	public void setDisplaySnowInTime(String displaysnowInTime) {
		this.displaySnowInTime = displaysnowInTime;
	}

	public String getDisplayEsbOutTime() {
		if(esbOutTime != null)
			return dateFormat.format(esbOutTime);
		else
			return displayEsbOutTime;
	}

	public void setDisplayEsbOutTime(String displayesbOutTime) {
		this.displayEsbOutTime = displayesbOutTime;
	}

	public String getDisplaySnowOutTime() {
		if(snowOutTime != null)
			return dateFormat.format(snowOutTime);
		else
			return displaySnowOutTime;
	}

	public void setDisplaySnowOutTime(String displaysnowOutTime) {
		this.displaySnowOutTime = displaysnowOutTime;
	}

	public String getTimeDuration() {
		if(esbInTime != null && esbOutTime != null)
			return Utilities.getTimeDifference(esbInTime, esbOutTime);
		else
			return timeDuration;
	}

	public void setTimeDuration(String timeDuration) {
		this.timeDuration = timeDuration;
	}
	
}