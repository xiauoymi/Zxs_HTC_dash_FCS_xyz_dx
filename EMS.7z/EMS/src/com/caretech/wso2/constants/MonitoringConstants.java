package com.caretech.wso2.constants;

public class MonitoringConstants {
	
	public static final String ALL = "all";
	
	public static final long ONE_DAY_IN_MILLISECOND = 86400000 ;
	
	public static final String OPERATOR_BETWEEN = "between";
	
	public static final String OPERATOR_EQUAL = "eq";
	
	public static final String OPERATOR_GREATER_THAN = ">";
	
	public static final String OPERATOR_GREATER_THAN_OR_EQUAL = ">=";
	
	public static final String OPERATOR_LESS_THAN = "<";
	
	public static final String OPERATOR_LESS_THAN_OR_EQUAL = "<=";
	
	public static final String PARAM_CREATE_TICKET_OR = "CreateTicketOR";
	
	public static final String PARAM_CREATE_TICKET_IR = "CreateTicketIR";
	
	public static final String PARAM_UPDATE_TICKET_OR = "UpdateTicketOR";
	
	public static final String PARAM_UPDATE_TICKET_IR = "UpdateTicketIR";
	
	public static final String PARAM_SOURCE_TICKET_NUMBER = "sourceTicketNumber";
	
	public static final String PARAM_DESTINATION_TICKET_NUMBER = "destinationTicketNumber";
	
	public static final String PARAM_TRANSACTION_ID = "transactionId";
}
