package com.caretech.wso2.constants;

import java.util.HashMap;
import java.util.LinkedHashMap;

import org.springframework.stereotype.Component;

@Component
public class RequestParameterMapping {
	
	private static HashMap<String,String> remedyRequestMap;
	
	private static HashMap<String,String> servicenowRequestMap;
	
	private static LinkedHashMap<String,Object> emptyRequestList;
	
	private static final String EMPTY_STRING = "";
	
	static{
		emptyRequestList = new LinkedHashMap<String,Object>();
		emptyRequestList.put("Service Name",EMPTY_STRING);
		emptyRequestList.put("Request Time",EMPTY_STRING);
		emptyRequestList.put("Office",EMPTY_STRING);
		emptyRequestList.put("Building",EMPTY_STRING);
		emptyRequestList.put("Description",EMPTY_STRING);
		emptyRequestList.put("Category",EMPTY_STRING);
		emptyRequestList.put("Remedy Ticket Number",EMPTY_STRING);
		emptyRequestList.put("ServiceNow Number",EMPTY_STRING);
		emptyRequestList.put("CMDB CI",EMPTY_STRING);
		emptyRequestList.put("KB Arrticle Number",EMPTY_STRING);
		emptyRequestList.put("Node Name",EMPTY_STRING);
		emptyRequestList.put("Citrix Server",EMPTY_STRING);
		emptyRequestList.put("Location",EMPTY_STRING);
		emptyRequestList.put("Department",EMPTY_STRING);
		emptyRequestList.put("Override Priority",EMPTY_STRING);
		emptyRequestList.put("Reason for Override",EMPTY_STRING);
		emptyRequestList.put("Source",EMPTY_STRING);
		emptyRequestList.put("First Name",EMPTY_STRING);
		emptyRequestList.put("Last Name",EMPTY_STRING);
		emptyRequestList.put("Item",EMPTY_STRING);
		emptyRequestList.put("Department",EMPTY_STRING);
		emptyRequestList.put("Submitter",EMPTY_STRING);
		emptyRequestList.put("Notes",EMPTY_STRING);
		emptyRequestList.put("Short Description",EMPTY_STRING);
		emptyRequestList.put("Status",EMPTY_STRING);
		emptyRequestList.put("Floor",EMPTY_STRING);
		emptyRequestList.put("Business Organization",EMPTY_STRING);
		emptyRequestList.put("Work Log",EMPTY_STRING);
		emptyRequestList.put("Network Login",EMPTY_STRING);
		emptyRequestList.put("Assigned Individual",EMPTY_STRING);
		emptyRequestList.put("Type",EMPTY_STRING);
		emptyRequestList.put("Patient Info",EMPTY_STRING);
		emptyRequestList.put("Assigned Group",EMPTY_STRING);
		//emptyRequestList.put("ServiceName",EMPTY_STRING);
		emptyRequestList.put("Summary",EMPTY_STRING);
		emptyRequestList.put("Phone",EMPTY_STRING);
		emptyRequestList.put("Priority",EMPTY_STRING);
		emptyRequestList.put("Close Code",EMPTY_STRING);
		emptyRequestList.put("Close Notes",EMPTY_STRING);
		
		remedyRequestMap = new HashMap<String,String>();
		remedyRequestMap.put("Office", "Office");
		remedyRequestMap.put("Building", "Building");
		remedyRequestMap.put("Description", "Description");
		remedyRequestMap.put("Category", "Category");
	    remedyRequestMap.put("Case_Number", "Remedy Ticket Number");
		remedyRequestMap.put("CTS_Ticket", "Remedy Ticket Number");
		remedyRequestMap.put("Customer_Ticket", "ServiceNow Number");
		remedyRequestMap.put("Integration_Attribute_01", "CMDB CI");
		remedyRequestMap.put("Integration_Attribute_02", "KB Arrticle Number");
		remedyRequestMap.put("Integration_Attribute_03", "Node Name");
		remedyRequestMap.put("Integration_Attribute_04", "Citrix Server");
		remedyRequestMap.put("Integration_Attribute_05", "Location");
		remedyRequestMap.put("Integration_Attribute_06", "Department");
		remedyRequestMap.put("Integration_Attribute_07", "Override Priority");
		remedyRequestMap.put("Integration_Attribute_08", "Reason for Override");
		remedyRequestMap.put("Source", "Source");
		remedyRequestMap.put("First_Name", "First Name");
		remedyRequestMap.put("Last_Name", "Last Name");
		remedyRequestMap.put("Item", "Item");
		remedyRequestMap.put("Department", "Department");
		remedyRequestMap.put("Submitter", "Submitter");
		remedyRequestMap.put("Notes", "Notes");
		remedyRequestMap.put("Short_Description", "Short Description");
		remedyRequestMap.put("Status", "Status");
		remedyRequestMap.put("Floor", "Floor");
		remedyRequestMap.put("Business_Organization", "Business Organization");
		remedyRequestMap.put("Work_Log", "Work Log");
		remedyRequestMap.put("Network_Login", "Network Login");
		remedyRequestMap.put("Assigned_Individual", "Assigned Individual");
		remedyRequestMap.put("Type", "Type");
		remedyRequestMap.put("Secure_Patient_Information", "Patient Info");
		remedyRequestMap.put("Assigned_Group", "Assigned Group");
		//remedyRequestMap.put("ServiceName", "ServiceName");
		remedyRequestMap.put("Summary", "Summary");
		remedyRequestMap.put("Phone_Work", "Phone");
		remedyRequestMap.put("Priority", "Priority");
		remedyRequestMap.put("Root_Cause_Category", "Close Code");
		remedyRequestMap.put("Resolution", "Close Notes");
		
		servicenowRequestMap = new HashMap<String,String>();
		//servicenowRequestMap.put("Office", "Office");
		//servicenowRequestMap.put("Building", "Building");
		servicenowRequestMap.put("description", "Description");
		servicenowRequestMap.put("category", "Category");
		servicenowRequestMap.put("u_external_ticket_id", "Remedy Ticket Number");
		servicenowRequestMap.put("number", "ServiceNow Number");
		servicenowRequestMap.put("cmdb_ci", "CMDB CI");
		servicenowRequestMap.put("u_kcs_solution", "KB Arrticle Number");
		servicenowRequestMap.put("u_node_name", "Node Name");
		servicenowRequestMap.put("u_citrix_server", "Citrix Server");
		servicenowRequestMap.put("location", "Location");
		servicenowRequestMap.put("u_department", "Department");
		servicenowRequestMap.put("u_overide_priority", "Override Priority");
		servicenowRequestMap.put("u_reason_override_priority", "Reason for Override");
		//servicenowRequestMap.put("Source", "Source");
		//servicenowRequestMap.put("First_Name", "First Name");
		//servicenowRequestMap.put("Last_Name", "Last Name");
		//servicenowRequestMap.put("Item", "Item");
		//servicenowRequestMap.put("Department", "Department");
		//servicenowRequestMap.put("Submitter", "Submitter");
		//servicenowRequestMap.put("Notes", "Notes");
		//servicenowRequestMap.put("Short_Description", "Short Description");
		servicenowRequestMap.put("state", "Status");
		//servicenowRequestMap.put("Floor", "Floor");
		//servicenowRequestMap.put("Business_Organization", "Business Organization");
		servicenowRequestMap.put("work_notes", "Work Log");
		//servicenowRequestMap.put("Network_Login", "Network Login");
		servicenowRequestMap.put("assigned_to", "Assigned Individual");
		//servicenowRequestMap.put("Type", "Type");
		servicenowRequestMap.put("u_patient_info", "Patient Info");
		servicenowRequestMap.put("assignment_group", "Assigned Group");
		//servicenowRequestMap.put("ServiceName", "ServiceName");
		servicenowRequestMap.put("short_description", "Summary");
		servicenowRequestMap.put("u_call_back_number", "Phone");
		servicenowRequestMap.put("priority", "Priority");
		servicenowRequestMap.put("close_code", "Close Code");
		servicenowRequestMap.put("close_notes", "Close Notes");
	}

	public static HashMap<String, String> getRemedyRequestMap() {
		return remedyRequestMap;
	}

	public static void setRemedyRequestMap(HashMap<String, String> remedyRequestMap) {
		RequestParameterMapping.remedyRequestMap = remedyRequestMap;
	}

	public static HashMap<String, String> getServicenowRequestMap() {
		return servicenowRequestMap;
	}

	public static void setServicenowRequestMap(HashMap<String, String> servicenowRequestMap) {
		RequestParameterMapping.servicenowRequestMap = servicenowRequestMap;
	}

	public static LinkedHashMap<String, Object> getEmptyRequestList() {
		return emptyRequestList;
	}

	public static void setEmptyRequestList(LinkedHashMap<String, Object> emptyRequestList) {
		RequestParameterMapping.emptyRequestList = emptyRequestList;
	}
	
	
	public static void getDefaultRequestList(LinkedHashMap<String, Object> emptyRequestList){
		emptyRequestList.put("Service Name",EMPTY_STRING);
		emptyRequestList.put("Request Time",EMPTY_STRING);
		emptyRequestList.put("Office",EMPTY_STRING);
		emptyRequestList.put("Building",EMPTY_STRING);
		emptyRequestList.put("Description",EMPTY_STRING);
		emptyRequestList.put("Category",EMPTY_STRING);
		emptyRequestList.put("Remedy Ticket Number",EMPTY_STRING);
		emptyRequestList.put("ServiceNow Number",EMPTY_STRING);
		emptyRequestList.put("CMDB CI",EMPTY_STRING);
		emptyRequestList.put("KB Arrticle Number",EMPTY_STRING);
		emptyRequestList.put("Node Name",EMPTY_STRING);
		emptyRequestList.put("Citrix Server",EMPTY_STRING);
		emptyRequestList.put("Location",EMPTY_STRING);
		emptyRequestList.put("Department",EMPTY_STRING);
		emptyRequestList.put("Override Priority",EMPTY_STRING);
		emptyRequestList.put("Reason for Override",EMPTY_STRING);
		emptyRequestList.put("Source",EMPTY_STRING);
		emptyRequestList.put("First Name",EMPTY_STRING);
		emptyRequestList.put("Last Name",EMPTY_STRING);
		emptyRequestList.put("Item",EMPTY_STRING);
		emptyRequestList.put("Department",EMPTY_STRING);
		emptyRequestList.put("Submitter",EMPTY_STRING);
		emptyRequestList.put("Notes",EMPTY_STRING);
		emptyRequestList.put("Short Description",EMPTY_STRING);
		emptyRequestList.put("Status",EMPTY_STRING);
		emptyRequestList.put("Floor",EMPTY_STRING);
		emptyRequestList.put("Business Organization",EMPTY_STRING);
		emptyRequestList.put("Work Log",EMPTY_STRING);
		emptyRequestList.put("Network Login",EMPTY_STRING);
		emptyRequestList.put("Assigned Individual",EMPTY_STRING);
		emptyRequestList.put("Type",EMPTY_STRING);
		emptyRequestList.put("Patient Info",EMPTY_STRING);
		emptyRequestList.put("Assigned Group",EMPTY_STRING);
		//emptyRequestList.put("ServiceName",EMPTY_STRING);
		emptyRequestList.put("Summary",EMPTY_STRING);
		emptyRequestList.put("Phone",EMPTY_STRING);
		emptyRequestList.put("Priority",EMPTY_STRING);
		emptyRequestList.put("Close Code",EMPTY_STRING);
		emptyRequestList.put("Close Notes",EMPTY_STRING);
	}
}
