package com.caretech.wso2.service;

import java.util.List;

import com.caretech.wso2.entity.EmsClient;
import com.caretech.wso2.entity.EsbDataSychronization;
import com.caretech.wso2.entity.EsbLogObject;
import com.caretech.wso2.entity.EsbLogDetails;
import com.caretech.wso2.entity.EsbLogSummary;
import com.caretech.wso2.entity.FoundationTransactionSummary;
import com.caretech.wso2.entity.SearchCriteria;
import com.caretech.wso2.entity.TransactionSummary;
import com.caretech.wso2.vo.RequestParameterVO;

/**
 * 
 * @author Hima
 *
 */
public interface MonitoringService {
	
	/**
	 * 
	 * @return
	 */
	
	public List<EsbLogSummary> getLogSummaryByPage(SearchCriteria searchCriteria);
	
	public List<EsbDataSychronization> getFoundationDataByPage(SearchCriteria searchCriteria);
	
	public Integer getTotalCount(SearchCriteria searchCriteria);
	
	public Integer getTotalCountForFoundation(SearchCriteria searchCriteria);
	
	public List<EsbLogSummary> getTotalData(SearchCriteria searchCriteria);
	
	public List<EsbDataSychronization> getFoundationTotalData(SearchCriteria searchCriteria);
	
	public EsbLogDetails getLogDetail(String transactionId);
	
	public EsbDataSychronization getFoundationLogDetail(String transactionId);
	
	public TransactionSummary getLogSummary(String transactionId);
	
	public FoundationTransactionSummary getFoundationLogSummary(String transactionId);
	
	public EsbLogObject getLogObject(String transactionId);	
	
	public EsbLogObject getFoundationLogObject(String transactionId);	
	
	public List<EmsClient> getClientDetails();

	public List<RequestParameterVO> getRequestParameter(String sourceTicketNumber, String destinationTicketNumber);

}
