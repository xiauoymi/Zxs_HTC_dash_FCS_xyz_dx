package com.caretech.wso2.service;

import com.caretech.wso2.entity.User;

/**
 * 
 * @author himasreev
 *
 */
public interface UserService {

	/**
	 * 
	 * @param login
	 * @return
	 */
	public User getUser(String login);

	public boolean authenticateUser(User user);

}
