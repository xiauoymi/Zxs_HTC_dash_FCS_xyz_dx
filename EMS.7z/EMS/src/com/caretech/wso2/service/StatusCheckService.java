package com.caretech.wso2.service;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;


public interface StatusCheckService {

	public List<Object> getStatusReport(String fromDate, String toDate, String clientName) throws ParseException;
	
	public List<Object> getStatusFoundationReport(String fromDate, String toDate, String clientName) throws ParseException;
	
	public HashMap<String, Boolean> getServices(String clientName);
}
