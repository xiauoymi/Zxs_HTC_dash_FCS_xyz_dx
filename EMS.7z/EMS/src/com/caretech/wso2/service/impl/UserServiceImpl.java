package com.caretech.wso2.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.caretech.wso2.dao.UserDAO;
import com.caretech.wso2.entity.User;
import com.caretech.wso2.service.UserService;

/**
 * 
 * @author himasreev
 *
 */
@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDAO userDAO;

	/*
	 * (non-Javadoc)
	 * @see com.caretech.wso2.service.UserService#getUser(java.lang.String)
	 */
	public User getUser(String login) {
		return userDAO.getUser(login);
	}

	@Override
	public boolean authenticateUser(User user) {
		
		return userDAO.authenticateUser(user);
	}

}