package com.caretech.wso2.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.caretech.wso2.dao.MonitoringDAO;
import com.caretech.wso2.entity.EmsClient;
import com.caretech.wso2.entity.EsbDataSychronization;
import com.caretech.wso2.entity.EsbLogObject;
import com.caretech.wso2.entity.EsbLogDetails;
import com.caretech.wso2.entity.EsbLogSummary;
import com.caretech.wso2.entity.FoundationTransactionSummary;
import com.caretech.wso2.entity.SearchCriteria;
import com.caretech.wso2.entity.TransactionSummary;
import com.caretech.wso2.service.MonitoringService;
import com.caretech.wso2.utils.Utilities;
import com.caretech.wso2.vo.RequestParameterVO;

@Service
@Transactional
public class MonitoringServiceImpl implements MonitoringService {
	
	@Autowired
	MonitoringDAO monitoringDAO;

	/*
	 * (non-Javadoc)
	 * @see com.caretech.wso2.service.MonitoringService#getLogSummaryByPage(com.caretech.wso2.entity.SearchCriteria)
	 */
	@Override
	public List<EsbLogSummary> getLogSummaryByPage(SearchCriteria searchCriteria) {
		return monitoringDAO.getLogSummaryByPage(searchCriteria);
	}
	
	/* (non-Javadoc)
	 * @see com.caretech.wso2.service.MonitoringService#getTotalCount(com.caretech.wso2.entity.SearchCriteria)
	 */
	@Override
	public Integer getTotalCount(SearchCriteria searchCriteria) {
		return monitoringDAO.getTotalCount(searchCriteria);
	}

	@Override
	public List<EsbLogSummary> getTotalData(SearchCriteria searchCriteria) {
		return monitoringDAO.getTotalData(searchCriteria);
	}
	
	@Override
	public EsbLogDetails getLogDetail(String transactionId) {
		return monitoringDAO.getLogDetails(transactionId);
	}
	
	@Override
	public TransactionSummary getLogSummary(String transactionId) {
		return monitoringDAO.getLogSummary(transactionId);
	}
	@Override
	public EsbLogObject getLogObject(String transactionId){
		String formatEsbInTime=null;
		String formatSnowInTime=null;
		String formatEsbOutTime=null;
		String formatSnowOutTime=null;
		EsbLogDetails details = getLogDetail(transactionId);
		TransactionSummary summary = getLogSummary(transactionId);
		EsbLogObject log = new EsbLogObject();
		log.setDetails(details);
		if(summary!=null){
			try {
				 formatEsbInTime = Utilities.formatTimestamp(summary.getEsbInTime());
				 formatSnowInTime = Utilities.formatTimestamp(summary.getSnowInTime());
				 formatEsbOutTime = Utilities.formatTimestamp(summary.getEsbOutTime());
				 formatSnowOutTime = Utilities.formatTimestamp(summary.getSnowOutTime());
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			summary.setDisplayEsbInTime(formatEsbInTime);
			summary.setDisplayEsbOutTime(formatEsbOutTime);
			summary.setDisplaySnowInTime(formatSnowInTime);
			summary.setDisplaySnowOutTime(formatSnowOutTime);
			log.setSummary(summary);
		}try {
			log.setTotalDuration(Utilities.getTimeDifference(summary.getEsbInTime(), summary.getEsbOutTime()));
		} catch (Exception e) {
			e.printStackTrace();
		}
	
		return log;
	}

	@Override
	public List<EmsClient> getClientDetails() {
		return monitoringDAO.getClientDetails();
	}

	@Override
	public List<RequestParameterVO> getRequestParameter(String sourceTicketNumber, String destinationTicketNumber) {
		List<RequestParameterVO> summaryList = monitoringDAO.getRequestParameter(sourceTicketNumber,destinationTicketNumber);
		return summaryList;
	}

	@Override
	public List<EsbDataSychronization> getFoundationDataByPage(
			SearchCriteria searchCriteria) {
		return monitoringDAO.getFoundationDataByPage(searchCriteria);
	}

	@Override
	public Integer getTotalCountForFoundation(SearchCriteria searchCriteria) {
		return monitoringDAO.getTotalCountForFoundation(searchCriteria);
	}

	@Override
	public EsbLogObject getFoundationLogObject(String transactionId) {
		String formatEsbInTime=null;
		String formatSnowInTime=null;
		String formatEsbOutTime=null;
		String formatSnowOutTime=null;
		EsbDataSychronization details = getFoundationLogDetail(transactionId);
		FoundationTransactionSummary summary = getFoundationLogSummary(transactionId);
		EsbLogObject log = new EsbLogObject();
		log.setFoundationDetails(details);
		if(summary!=null){
			try {
				 formatEsbInTime = Utilities.formatTimestamp(summary.getEsbInTime());
				 formatSnowInTime = Utilities.formatTimestamp(summary.getSnowInTime());
				 formatEsbOutTime = Utilities.formatTimestamp(summary.getEsbOutTime());
				 formatSnowOutTime = Utilities.formatTimestamp(summary.getSnowOutTime());
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			summary.setDisplayEsbInTime(formatEsbInTime);
			summary.setDisplayEsbOutTime(formatEsbOutTime);
			summary.setDisplaysnowInTime(formatSnowInTime);
			summary.setDisplaysnowOutTime(formatSnowOutTime);
			log.setFoundationSummary(summary);
		}try {
			log.setTotalDuration(Utilities.getTimeDifference(summary.getEsbInTime(), summary.getEsbOutTime()));
		} catch (Exception e) {
			e.printStackTrace();
		}
	
		return log;
	}

	@Override
	public EsbDataSychronization getFoundationLogDetail(String transactionId) {
		return monitoringDAO.getFoundationLogDetails(transactionId);
		
	}

	@Override
	public FoundationTransactionSummary getFoundationLogSummary(
			String transactionId) {
		return monitoringDAO.getFoundationLogSummary(transactionId);
		}

	@Override
	public List<EsbDataSychronization> getFoundationTotalData(
			SearchCriteria searchCriteria) {
		return monitoringDAO.getTotalFoundationData(searchCriteria);
		}
	
	
}
