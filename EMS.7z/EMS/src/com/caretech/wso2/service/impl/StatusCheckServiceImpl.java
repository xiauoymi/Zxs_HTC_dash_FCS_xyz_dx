package com.caretech.wso2.service.impl;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.caretech.wso2.dao.StatusCheckDAO;
import com.caretech.wso2.entity.Services;
import com.caretech.wso2.service.StatusCheckService;

@Service
@Transactional
public class StatusCheckServiceImpl implements StatusCheckService {
	

	@Autowired
	StatusCheckDAO statusCheckDAO;

	@Override
	public List<Object> getStatusReport(String fromDate, String toDate, String clientName) throws ParseException{		
		return statusCheckDAO.getStatusReport(fromDate,toDate,clientName);
	}
	
	@Override
	public List<Object> getStatusFoundationReport(String fromDate,
			String toDate, String clientName) throws ParseException {		
		return statusCheckDAO.getFoundationStatusReport(fromDate,toDate,clientName);
	}	
	
	@Override
	public HashMap<String, Boolean> getServices(String clientName){
		HashMap<String, Boolean> serviceResponseMap = new HashMap<String, Boolean>();
		List<Services> serviceList= statusCheckDAO.getServices(clientName);
		URL url = null;
		for (Services service : serviceList) {		
			boolean isActive = false;
			HttpURLConnection urlConnection = null;
			try {
				url = new URL(service.getUrl());
				System.out.println("URL : "+service.getUrl());
				urlConnection = (HttpURLConnection) url.openConnection();
				urlConnection.setConnectTimeout(5000);
				urlConnection.setReadTimeout(5000);
				int responseCode = urlConnection.getResponseCode();
				System.out.println("responseCode : "+responseCode);
				if (responseCode == 200 || responseCode == 202 || responseCode== 405 )
					isActive = true;
				serviceResponseMap.put(service.getServiceName(), isActive);
			} catch (Exception ex) {
				try {
					System.out.println(urlConnection.getResponseCode());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				isActive = false;
				serviceResponseMap.put(service.getServiceName(), isActive);
				System.out.println("Failed opening connection. Perhaps WS is not up?");
			}
		}
		serviceList.clear();
		return serviceResponseMap;
	}

	

}
