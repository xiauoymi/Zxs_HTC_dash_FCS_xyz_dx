package com.caretech.wso2.processor;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caretech.wso2.constants.RequestParameterMapping;

@Component
public class RequestProcessor {
	
	@Autowired
	JSONProcessor jSONProcessor;
	
	@Autowired
	RequestParameterMapping requestMapping;
	
	@SuppressWarnings("static-access")
	public String processRemedyRequest(String requestParameter, HashMap<String,Object> mappedTargetValues){
		
		try {
			jSONProcessor = new JSONProcessor();
			Map<String, Object> requestMap = jSONProcessor.getInputJsonAsMap(requestParameter);
			LinkedHashMap<String,Object> targetValues = new LinkedHashMap<String,Object>();
			requestMapping.getDefaultRequestList(targetValues);
			targetValues.put("Service Name", mappedTargetValues.get("Service Name"));
			targetValues.put("Request Time", mappedTargetValues.get("Request Time"));
			Map<String, Object> mappedRequest = getMappedTargetValues(requestMap,
					requestMapping.getRemedyRequestMap(), targetValues);
			requestParameter = jSONProcessor.getInputMapAsJson(mappedRequest);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return requestParameter;
		
	}
	
	@SuppressWarnings("static-access")
	public String processSNOWRequest(String requestParameter, HashMap<String,Object> mappedTargetValues){
		
		try {
			Map<String, Object> requestMap = jSONProcessor.getInputJsonAsMap(requestParameter);
			LinkedHashMap<String,Object> targetValues = new LinkedHashMap<String,Object>();
			requestMapping.getDefaultRequestList(targetValues);
			targetValues.put("Service Name", mappedTargetValues.get("Service Name"));
			targetValues.put("Request Time", mappedTargetValues.get("Request Time"));
			Map<String, Object> mappedRequest = getMappedTargetValues(requestMap,
					requestMapping.getServicenowRequestMap(), targetValues);
			requestParameter = jSONProcessor.getInputMapAsJson(mappedRequest);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return requestParameter;
		
	}
	
	
	private Map<String, Object> getMappedTargetValues(Map<String, Object> receivedInput,
			Map<String, String> fieldSources, Map<String, Object> mappedTargetValues) throws Exception {
        
        Iterator<Entry<String, Object>> it = receivedInput.entrySet().iterator();
        
        while (it.hasNext()) {
	        Entry<String, Object> pair = it.next();
	        if(fieldSources.get(pair.getKey()) != null)
	        	mappedTargetValues.put(fieldSources.get(pair.getKey()), pair.getValue());
        }
		return mappedTargetValues;
	}
	
	
}
