package com.caretech.wso2.utils;

import java.io.ByteArrayOutputStream;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caretech.wso2.entity.EsbDataSychronization;
import com.caretech.wso2.entity.EsbLogSummary;
import com.caretech.wso2.entity.SearchCriteria;
import com.caretech.wso2.service.MonitoringService;
@Component
public class ExportUtils {
	
	private SearchCriteria searchCriteria;
	
	@Autowired
	MonitoringService monitoringService;
	public void exportExcel(HttpServletResponse response){
		try {
		    HSSFWorkbook workbook = new HSSFWorkbook();
		    HSSFSheet sheet = workbook.createSheet("esb_log_summary");
		    HSSFRow rowhead = sheet.createRow((short) 0);
				    rowhead.createCell((short) 0).setCellValue("source");
				    rowhead.createCell((short) 1).setCellValue("request_message_id");
				    rowhead.createCell((short) 2).setCellValue("in_time_to_esb");
				    rowhead.createCell((short) 3).setCellValue("in_time_to_snow");
				    rowhead.createCell((short) 4).setCellValue("destination");
				    rowhead.createCell((short) 5).setCellValue("response_message_id");
				    rowhead.createCell((short) 6).setCellValue("out_time_from_snow");
				    rowhead.createCell((short) 7).setCellValue("out_time_from_esb");
				    rowhead.createCell((short) 8).setCellValue("source_ticket_number");
				    rowhead.createCell((short) 9).setCellValue("destination_ticket_number");
				    rowhead.createCell((short) 10).setCellValue("status");
				    rowhead.createCell((short) 11).setCellValue("client_name");
		   

		    int i = 1;
		    for (EsbLogSummary summary : monitoringService.getTotalData(getSearchCriteria())) {
		    	 HSSFRow row = sheet.createRow((short) i);
	 		        row.createCell((short) 0).setCellValue(summary.getSource());
	 		        row.createCell((short) 1).setCellValue(summary.getRequestMessageId());
	 		        row.createCell((short) 2).setCellValue(summary.getDisplayEsbInTime());
	 		        row.createCell((short) 3).setCellValue(summary.getDisplaySnowInTime());
	 		        row.createCell((short) 4).setCellValue(summary.getDestination());
	 		        row.createCell((short) 5).setCellValue(summary.getResponseMessageId());
	 		        row.createCell((short) 6).setCellValue(summary.getDisplaySnowOutTime());
	 		        row.createCell((short) 7).setCellValue(summary.getDisplayEsbOutTime());
	 		        row.createCell((short) 8).setCellValue(summary.getSourceTicketNumber());
	 		        row.createCell((short) 9).setCellValue(summary.getDestinationTicketNumber());
	 		        row.createCell((short) 10).setCellValue(summary.getStatus());
	 		        row.createCell((short) 11).setCellValue(summary.getClientName());	       
		 	i++;
			}
		 
		    response.setContentType("application/vnd.ms-excel");
			response.setHeader("Content-Disposition", "attachment; filename=eConnector_Monitoring.xlsx");
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			workbook.write(bos);
			byte[] bytes = bos.toByteArray();
			response.getOutputStream().write(bytes);
			bos.close();
		    } catch (Exception e) {
		       e.printStackTrace();
		    }

		}
	
	public void exportFoundationExcel(HttpServletResponse response){
		try {
		    HSSFWorkbook workbook = new HSSFWorkbook();
		    HSSFSheet sheet = workbook.createSheet("esb_data_synchronization");
		    HSSFRow rowhead = sheet.createRow((short) 0);
				    rowhead.createCell((short) 0).setCellValue("source");
				    rowhead.createCell((short) 1).setCellValue("request_message_id");
				    rowhead.createCell((short) 2).setCellValue("in_time_to_esb");
				    rowhead.createCell((short) 3).setCellValue("in_time_to_destination");
				    rowhead.createCell((short) 4).setCellValue("destination");
				    rowhead.createCell((short) 5).setCellValue("out_time_from_esb");
				    rowhead.createCell((short) 6).setCellValue("out_time_from_destination");
				    rowhead.createCell((short) 7).setCellValue("status");
				    rowhead.createCell((short) 8).setCellValue("client_name");
		   

		    int i = 1;
		    for (EsbDataSychronization summary : monitoringService.getFoundationTotalData(getSearchCriteria())) {
		    	 HSSFRow row = sheet.createRow((short) i);
	 		        row.createCell((short) 0).setCellValue(summary.getSource());
	 		        row.createCell((short) 1).setCellValue(summary.getRequestMessageId());
	 		        row.createCell((short) 2).setCellValue(summary.getDisplayEsbInTime());
	 		        row.createCell((short) 3).setCellValue(summary.getDisplaySnowInTime());
	 		        row.createCell((short) 4).setCellValue(summary.getDestination());
	 		        row.createCell((short) 5).setCellValue(summary.getDisplaySnowOutTime());
	 		        row.createCell((short) 6).setCellValue(summary.getDisplayEsbOutTime());	 		   
	 		        row.createCell((short) 7).setCellValue(summary.getStatus());
	 		        row.createCell((short) 8).setCellValue(summary.getClientName());	       
		 	i++;
			}
		 
		    response.setContentType("application/vnd.ms-excel");
			response.setHeader("Content-Disposition", "attachment; filename=eConnector_Monitoring.xlsx");
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			workbook.write(bos);
			byte[] bytes = bos.toByteArray();
			response.getOutputStream().write(bytes);
			bos.close();
		    } catch (Exception e) {
		       e.printStackTrace();
		    }

		}
	
	public SearchCriteria getSearchCriteria() {
		return searchCriteria;
	}

	public void setSearchCriteria(SearchCriteria searchCriteria) {
		this.searchCriteria = searchCriteria;
	}
 
}
