package com.caretech.wso2.utils;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.caretech.wso2.constants.MonitoringConstants;

public class Utilities {
	
	public static String getCurrentDateTime() {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		return dateFormat.format(cal.getTime());
	}
	
	public static String getCurrentDateTime(Date currentTime) {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		return dateFormat.format(currentTime.getTime());
	}
	
	public static String getTimeDifference(Date startTime, Date endTime) {
		long difference = endTime.getTime()-startTime.getTime();
		long dsecs = difference / 1000;
	    //long dminutes = difference / (60 * 1000);
		return String.valueOf(dsecs) + " Seconds";
	}

	public static String formatTimestamp(Timestamp ts) {
		String formattedTs = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(ts); 
		return formattedTs;
	}
	
	
	public static java.sql.Date convertStringToSqlDate(String date) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Date utilDate = (Date) sdf.parse(date);
		java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
	    return sqlDate;
	}

	public static java.sql.Date getFormattedToDate(String date) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Date utilDate = (Date) sdf.parse(date);
		java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime()+MonitoringConstants.ONE_DAY_IN_MILLISECOND);
	    return sqlDate;
	}
}
