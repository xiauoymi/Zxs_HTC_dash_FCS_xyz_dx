package com.caretech.wso2.vo;

import java.util.List;

import com.caretech.wso2.entity.EsbDataSychronization;

public class FoundationVo {
	
	private Integer totalCount;
	
	private List<EsbDataSychronization> summaryList;

	/**
	 * @return the totalCount
	 */
	public Integer getTotalCount() {
		return totalCount;
	}

	/**
	 * @param totalCount the totalCount to set
	 */
	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}

	/**
	 * @return the summaryList
	 */
	public List<EsbDataSychronization> getSummaryList() {
		return summaryList;
	}

	/**
	 * @param summaryList the summaryList to set
	 */
	public void setSummaryList(List<EsbDataSychronization> summaryList) {
		this.summaryList = summaryList;
	}
	
	

}
