package com.caretech.wso2.vo;

import java.io.Serializable;


/**
 * @author gopinathn
 *
 */

public class RequestParameterVO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4789276271845214940L;

	private String requestTime;
	
	private String serviceName;
	
	private String requestParamJson;

	public String getRequestTime() {
		return requestTime;
	}

	public void setRequestTime(String requestTime) {
		this.requestTime = requestTime;
	}

	public String getRequestParamJson() {
		return requestParamJson;
	}

	public void setRequestParamJson(String requestParamJson) {
		this.requestParamJson = requestParamJson;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	

}
