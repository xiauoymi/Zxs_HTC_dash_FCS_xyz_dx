package com.caretech.wso2.vo;

import java.util.List;

import com.caretech.wso2.entity.EsbLogSummary;

public class LogSummaryVO {
	
	private Integer totalCount;
	
	private List<EsbLogSummary> summaryList;

	/**
	 * @return the totalCount
	 */
	public Integer getTotalCount() {
		return totalCount;
	}

	/**
	 * @param totalCount the totalCount to set
	 */
	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}

	/**
	 * @return the summaryList
	 */
	public List<EsbLogSummary> getSummaryList() {
		return summaryList;
	}

	/**
	 * @param summaryList the summaryList to set
	 */
	public void setSummaryList(List<EsbLogSummary> summaryList) {
		this.summaryList = summaryList;
	}
	
	

}
