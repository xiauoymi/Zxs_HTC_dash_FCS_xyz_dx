-- Create table
create table USERS
(
 id serial NOT NULL,
 USERNAME VARCHAR(36) not null,
 PASSWORD VARCHAR(36) not null,
 ROLE     VARCHAR(36) not null,
 PRIMARY KEY(id)
) ;
 
insert into users (USERNAME, PASSWORD, ROLE)
values ('admin', '12345', 'ROLL_ADMIN');
 