package com.caretech.ticket.webservice.model;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author gopinathn
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "client-mapping")
public class ClientMapping {
	
	@XmlElement(name = "client")
	private List<Client> clientList;

	/**
	 * @return the clientList
	 */
	public List<Client> getClientList() {
		return clientList;
	}

	/**
	 * @param clientList the clientList to set
	 */
	public void setClientList(List<Client> clientList) {
		this.clientList = clientList;
	}

		

}
