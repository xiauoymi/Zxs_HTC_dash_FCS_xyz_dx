/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.caretech.ticket.webservice.model;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


/**
 * @author viswanathane
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "client-authentication")
public class ClientAuthenticationDTO {
	
	@XmlElement(name = "authenticationRequired")
	private String authenticationRequired;
    @XmlElement(name = "client")
    private List<ClientDTO> clientObjects;
	
	/**
	 * @return the authenticationRequired
	 */
	public String getAuthenticationRequired() {
		return authenticationRequired;
	}
	/**
	 * @param authenticationRequired the authenticationRequired to set
	 */
	public void setAuthenticationRequired(String authenticationRequired) {
		this.authenticationRequired = authenticationRequired;
	}
	/**
	 * @return the clientObjects
	 */
	public List<ClientDTO> getClientObjects() {
		return clientObjects;
	}
	/**
	 * @param clientObjects the clientObjects to set
	 */
	public void setClientObjects(List<ClientDTO> clientObjects) {
		this.clientObjects = clientObjects;
	}

   
}
