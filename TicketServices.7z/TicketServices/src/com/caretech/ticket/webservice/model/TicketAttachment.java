package com.caretech.ticket.webservice.model;

import org.apache.axis2.databinding.types.xsd.Base64Binary;


public class TicketAttachment {
	
	private String ServiceName;
	
	private String CTS_Ticket__c;
	
	private String Customer_Ticket__c;
	
	private String Attachment_1_attachmentName;

	private Base64Binary Attachment_1_attachmentData;

	private String Attachment_1_attachmentOrigSize;
	
	private String Attachment_2_attachmentName;

	private Base64Binary Attachment_2_attachmentData;

	private String Attachment_2_attachmentOrigSize;
	
	private String Attachment_3_attachmentName;

	private Base64Binary Attachment_3_attachmentData;

	private String Attachment_3_attachmentOrigSize;
	
	private String Attachment_4_attachmentName;

	private Base64Binary Attachment_4_attachmentData;

	private String Attachment_4_attachmentOrigSize;
	
	private String Attachment_5_attachmentName;

	private Base64Binary Attachment_5_attachmentData;

	private String Attachment_5_attachmentOrigSize;
	
	private String Patient_Attachment_1_attachmentName;

	private Base64Binary Patient_Attachment_1_attachmentData;

	private String Patient_Attachment_1_attachmentOrigSize;
	
	private String Patient_Attachment_2_attachmentName;

	private Base64Binary Patient_Attachment_2_attachmentData;

	private String Patient_Attachment_2_attachmentOrigSize;
	
	private String Patient_Attachment_3_attachmentName;

	private Base64Binary Patient_Attachment_3_attachmentData;

	private String Patient_Attachment_3_attachmentOrigSize;
	
	private String Patient_Attachment_4_attachmentName;

	private Base64Binary Patient_Attachment_4_attachmentData;

	private String Patient_Attachment_4_attachmentOrigSize;
	
	private String Patient_Attachment_5_attachmentName;

	private Base64Binary Patient_Attachment_5_attachmentData;

	private String Patient_Attachment_5_attachmentOrigSize;


	/**
	 * @return the serviceName
	 */
	public String getServiceName() {
		return ServiceName;
	}

	/**
	 * @param serviceName the serviceName to set
	 */
	public void setServiceName(String serviceName) {
		this.ServiceName = serviceName;
	}

	/**
	 * @return the cTS_Ticket__c
	 */
	public String getCTS_Ticket__c() {
		return CTS_Ticket__c;
	}

	/**
	 * @param cTS_Ticket__c the cTS_Ticket__c to set
	 */
	public void setCTS_Ticket__c(String cTS_Ticket__c) {
		CTS_Ticket__c = cTS_Ticket__c;
	}

	/**
	 * @return the customer_Ticket__c
	 */
	public String getCustomer_Ticket__c() {
		return Customer_Ticket__c;
	}

	/**
	 * @param customer_Ticket__c the customer_Ticket__c to set
	 */
	public void setCustomer_Ticket__c(String customer_Ticket__c) {
		Customer_Ticket__c = customer_Ticket__c;
	}

	/**
	 * @return the attachment_1_attachmentName
	 */
	public String getAttachment_1_attachmentName() {
		return Attachment_1_attachmentName;
	}

	/**
	 * @param attachment_1_attachmentName the attachment_1_attachmentName to set
	 */
	public void setAttachment_1_attachmentName(String attachment_1_attachmentName) {
		Attachment_1_attachmentName = attachment_1_attachmentName;
	}

	/**
	 * @return the attachment_1_attachmentData
	 */
	public Base64Binary getAttachment_1_attachmentData() {
		return Attachment_1_attachmentData;
	}

	/**
	 * @param attachment_1_attachmentData the attachment_1_attachmentData to set
	 */
	public void setAttachment_1_attachmentData(Base64Binary attachment_1_attachmentData) {
		Attachment_1_attachmentData = attachment_1_attachmentData;
	}

	/**
	 * @return the attachment_1_attachmentOrigSize
	 */
	public String getAttachment_1_attachmentOrigSize() {
		return Attachment_1_attachmentOrigSize;
	}

	/**
	 * @param attachment_1_attachmentOrigSize the attachment_1_attachmentOrigSize to set
	 */
	public void setAttachment_1_attachmentOrigSize(String attachment_1_attachmentOrigSize) {
		Attachment_1_attachmentOrigSize = attachment_1_attachmentOrigSize;
	}

	/**
	 * @return the attachment_2_attachmentName
	 */
	public String getAttachment_2_attachmentName() {
		return Attachment_2_attachmentName;
	}

	/**
	 * @param attachment_2_attachmentName the attachment_2_attachmentName to set
	 */
	public void setAttachment_2_attachmentName(String attachment_2_attachmentName) {
		Attachment_2_attachmentName = attachment_2_attachmentName;
	}

	/**
	 * @return the attachment_2_attachmentData
	 */
	public Base64Binary getAttachment_2_attachmentData() {
		return Attachment_2_attachmentData;
	}

	/**
	 * @param attachment_2_attachmentData the attachment_2_attachmentData to set
	 */
	public void setAttachment_2_attachmentData(Base64Binary attachment_2_attachmentData) {
		Attachment_2_attachmentData = attachment_2_attachmentData;
	}

	/**
	 * @return the attachment_2_attachmentOrigSize
	 */
	public String getAttachment_2_attachmentOrigSize() {
		return Attachment_2_attachmentOrigSize;
	}

	/**
	 * @param attachment_2_attachmentOrigSize the attachment_2_attachmentOrigSize to set
	 */
	public void setAttachment_2_attachmentOrigSize(String attachment_2_attachmentOrigSize) {
		Attachment_2_attachmentOrigSize = attachment_2_attachmentOrigSize;
	}

	/**
	 * @return the attachment_3_attachmentName
	 */
	public String getAttachment_3_attachmentName() {
		return Attachment_3_attachmentName;
	}

	/**
	 * @param attachment_3_attachmentName the attachment_3_attachmentName to set
	 */
	public void setAttachment_3_attachmentName(String attachment_3_attachmentName) {
		Attachment_3_attachmentName = attachment_3_attachmentName;
	}

	/**
	 * @return the attachment_3_attachmentData
	 */
	public Base64Binary getAttachment_3_attachmentData() {
		return Attachment_3_attachmentData;
	}

	/**
	 * @param attachment_3_attachmentData the attachment_3_attachmentData to set
	 */
	public void setAttachment_3_attachmentData(Base64Binary attachment_3_attachmentData) {
		Attachment_3_attachmentData = attachment_3_attachmentData;
	}

	/**
	 * @return the attachment_3_attachmentOrigSize
	 */
	public String getAttachment_3_attachmentOrigSize() {
		return Attachment_3_attachmentOrigSize;
	}

	/**
	 * @param attachment_3_attachmentOrigSize the attachment_3_attachmentOrigSize to set
	 */
	public void setAttachment_3_attachmentOrigSize(String attachment_3_attachmentOrigSize) {
		Attachment_3_attachmentOrigSize = attachment_3_attachmentOrigSize;
	}

	/**
	 * @return the attachment_4_attachmentName
	 */
	public String getAttachment_4_attachmentName() {
		return Attachment_4_attachmentName;
	}

	/**
	 * @param attachment_4_attachmentName the attachment_4_attachmentName to set
	 */
	public void setAttachment_4_attachmentName(String attachment_4_attachmentName) {
		Attachment_4_attachmentName = attachment_4_attachmentName;
	}

	/**
	 * @return the attachment_4_attachmentData
	 */
	public Base64Binary getAttachment_4_attachmentData() {
		return Attachment_4_attachmentData;
	}

	/**
	 * @param attachment_4_attachmentData the attachment_4_attachmentData to set
	 */
	public void setAttachment_4_attachmentData(Base64Binary attachment_4_attachmentData) {
		Attachment_4_attachmentData = attachment_4_attachmentData;
	}

	/**
	 * @return the attachment_4_attachmentOrigSize
	 */
	public String getAttachment_4_attachmentOrigSize() {
		return Attachment_4_attachmentOrigSize;
	}

	/**
	 * @param attachment_4_attachmentOrigSize the attachment_4_attachmentOrigSize to set
	 */
	public void setAttachment_4_attachmentOrigSize(String attachment_4_attachmentOrigSize) {
		Attachment_4_attachmentOrigSize = attachment_4_attachmentOrigSize;
	}

	/**
	 * @return the attachment_5_attachmentName
	 */
	public String getAttachment_5_attachmentName() {
		return Attachment_5_attachmentName;
	}

	/**
	 * @param attachment_5_attachmentName the attachment_5_attachmentName to set
	 */
	public void setAttachment_5_attachmentName(String attachment_5_attachmentName) {
		Attachment_5_attachmentName = attachment_5_attachmentName;
	}

	/**
	 * @return the attachment_5_attachmentData
	 */
	public Base64Binary getAttachment_5_attachmentData() {
		return Attachment_5_attachmentData;
	}

	/**
	 * @param attachment_5_attachmentData the attachment_5_attachmentData to set
	 */
	public void setAttachment_5_attachmentData(Base64Binary attachment_5_attachmentData) {
		Attachment_5_attachmentData = attachment_5_attachmentData;
	}

	/**
	 * @return the attachment_5_attachmentOrigSize
	 */
	public String getAttachment_5_attachmentOrigSize() {
		return Attachment_5_attachmentOrigSize;
	}

	/**
	 * @param attachment_5_attachmentOrigSize the attachment_5_attachmentOrigSize to set
	 */
	public void setAttachment_5_attachmentOrigSize(String attachment_5_attachmentOrigSize) {
		Attachment_5_attachmentOrigSize = attachment_5_attachmentOrigSize;
	}

	/**
	 * @return the patient_Attachment_1_attachmentName
	 */
	public String getPatient_Attachment_1_attachmentName() {
		return Patient_Attachment_1_attachmentName;
	}

	/**
	 * @param patient_Attachment_1_attachmentName the patient_Attachment_1_attachmentName to set
	 */
	public void setPatient_Attachment_1_attachmentName(String patient_Attachment_1_attachmentName) {
		Patient_Attachment_1_attachmentName = patient_Attachment_1_attachmentName;
	}

	/**
	 * @return the patient_Attachment_1_attachmentData
	 */
	public Base64Binary getPatient_Attachment_1_attachmentData() {
		return Patient_Attachment_1_attachmentData;
	}

	/**
	 * @param patient_Attachment_1_attachmentData the patient_Attachment_1_attachmentData to set
	 */
	public void setPatient_Attachment_1_attachmentData(Base64Binary patient_Attachment_1_attachmentData) {
		Patient_Attachment_1_attachmentData = patient_Attachment_1_attachmentData;
	}

	/**
	 * @return the patient_Attachment_1_attachmentOrigSize
	 */
	public String getPatient_Attachment_1_attachmentOrigSize() {
		return Patient_Attachment_1_attachmentOrigSize;
	}

	/**
	 * @param patient_Attachment_1_attachmentOrigSize the patient_Attachment_1_attachmentOrigSize to set
	 */
	public void setPatient_Attachment_1_attachmentOrigSize(String patient_Attachment_1_attachmentOrigSize) {
		Patient_Attachment_1_attachmentOrigSize = patient_Attachment_1_attachmentOrigSize;
	}

	/**
	 * @return the patient_Attachment_2_attachmentName
	 */
	public String getPatient_Attachment_2_attachmentName() {
		return Patient_Attachment_2_attachmentName;
	}

	/**
	 * @param patient_Attachment_2_attachmentName the patient_Attachment_2_attachmentName to set
	 */
	public void setPatient_Attachment_2_attachmentName(String patient_Attachment_2_attachmentName) {
		Patient_Attachment_2_attachmentName = patient_Attachment_2_attachmentName;
	}

	/**
	 * @return the patient_Attachment_2_attachmentData
	 */
	public Base64Binary getPatient_Attachment_2_attachmentData() {
		return Patient_Attachment_2_attachmentData;
	}

	/**
	 * @param patient_Attachment_2_attachmentData the patient_Attachment_2_attachmentData to set
	 */
	public void setPatient_Attachment_2_attachmentData(Base64Binary patient_Attachment_2_attachmentData) {
		Patient_Attachment_2_attachmentData = patient_Attachment_2_attachmentData;
	}

	/**
	 * @return the patient_Attachment_2_attachmentOrigSize
	 */
	public String getPatient_Attachment_2_attachmentOrigSize() {
		return Patient_Attachment_2_attachmentOrigSize;
	}

	/**
	 * @param patient_Attachment_2_attachmentOrigSize the patient_Attachment_2_attachmentOrigSize to set
	 */
	public void setPatient_Attachment_2_attachmentOrigSize(String patient_Attachment_2_attachmentOrigSize) {
		Patient_Attachment_2_attachmentOrigSize = patient_Attachment_2_attachmentOrigSize;
	}

	/**
	 * @return the patient_Attachment_3_attachmentName
	 */
	public String getPatient_Attachment_3_attachmentName() {
		return Patient_Attachment_3_attachmentName;
	}

	/**
	 * @param patient_Attachment_3_attachmentName the patient_Attachment_3_attachmentName to set
	 */
	public void setPatient_Attachment_3_attachmentName(String patient_Attachment_3_attachmentName) {
		Patient_Attachment_3_attachmentName = patient_Attachment_3_attachmentName;
	}

	/**
	 * @return the patient_Attachment_3_attachmentData
	 */
	public Base64Binary getPatient_Attachment_3_attachmentData() {
		return Patient_Attachment_3_attachmentData;
	}

	/**
	 * @param patient_Attachment_3_attachmentData the patient_Attachment_3_attachmentData to set
	 */
	public void setPatient_Attachment_3_attachmentData(Base64Binary patient_Attachment_3_attachmentData) {
		Patient_Attachment_3_attachmentData = patient_Attachment_3_attachmentData;
	}

	/**
	 * @return the patient_Attachment_3_attachmentOrigSize
	 */
	public String getPatient_Attachment_3_attachmentOrigSize() {
		return Patient_Attachment_3_attachmentOrigSize;
	}

	/**
	 * @param patient_Attachment_3_attachmentOrigSize the patient_Attachment_3_attachmentOrigSize to set
	 */
	public void setPatient_Attachment_3_attachmentOrigSize(String patient_Attachment_3_attachmentOrigSize) {
		Patient_Attachment_3_attachmentOrigSize = patient_Attachment_3_attachmentOrigSize;
	}

	/**
	 * @return the patient_Attachment_4_attachmentName
	 */
	public String getPatient_Attachment_4_attachmentName() {
		return Patient_Attachment_4_attachmentName;
	}

	/**
	 * @param patient_Attachment_4_attachmentName the patient_Attachment_4_attachmentName to set
	 */
	public void setPatient_Attachment_4_attachmentName(String patient_Attachment_4_attachmentName) {
		Patient_Attachment_4_attachmentName = patient_Attachment_4_attachmentName;
	}

	/**
	 * @return the patient_Attachment_4_attachmentData
	 */
	public Base64Binary getPatient_Attachment_4_attachmentData() {
		return Patient_Attachment_4_attachmentData;
	}

	/**
	 * @param patient_Attachment_4_attachmentData the patient_Attachment_4_attachmentData to set
	 */
	public void setPatient_Attachment_4_attachmentData(Base64Binary patient_Attachment_4_attachmentData) {
		Patient_Attachment_4_attachmentData = patient_Attachment_4_attachmentData;
	}

	/**
	 * @return the patient_Attachment_4_attachmentOrigSize
	 */
	public String getPatient_Attachment_4_attachmentOrigSize() {
		return Patient_Attachment_4_attachmentOrigSize;
	}

	/**
	 * @param patient_Attachment_4_attachmentOrigSize the patient_Attachment_4_attachmentOrigSize to set
	 */
	public void setPatient_Attachment_4_attachmentOrigSize(String patient_Attachment_4_attachmentOrigSize) {
		Patient_Attachment_4_attachmentOrigSize = patient_Attachment_4_attachmentOrigSize;
	}

	/**
	 * @return the patient_Attachment_5_attachmentName
	 */
	public String getPatient_Attachment_5_attachmentName() {
		return Patient_Attachment_5_attachmentName;
	}

	/**
	 * @param patient_Attachment_5_attachmentName the patient_Attachment_5_attachmentName to set
	 */
	public void setPatient_Attachment_5_attachmentName(String patient_Attachment_5_attachmentName) {
		Patient_Attachment_5_attachmentName = patient_Attachment_5_attachmentName;
	}

	/**
	 * @return the patient_Attachment_5_attachmentData
	 */
	public Base64Binary getPatient_Attachment_5_attachmentData() {
		return Patient_Attachment_5_attachmentData;
	}

	/**
	 * @param patient_Attachment_5_attachmentData the patient_Attachment_5_attachmentData to set
	 */
	public void setPatient_Attachment_5_attachmentData(Base64Binary patient_Attachment_5_attachmentData) {
		Patient_Attachment_5_attachmentData = patient_Attachment_5_attachmentData;
	}

	/**
	 * @return the patient_Attachment_5_attachmentOrigSize
	 */
	public String getPatient_Attachment_5_attachmentOrigSize() {
		return Patient_Attachment_5_attachmentOrigSize;
	}

	/**
	 * @param patient_Attachment_5_attachmentOrigSize the patient_Attachment_5_attachmentOrigSize to set
	 */
	public void setPatient_Attachment_5_attachmentOrigSize(String patient_Attachment_5_attachmentOrigSize) {
		Patient_Attachment_5_attachmentOrigSize = patient_Attachment_5_attachmentOrigSize;
		
	}

	@Override
	public String toString() {
		String result = "{"
				+ (ServiceName != null ? "\"ServiceName\":\"" + ServiceName + "\", " : "")
				+ (CTS_Ticket__c != null ? "\"CTS_Ticket__c\":\"" + CTS_Ticket__c + "\", " : "")
				+ (Customer_Ticket__c != null ? "\"Customer_Ticket__c\":\"" + Customer_Ticket__c + "\", " : "")
				+ (Attachment_1_attachmentName != null ? "\"Attachment_1_attachmentName\":\"" + Attachment_1_attachmentName + "\", " : "") 
				//+ (Attachment_1_attachmentData != null ? "\"Attachment_1_attachmentData\":\"" + Attachment_1_attachmentData + "\", " : "")
				+ (Attachment_1_attachmentOrigSize != null ? "\"Attachment_1_attachmentOrigSize\":\"" + Attachment_1_attachmentOrigSize + "\", " : "")
				+ (Attachment_2_attachmentName != null ? "\"Attachment_2_attachmentName\":\"" + Attachment_2_attachmentName + "\", " : "")
				//+ (Attachment_2_attachmentData != null ? "\"Attachment_2_attachmentData\":\"" + Attachment_2_attachmentData + "\", " : "") 
				+ (Attachment_2_attachmentOrigSize != null ? "\"Attachment_2_attachmentOrigSize\":\"" + Attachment_2_attachmentOrigSize + "\", " : "")
				+ (Attachment_3_attachmentName != null ? "\"Attachment_3_attachmentName\":\"" + Attachment_3_attachmentName + "\", " : "") 
				//+ (Attachment_3_attachmentData != null ? "\"Attachment_3_attachmentData\":\""  + Attachment_3_attachmentData + "\", " : "") 
				+ (Attachment_3_attachmentOrigSize != null ? "\"Attachment_3_attachmentOrigSize\":\"" + Attachment_3_attachmentOrigSize + "\", " : "")
				+ (Attachment_4_attachmentName != null ? "\"Attachment_4_attachmentName\":\"" + Attachment_4_attachmentName + "\", " : "") 
				//+ (Attachment_4_attachmentData != null ? "\"Attachment_4_attachmentData\":\"" + Attachment_4_attachmentData + "\", " : "") 
				+ (Attachment_4_attachmentOrigSize != null ? "\"Attachment_4_attachmentOrigSize\":\"" + Attachment_4_attachmentOrigSize + "\", " : "")
				+ (Attachment_5_attachmentName != null ? "\"Attachment_5_attachmentName\":\"" + Attachment_5_attachmentName + "\", " : "") 
				//+ (Attachment_5_attachmentData != null ? "\"Attachment_5_attachmentData\":\"" + Attachment_5_attachmentData + "\", " : "") 
				+ (Attachment_5_attachmentOrigSize != null ? "\"Attachment_5_attachmentOrigSize\":\"" + Attachment_5_attachmentOrigSize + "\", " : "")
				+ (Patient_Attachment_1_attachmentName != null ? "\"Patient_Attachment_1_attachmentName\":\"" + Patient_Attachment_1_attachmentName + "\", " : "")
				//+ (Patient_Attachment_1_attachmentData != null ? "\"Patient_Attachment_1_attachmentData\":\"" + Patient_Attachment_1_attachmentData + "\", " : "")
				+ (Patient_Attachment_1_attachmentOrigSize != null ? "\"Patient_Attachment_1_attachmentOrigSize\":\"" + Patient_Attachment_1_attachmentOrigSize + "\", " : "")
				+ (Patient_Attachment_2_attachmentName != null ? "\"Patient_Attachment_2_attachmentName\":\"" + Patient_Attachment_2_attachmentName + "\", " : "")
				//+ (Patient_Attachment_2_attachmentData != null ? "\"Patient_Attachment_2_attachmentData\":\"" + Patient_Attachment_2_attachmentData + "\", " : "")
				+ (Patient_Attachment_2_attachmentOrigSize != null ? "\"Patient_Attachment_2_attachmentOrigSize\":\"" + Patient_Attachment_2_attachmentOrigSize + "\", " : "")
				+ (Patient_Attachment_3_attachmentName != null ? "\"Patient_Attachment_3_attachmentName\":\"" + Patient_Attachment_3_attachmentName + "\", " : "")
				//+ (Patient_Attachment_3_attachmentData != null ? "\"Patient_Attachment_3_attachmentData\":\"" + Patient_Attachment_3_attachmentData + "\", " : "")
				+ (Patient_Attachment_3_attachmentOrigSize != null ? "\"Patient_Attachment_3_attachmentOrigSize\":\"" + Patient_Attachment_3_attachmentOrigSize + "\", " : "")
				+ (Patient_Attachment_4_attachmentName != null ? "\"Patient_Attachment_4_attachmentName\":\"" + Patient_Attachment_4_attachmentName + "\", " : "")
				//+ (Patient_Attachment_4_attachmentData != null ? "\"Patient_Attachment_4_attachmentData\":\"" + Patient_Attachment_4_attachmentData + "\", " : "")
				+ (Patient_Attachment_4_attachmentOrigSize != null ? "\"Patient_Attachment_4_attachmentOrigSize\":\"" + Patient_Attachment_4_attachmentOrigSize + "\", " : "")
				+ (Patient_Attachment_5_attachmentName != null ? "\"Patient_Attachment_5_attachmentName\":\"" + Patient_Attachment_5_attachmentName + "\", " : "")
				//+ (Patient_Attachment_5_attachmentData != null ? "\"Patient_Attachment_5_attachmentData\":\"" + Patient_Attachment_5_attachmentData + "\", " : "")
				+ (Patient_Attachment_5_attachmentOrigSize != null ? "\"Patient_Attachment_5_attachmentOrigSize\":\"" + Patient_Attachment_5_attachmentOrigSize + "\", " : "");
				
		result = result.substring(0, result.lastIndexOf(",")) + "}";
		return result;
	}

}
