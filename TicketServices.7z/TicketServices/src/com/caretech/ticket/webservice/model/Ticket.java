package com.caretech.ticket.webservice.model;


public class Ticket {
	
	private String ServiceName;
	
	private String Submitter;
	
	private String Assigned_To;
	
	private String Status;
	
	private String Short_Description;
	
	private String Title;
	
	private String Floor;
	
	private String Priority;
	
	private String Summary;
	
	private String First_Name;
	
	private String Last_Name;
	
	private String Department;
	
	private String Computer_Name;
	
	private String Assigned_Individual;
	
	private String Category;
	
	private String Type;
	
	private String Item;
	
	private String Building;
	
	private String Assigned_Group;
	
	private String Work_Log;
	
	private String Phone_Ext;
	
	private String Office;
	
	private String Pending_Reason;
	
	private String Customer_Ticket;
	
	private String Date_Time_Assigned;
	
	private String Ticket_Create_Date;
	
	private String Integration_Attribute_01;
	
	private String Integration_Attribute_02;
	
	private String Integration_Attribute_03;
	
	private String Integration_Attribute_04;
	
	private String Integration_Attribute_05;
	
	private String Integration_Attribute_06;
	
	private String Integration_Attribute_07;
	
	private String Integration_Attribute_08;
	
	private String Foreign_Parent_Key;
	
	private String Phone_Work;
	
	private String Pager_Numeric;
	
	private String Pager_Pin;
	
	private String Network_Login;
	
	private String Suite;

	private String Email_Address;
		
	private String Source;

	private String CTS_Ticket;

	private String Business_Organization;
		
	private String Secure_Patient_Information;

	private String Resolution;

	private String Root_Cause_Category;
	
	private String Notes;
	
	private String 	Description;
	
	private String Case_Number;
	
	private String Client_ID;
	
	private String Incident_Board_Master;
	
	private String Remote_Control;
	
	private String Impact;
	
	private String Urgency;
	
	private String Caller_Unlisted;
	
	private String Location_Unlisted;
	
	private String FCR;


	/**
	 * @return the serviceName
	 */
	public String getServiceName() {
		return ServiceName;
	}

	public String getImpact() {
		return Impact;
	}

	public void setImpact(String impact) {
		Impact = impact;
	}

	public String getUrgency() {
		return Urgency;
	}

	public void setUrgency(String urgency) {
		Urgency = urgency;
	}

	public String getCaller_Unlisted() {
		return Caller_Unlisted;
	}

	public void setCaller_Unlisted(String caller_Unlisted) {
		Caller_Unlisted = caller_Unlisted;
	}

	public String getLocation_Unlisted() {
		return Location_Unlisted;
	}

	public void setLocation_Unlisted(String location_Unlisted) {
		Location_Unlisted = location_Unlisted;
	}

	/**
	 * @param serviceName the serviceName to set
	 */
	public void setServiceName(String serviceName) {
		ServiceName = serviceName;
	}

	/**
	 * @return the submitter
	 */
	public String getSubmitter() {
		return Submitter;
	}

	/**
	 * @param submitter the submitter to set
	 */
	public void setSubmitter(String submitter) {
		Submitter = submitter;
	}

	/**
	 * @return the assigned_To
	 */
	public String getAssigned_To() {
		return Assigned_To;
	}

	/**
	 * @param assigned_To the assigned_To to set
	 */
	public void setAssigned_To(String assigned_To) {
		Assigned_To = assigned_To;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return Status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		Status = status;
	}

	/**
	 * @return the short_Description
	 */
	public String getShort_Description() {
		return Short_Description;
	}

	/**
	 * @param short_Description the short_Description to set
	 */
	public void setShort_Description(String short_Description) {
		Short_Description = short_Description;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return Title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		Title = title;
	}

	/**
	 * @return the floor
	 */
	public String getFloor() {
		return Floor;
	}

	/**
	 * @param floor the floor to set
	 */
	public void setFloor(String floor) {
		Floor = floor;
	}

	/**
	 * @return the priority
	 */
	public String getPriority() {
		return Priority;
	}

	/**
	 * @param priority the priority to set
	 */
	public void setPriority(String priority) {
		Priority = priority;
	}

	/**
	 * @return the summary
	 */
	public String getSummary() {
		return Summary;
	}

	/**
	 * @param summary the summary to set
	 */
	public void setSummary(String summary) {
		Summary = summary;
	}

	/**
	 * @return the first_Name
	 */
	public String getFirst_Name() {
		return First_Name;
	}

	/**
	 * @param first_Name the first_Name to set
	 */
	public void setFirst_Name(String first_Name) {
		First_Name = first_Name;
	}

	/**
	 * @return the last_Name
	 */
	public String getLast_Name() {
		return Last_Name;
	}

	/**
	 * @param last_Name the last_Name to set
	 */
	public void setLast_Name(String last_Name) {
		Last_Name = last_Name;
	}

	/**
	 * @return the department
	 */
	public String getDepartment() {
		return Department;
	}

	/**
	 * @param department the department to set
	 */
	public void setDepartment(String department) {
		Department = department;
	}

	/**
	 * @return the computer_Name
	 */
	public String getComputer_Name() {
		return Computer_Name;
	}

	/**
	 * @param computer_Name the computer_Name to set
	 */
	public void setComputer_Name(String computer_Name) {
		Computer_Name = computer_Name;
	}

	/**
	 * @return the assigned_Individual
	 */
	public String getAssigned_Individual() {
		return Assigned_Individual;
	}

	/**
	 * @param assigned_Individual the assigned_Individual to set
	 */
	public void setAssigned_Individual(String assigned_Individual) {
		Assigned_Individual = assigned_Individual;
	}

	/**
	 * @return the category
	 */
	public String getCategory() {
		return Category;
	}

	/**
	 * @param category the category to set
	 */
	public void setCategory(String category) {
		Category = category;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return Type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		Type = type;
	}

	/**
	 * @return the item
	 */
	public String getItem() {
		return Item;
	}

	/**
	 * @param item the item to set
	 */
	public void setItem(String item) {
		Item = item;
	}

	/**
	 * @return the building
	 */
	public String getBuilding() {
		return Building;
	}

	/**
	 * @param building the building to set
	 */
	public void setBuilding(String building) {
		Building = building;
	}

	/**
	 * @return the assigned_Group
	 */
	public String getAssigned_Group() {
		return Assigned_Group;
	}

	/**
	 * @param assigned_Group the assigned_Group to set
	 */
	public void setAssigned_Group(String assigned_Group) {
		Assigned_Group = assigned_Group;
	}

	/**
	 * @return the work_Log
	 */
	public String getWork_Log() {
		return Work_Log;
	}

	/**
	 * @param work_Log the work_Log to set
	 */
	public void setWork_Log(String work_Log) {
		Work_Log = work_Log;
	}

	/**
	 * @return the phone_Ext
	 */
	public String getPhone_Ext() {
		return Phone_Ext;
	}

	/**
	 * @param phone_Ext the phone_Ext to set
	 */
	public void setPhone_Ext(String phone_Ext) {
		Phone_Ext = phone_Ext;
	}

	/**
	 * @return the office
	 */
	public String getOffice() {
		return Office;
	}

	/**
	 * @param office the office to set
	 */
	public void setOffice(String office) {
		Office = office;
	}

	/**
	 * @return the pending_Reason
	 */
	public String getPending_Reason() {
		return Pending_Reason;
	}

	/**
	 * @param pending_Reason the pending_Reason to set
	 */
	public void setPending_Reason(String pending_Reason) {
		Pending_Reason = pending_Reason;
	}

	/**
	 * @return the customer_Ticket
	 */
	public String getCustomer_Ticket() {
		return Customer_Ticket;
	}

	/**
	 * @param customer_Ticket the customer_Ticket to set
	 */
	public void setCustomer_Ticket(String customer_Ticket) {
		Customer_Ticket = customer_Ticket;
	}

	/**
	 * @return the date_Time_Assigned
	 */
	public String getDate_Time_Assigned() {
		return Date_Time_Assigned;
	}

	/**
	 * @param date_Time_Assigned the date_Time_Assigned to set
	 */
	public void setDate_Time_Assigned(String date_Time_Assigned) {
		Date_Time_Assigned = date_Time_Assigned;
	}

	/**
	 * @return the ticket_Create_Date
	 */
	public String getTicket_Create_Date() {
		return Ticket_Create_Date;
	}

	/**
	 * @param ticket_Create_Date the ticket_Create_Date to set
	 */
	public void setTicket_Create_Date(String ticket_Create_Date) {
		Ticket_Create_Date = ticket_Create_Date;
	}

	/**
	 * @return the integration_Attribute_01
	 */
	public String getIntegration_Attribute_01() {
		return Integration_Attribute_01;
	}

	/**
	 * @param integration_Attribute_01 the integration_Attribute_01 to set
	 */
	public void setIntegration_Attribute_01(String integration_Attribute_01) {
		Integration_Attribute_01 = integration_Attribute_01;
	}

	/**
	 * @return the integration_Attribute_02
	 */
	public String getIntegration_Attribute_02() {
		return Integration_Attribute_02;
	}

	/**
	 * @param integration_Attribute_02 the integration_Attribute_02 to set
	 */
	public void setIntegration_Attribute_02(String integration_Attribute_02) {
		Integration_Attribute_02 = integration_Attribute_02;
	}

	/**
	 * @return the integration_Attribute_03
	 */
	public String getIntegration_Attribute_03() {
		return Integration_Attribute_03;
	}

	/**
	 * @param integration_Attribute_03 the integration_Attribute_03 to set
	 */
	public void setIntegration_Attribute_03(String integration_Attribute_03) {
		Integration_Attribute_03 = integration_Attribute_03;
	}

	/**
	 * @return the integration_Attribute_04
	 */
	public String getIntegration_Attribute_04() {
		return Integration_Attribute_04;
	}

	/**
	 * @param integration_Attribute_04 the integration_Attribute_04 to set
	 */
	public void setIntegration_Attribute_04(String integration_Attribute_04) {
		Integration_Attribute_04 = integration_Attribute_04;
	}

	/**
	 * @return the foreign_Parent_Key
	 */
	public String getForeign_Parent_Key() {
		return Foreign_Parent_Key;
	}

	/**
	 * @param foreign_Parent_Key the foreign_Parent_Key to set
	 */
	public void setForeign_Parent_Key(String foreign_Parent_Key) {
		Foreign_Parent_Key = foreign_Parent_Key;
	}

	/**
	 * @return the phone_Work
	 */
	public String getPhone_Work() {
		return Phone_Work;
	}

	/**
	 * @param phone_Work the phone_Work to set
	 */
	public void setPhone_Work(String phone_Work) {
		Phone_Work = phone_Work;
	}

	/**
	 * @return the pager_Numeric
	 */
	public String getPager_Numeric() {
		return Pager_Numeric;
	}

	/**
	 * @param pager_Numeric the pager_Numeric to set
	 */
	public void setPager_Numeric(String pager_Numeric) {
		Pager_Numeric = pager_Numeric;
	}

	/**
	 * @return the pager_Pin
	 */
	public String getPager_Pin() {
		return Pager_Pin;
	}

	/**
	 * @param pager_Pin the pager_Pin to set
	 */
	public void setPager_Pin(String pager_Pin) {
		Pager_Pin = pager_Pin;
	}

	/**
	 * @return the network_Login
	 */
	public String getNetwork_Login() {
		return Network_Login;
	}

	/**
	 * @param network_Login the network_Login to set
	 */
	public void setNetwork_Login(String network_Login) {
		Network_Login = network_Login;
	}

	/**
	 * @return the suite
	 */
	public String getSuite() {
		return Suite;
	}

	/**
	 * @param suite the suite to set
	 */
	public void setSuite(String suite) {
		Suite = suite;
	}

	/**
	 * @return the email_Address
	 */
	public String getEmail_Address() {
		return Email_Address;
	}

	/**
	 * @param email_Address the email_Address to set
	 */
	public void setEmail_Address(String email_Address) {
		Email_Address = email_Address;
	}

	/**
	 * @return the source
	 */
	public String getSource() {
		return Source;
	}

	/**
	 * @param source the source to set
	 */
	public void setSource(String source) {
		Source = source;
	}


	/**
	 * @return the business_Organization
	 */
	public String getBusiness_Organization() {
		return Business_Organization;
	}

	/**
	 * @param business_Organization the business_Organization to set
	 */
	public void setBusiness_Organization(String business_Organization) {
		Business_Organization = business_Organization;
	}

	/**
	 * @return the secure_Patient_Information
	 */
	public String getSecure_Patient_Information() {
		return Secure_Patient_Information;
	}

	/**
	 * @param secure_Patient_Information the secure_Patient_Information to set
	 */
	public void setSecure_Patient_Information(String secure_Patient_Information) {
		Secure_Patient_Information = secure_Patient_Information;
	}

	/**
	 * @return the resolution
	 */
	public String getResolution() {
		return Resolution;
	}

	/**
	 * @param resolution the resolution to set
	 */
	public void setResolution(String resolution) {
		Resolution = resolution;
	}

	/**
	 * @return the root_Cause_Category
	 */
	public String getRoot_Cause_Category() {
		return Root_Cause_Category;
	}

	/**
	 * @param root_Cause_Category the root_Cause_Category to set
	 */
	public void setRoot_Cause_Category(String root_Cause_Category) {
		Root_Cause_Category = root_Cause_Category;
	}

	@Override
	public String toString() {
		String result = "{"
				+ (ServiceName != null ?  "\"ServiceName\":\"" + ServiceName + "\", " : "")
				+ (Submitter != null ? "\"Submitter\":\"" + Submitter + "\", " : "")
				+ (Assigned_To != null ? "\"Assigned_To\":\"" + Assigned_To + "\", " : "")
				+ (Status != null ? "\"Status\":\"" + Status + "\", " : "")
				+ (Short_Description != null ? "\"Short_Description\":\"" + Short_Description + "\", " : "")
				+ (Title != null ? "\"Title\":\"" + Title + "\", " : "")
				+ (Floor != null ? "\"Floor\":\"" + Floor + "\", " : "")					
				+ (Priority != null ? "\"Priority\":\"" + Priority + "\", " : "")
				+ (Summary != null ? "\"Summary\":\"" + Summary + "\", " : "")
				+ (First_Name != null ? "\"First_Name\":\"" + First_Name + "\", " : "")
				+ (Last_Name != null ? "\"Last_Name\":\"" + Last_Name + "\", " : "")
				+ (Department != null ? "\"Department\":\"" + Department + "\", " : "")
				+ (Computer_Name != null ? "\"Computer_Name\":\"" + Computer_Name + "\", " : "")
				+ (Assigned_Individual != null ? "\"Assigned_Individual\":\"" + Assigned_Individual + "\", " : "") 
				+ (Category != null ? "\"Category\":\"" + Category + "\", " : "")
				+ (Type != null ? "\"Type\":\"" + Type + "\", " : "")
				+ (Item != null ? "\"Item\":\"" + Item + "\", " : "")
				+ (Building != null ? "\"Building\":\"" + Building+ "\", " : "") 
				+ (Assigned_Group != null ? "\"Assigned_Group\":\"" + Assigned_Group + "\", " : "") 
				+ (Work_Log != null ? "\"Work_Log\":\"" + Work_Log + "\", " : "")
				+ (Phone_Ext != null ? "\"Phone_Ext\":\"" + Phone_Ext + "\", " : "")
				+ (Office != null ? "\"Office\":\"" + Office + "\", " : "")
				+ (Pending_Reason != null ? "\"Pending_Reason\":\"" + Pending_Reason + "\", " : "")
				+ (Customer_Ticket != null ? "\"Customer_Ticket\":\"" + Customer_Ticket + "\", " : "")
				+ (Date_Time_Assigned != null ? "\"Date_Time_Assigned\":\"" + Date_Time_Assigned + "\", " : "")
				+ (Ticket_Create_Date != null ? "\"Ticket_Create_Date\":\"" + Ticket_Create_Date + "\", " : "")
				+ (Integration_Attribute_01 != null ? "\"Integration_Attribute_01\":\"" + Integration_Attribute_01 + "\", " : "") 
				+ (Integration_Attribute_02 != null ? "\"Integration_Attribute_02\":\"" + Integration_Attribute_02 + "\", " : "")
				+ (Integration_Attribute_03 != null ? "\"Integration_Attribute_03\":\"" + Integration_Attribute_03 + "\", " : "")
				+ (Integration_Attribute_04 != null ? "\"Integration_Attribute_04\":\"" + Integration_Attribute_04 + "\", " : "")
				+ (Foreign_Parent_Key != null ? "\"Foreign_Parent_Key\":\"" + Foreign_Parent_Key + "\", " : "")
				+ (Phone_Work != null ? "\"Phone_Work\":\"" + Phone_Work + "\", " : "")
				+ (Pager_Numeric != null ? "\"Pager_Numeric\":\"" + Pager_Numeric + "\", " : "") 
				+ (Pager_Pin != null ? "\"Pager_Pin\":\"" + Pager_Pin + "\", " : "")
				+ (Network_Login != null ? "\"Network_Login\":\"" + Network_Login + "\", " : "") 
				+ (Suite != null ? "\"Suite\":\"" + Suite + "\", " : "")
				+ (Email_Address != null ? "\"Email_Address\":\"" + Email_Address + "\", " : "") 
				+ (Source != null ? "\"Source\":\"" + Source + "\", " : "")
				+ (CTS_Ticket != null ? "\"Case_Number\":\"" + CTS_Ticket + "\", " : "") 
				+ (Business_Organization != null ? "\"Business_Organization\":\"" + Business_Organization + "\", " : "")
				+ (Secure_Patient_Information != null ? "\"Secure_Patient_Information\":\"" + Secure_Patient_Information + "\", " : "") 
				+ (Resolution != null ? "\"Resolution\":\"" + Resolution + "\", " : "")
				+ (Description != null ? "\"Description\":\"" + Description + "\", " : "")
				+ (Secure_Patient_Information != null ? "\"Secure_Patient_Information\":\"" + Secure_Patient_Information + "\", " : "")
				+ (Root_Cause_Category != null ? "\"Root_Cause_Category\":\"" + Root_Cause_Category + "\", " : "")
				+ (Remote_Control != null ? "Remote_Control=" + Remote_Control + ", " : "")
				+ (FCR != null ? "FCR=" + FCR + ", " : "");

				
				result = result.substring(0, result.lastIndexOf(","))+ "}";
		
		return result;
	}

	public static void main(String[] args) {
		Ticket str = new Ticket();
		str.setAssigned_Group("Test Data");
		str.setBuilding("building");		
		System.out.println(str);
	}

	/**
	 * @return the CTS_Ticket
	 */
	public String getCTS_Ticket() {
		return CTS_Ticket;
	}

	/**
	 * @param CTS_Ticket the CTS_Ticket to set
	 */
	public void setCTS_Ticket(String cTS_Ticket) {
		CTS_Ticket = cTS_Ticket;
	}

	/**
	 * @return the integration_Attribute_05
	 */
	public String getIntegration_Attribute_05() {
		return Integration_Attribute_05;
	}

	/**
	 * @param integration_Attribute_05 the integration_Attribute_05 to set
	 */
	public void setIntegration_Attribute_05(String integration_Attribute_05) {
		Integration_Attribute_05 = integration_Attribute_05;
	}

	/**
	 * @return the integration_Attribute_06
	 */
	public String getIntegration_Attribute_06() {
		return Integration_Attribute_06;
	}

	/**
	 * @param integration_Attribute_06 the integration_Attribute_06 to set
	 */
	public void setIntegration_Attribute_06(String integration_Attribute_06) {
		Integration_Attribute_06 = integration_Attribute_06;
	}

	/**
	 * @return the notes
	 */
	public String getNotes() {
		return Notes;
	}

	/**
	 * @param notes the notes to set
	 */
	public void setNotes(String notes) {
		Notes = notes;
	}


	/**
	 * @return the description
	 */
	public String getDescription() {
		return Description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		Description = description;
	}

	/**
	 * @return the case_Number
	 */
	public String getCase_Number() {
		return Case_Number;
	}

	/**
	 * @param case_Number the case_Number to set
	 */
	public void setCase_Number(String case_Number) {
		Case_Number = case_Number;
	}

	/**
	 * @return the client_ID
	 */
	public String getClient_ID() {
		return Client_ID;
	}

	/**
	 * @param client_ID the client_ID to set
	 */
	public void setClient_ID(String client_ID) {
		Client_ID = client_ID;
	}

	/**
	 * @return the integration_Attribute_07
	 */
	public String getIntegration_Attribute_07() {
		return Integration_Attribute_07;
	}

	/**
	 * @param integration_Attribute_07 the integration_Attribute_07 to set
	 */
	public void setIntegration_Attribute_07(String integration_Attribute_07) {
		Integration_Attribute_07 = integration_Attribute_07;
	}

	/**
	 * @return the integration_Attribute_08
	 */
	public String getIntegration_Attribute_08() {
		return Integration_Attribute_08;
	}

	/**
	 * @param integration_Attribute_08 the integration_Attribute_08 to set
	 */
	public void setIntegration_Attribute_08(String integration_Attribute_08) {
		Integration_Attribute_08 = integration_Attribute_08;
	}

	/**
	 * @return the incident_Board_Master
	 */
	public String getIncident_Board_Master() {
		return Incident_Board_Master;
	}

	/**
	 * @param incident_Board_Master the incident_Board_Master to set
	 */
	public void setIncident_Board_Master(String incident_Board_Master) {
		Incident_Board_Master = incident_Board_Master;
	}

	public String getRemote_Control() {
		return Remote_Control;
	}

	public void setRemote_Control(String remote_Control) {
		Remote_Control = remote_Control;
	}

	public String getFCR() {
		return FCR;
	}

	public void setFCR(String fCR) {
		FCR = fCR;
	}
	
	
	
}
