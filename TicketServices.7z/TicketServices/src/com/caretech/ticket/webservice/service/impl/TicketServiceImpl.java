package com.caretech.ticket.webservice.service.impl;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import javax.activation.DataHandler;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.axis2.databinding.types.xsd.Base64Binary;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.caretech.ticket.datamapping.constants.TicketConstants;
import com.caretech.ticket.datamapping.enums.ErrorCode;
import com.caretech.ticket.datamapping.processor.DataMapperProcessor;
import com.caretech.ticket.datamapping.processor.JSONProcessor;
import com.caretech.ticket.webservice.exception.InvalidDataMappingXMLException;
import com.caretech.ticket.webservice.exception.MandatoryParameterException;
import com.caretech.ticket.webservice.exception.TicketCreationException;
import com.caretech.ticket.webservice.model.Response;
import com.caretech.ticket.webservice.model.TargetApplicationDTO;
import com.caretech.ticket.webservice.model.Ticket;
import com.caretech.ticket.webservice.model.TicketAttachment;
import com.caretech.ticket.webservice.processor.WSO2Processor;
import com.caretech.ticket.webservice.service.TicketService;

/**
 * @author gopinathn
 *
 */
public class TicketServiceImpl implements TicketService {

	private Logger LOGGER = Logger.getLogger(TicketServiceImpl.class.getName());

	private static TicketService ticketService;

	private TicketServiceImpl() {
	}

	public static TicketService getInstance() {
		if (ticketService != null)
			return ticketService;
		else
			return new TicketServiceImpl();

	}

	/**
	 * Method to create Ticket and return its ticket id
	 * 
	 * @param ticket
	 * @return response string
	 */
	@Override
	public Response createTicket(Ticket ticket) throws TicketCreationException {

		DataMapperProcessor processor = DataMapperProcessor.getInstance();
		WSO2Processor wso2Processor = WSO2Processor.getInstance();
		Response response = new Response();
		String responseData = null;
		try {
			Map<String, Object> requestData = convertObjectToMap(ticket);
			TargetApplicationDTO targetApplication = processor.processDataMapperService(requestData);
			responseData = wso2Processor.processWSO2Request(targetApplication);
			response.setStatus("SUCCESS");
			
			LOGGER.info(responseData);
			responseData = parseJSONResponse(responseData,response);
			//response.setResult(responseData);
		} catch (InvalidDataMappingXMLException e) {
			LOGGER.error(e.getMessage(), e);
			/*response.setStatus("FAILED");
			response.setErrorCode(e.getErrorCode());
			response.setErrorDesc(e.getErrorMessage());*/
			throw new TicketCreationException(e.getErrorCode(), e.getErrorMessage());
		} catch (MandatoryParameterException e) {
			LOGGER.error(e.getMessage(), e);
			throw new TicketCreationException(ErrorCode.ERR_X1005.name(), ErrorCode.ERR_X1005.getErrorMessage() + " " + e.getMessage());
		} catch (TicketCreationException e) {
			LOGGER.error(e.getMessage(), e);
			throw new TicketCreationException(e.getErrorCode(),
					e.getErrorMessage());
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			throw new TicketCreationException(ErrorCode.ERR_X1005.name(),
					ErrorCode.ERR_X1005.getErrorMessage());
		}

		return response;
	}

	/**
	 * Helper method to convert an java object to java Map
	 * 
	 * @param obj
	 * @return Map
	 * @throws TicketCreationException 
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 */
	public  Map<String, Object> convertObjectToMap(Object obj) throws TicketCreationException {
		Method[] methods = obj.getClass().getMethods();

		Map<String, Object> map = new HashMap<String, Object>();
		try {
			for (Method m : methods) {
				if (m.getName().startsWith("get") && !m.getName().startsWith("getClass")) {
					Object value;
					value = (Object) m.invoke(obj);
					if(value != null)
					if(m.getName().equalsIgnoreCase("getAttachment_1_attachmentData") ||
							m.getName().equalsIgnoreCase("getPatient_Attachment_1_attachmentData")) {
						DataHandler data =  ((Base64Binary)value).getBase64Binary();
						if(data != null) {
						BufferedInputStream in = new BufferedInputStream(data.getInputStream());
						byte[] byteArray=org.apache.commons.io.IOUtils.toByteArray(in);
						byte[] encoded = Base64.encodeBase64(byteArray);
						//String encodedString = new String(encoded);
						map.put("Attachment_1_attachmentData", (Object) new String(encoded));
						}
					} else if(m.getName().equalsIgnoreCase("getAttachment_1_attachmentName") ||
							m.getName().equalsIgnoreCase("getPatient_Attachment_1_attachmentName")) {
						
						if(((String) value).lastIndexOf("\\") > 0) {
						String fileName = ((String) value).substring(((String) value).lastIndexOf("\\")+1, ((String) value).length());
						LOGGER.info("File Name -->" + fileName); 
						map.put("Attachment_1_attachmentName", (Object) fileName);
						
						}else{
							map.put("Attachment_1_attachmentName", (Object) value);
						}
					} else
						map.put(m.getName().substring(3), (Object) value);
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			throw new TicketCreationException(ErrorCode.ERR_X1009.name(), ErrorCode.ERR_X1009.getErrorMessage());
		} 
		return map;
	}

	@Override
	public Response uploadAttachment(TicketAttachment attachment) throws TicketCreationException {
		String responseData = null;
		Response response = new Response();
		DataMapperProcessor processor = DataMapperProcessor.getInstance();
		WSO2Processor wso2Processor = WSO2Processor.getInstance();
		JSONProcessor jsonProcessor = JSONProcessor.getInstance();
		try {
			Map<String, Object> requestData = convertObjectToMap(attachment);
			TargetApplicationDTO targetApplication = processor.processDataMapperService(requestData);
			targetApplication.setRequest(jsonProcessor.getInputMapAsJson(requestData));
			responseData = wso2Processor.processWSO2Request(targetApplication);
			response.setStatus("SUCCESS");
			
			LOGGER.info(responseData);
			responseData = parseJSONResponse(responseData,response);
			//response.setResult(responseData);
		} catch (InvalidDataMappingXMLException e) {
			LOGGER.error(e.getMessage(), e);
			throw new TicketCreationException(e.getErrorCode(), e.getErrorMessage());
		} catch (MandatoryParameterException e) {
			LOGGER.error(e.getMessage(), e);
			responseData = "Missing Parameter(s) " + e.getMessage();
			throw new TicketCreationException(ErrorCode.ERR_X1005.name(), responseData );
		} catch (TicketCreationException e) {
			LOGGER.error(e.getMessage(), e);
			throw e;
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			throw new TicketCreationException(ErrorCode.ERR_X1005.name(),
					ErrorCode.ERR_X1005.getErrorMessage());
		}
		return response;
	}
	
	/**
	 * Helper method to parse the xml and return value based on status
	 * 
	 * @param responseXML
	 * @return string
	 * @throws InvalidDataMappingXMLException
	 * @throws Exception
	 */
	@SuppressWarnings("unused")
	private String parseXMLResponse(String responseXML) throws TicketCreationException {
		String result = "";
		DocumentBuilder db;
		try {
			db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(responseXML));

			Document doc = db.parse(is);
			NodeList statusNode = doc.getElementsByTagName("status");
			String status = statusNode.item(0).getTextContent();
			if (status.equals("SUCCESS")) {
				result = doc.getElementsByTagName("id").item(0).getTextContent();
			} else {
				result = doc.getElementsByTagName("errorDesc").item(0).getTextContent();
			}
		} catch (ParserConfigurationException e) {
			LOGGER.error(e.getMessage(), e);
			throw new TicketCreationException(ErrorCode.ERR_X1007.name(),
					ErrorCode.ERR_X1007.getErrorMessage());
		} catch (SAXException e) {
			LOGGER.error(e.getMessage(), e);
			throw new TicketCreationException(ErrorCode.ERR_X1001.name(),
					ErrorCode.ERR_X1001.getErrorMessage());
		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
			throw new TicketCreationException(ErrorCode.ERR_X1008.name(),
					ErrorCode.ERR_X1008.getErrorMessage());
		}

		return result;

	}
	
	/**
	 * Helper method to parse the xml and return value based on status
	 * 
	 * @param responseXML
	 * @return string
	 * @throws InvalidDataMappingXMLException
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	private String parseJSONResponse(String responseJSON,Response response) throws TicketCreationException {
		String result = "";
		JSONProcessor jsonProcessor = JSONProcessor.getInstance();
		try {
			Map<String, Object> responseData = jsonProcessor.getInputJsonAsMap(responseJSON);
			String status = (String)responseData.get("Status");
			if (status!=null && status.length()>0 && TicketConstants.STATUS_SUCCESS.equals(status.toUpperCase())) {
				//Map<String, Object> resultMap = (Map<String, Object>)((Map<String, Object>)((Map<String, Object>)responseData.get("output")).get("output")).get("Entry");
				result = (String)responseData.get("TicketNumber");
			} else {
				//result = (String)responseData.get("errorDesc");
				response.setErrorCode((String)responseData.get("errorCode"));
				response.setErrorDesc((String)responseData.get("errorDesc"));
				response.setStatus(TicketConstants.STATUS_FAILED);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			//throw new TicketCreationException("101","Error while parsing the response");
			throw new TicketCreationException(ErrorCode.ERR_X1010.name(),
					ErrorCode.ERR_X1010.getErrorMessage());
		}
		response.setResult(result);
		return result;

	}

	/**
	 * Method to update Ticket and return its ticket id
	 * 
	 * @param ticket
	 * @return response string
	 */
	@Override
	public Response updateTicket(Ticket ticket) throws TicketCreationException {

		DataMapperProcessor processor = DataMapperProcessor.getInstance();
		WSO2Processor wso2Processor = WSO2Processor.getInstance();
		Response response = new Response();
		String responseData = null;
		try {
			Map<String, Object> requestData = convertObjectToMap(ticket);
			TargetApplicationDTO targetApplication = processor.processDataMapperService(requestData);
			response.setStatus(TicketConstants.STATUS_SUCCESS);
			responseData = wso2Processor.processWSO2Request(targetApplication);
			LOGGER.info(responseData);
			responseData = parseJSONResponse(responseData,response);
			//response.setResult(responseData);
		} catch (MandatoryParameterException e) {
			LOGGER.error(e.getMessage(), e);
			throw new TicketCreationException(ErrorCode.ERR_X1005.name(), ErrorCode.ERR_X1005.getErrorMessage() + " " + e.getMessage());
		} catch (HttpHostConnectException e) {
			LOGGER.error(e.getMessage(), e);
			responseData = e.getLocalizedMessage();
			throw new TicketCreationException(ErrorCode.ERR_X1006.name(),
					ErrorCode.ERR_X1006.getErrorMessage());
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			throw new TicketCreationException(ErrorCode.ERR_X1007.name(),
					ErrorCode.ERR_X1007.getErrorMessage());
		}

		return response;
	}

}
