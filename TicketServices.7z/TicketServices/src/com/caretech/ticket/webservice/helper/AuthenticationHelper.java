package com.caretech.ticket.webservice.helper;

import java.util.List;

import javax.xml.namespace.QName;

import org.apache.axiom.soap.SOAPHeader;
import org.apache.axis2.context.MessageContext;
import org.apache.log4j.Logger;

import com.caretech.ticket.datamapping.constants.TicketConstants;
import com.caretech.ticket.datamapping.processor.DataMapperProcessor;
import com.caretech.ticket.webservice.controller.CreateTicket;
import com.caretech.ticket.webservice.model.ClientAuthenticationDTO;
import com.caretech.ticket.webservice.model.ClientDTO;

public class AuthenticationHelper {
	
	private static Logger LOGGER = Logger.getLogger(CreateTicket.class.getName());

	/*static Properties prop = new Properties();

	static {
		try {
			String authFilePath = TicketConstants.AUTHENTICATION_FILE_PATH;
			InputStream is = new FileInputStream(authFilePath);
			prop.load(is);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}*/
	
	/**
	 * Helper method to authenticate the user 
	 * @return String
	 */
	public static String authenticateUser() {
		LOGGER.info("User Authentication Starts");
		String result = null;
		try {
			MessageContext msg = MessageContext.getCurrentMessageContext();
			SOAPHeader soapHeader = msg.getEnvelope().getHeader();
			ClientAuthenticationDTO clientAuthenticationDTO = DataMapperProcessor.getInstance().processClientAuthenticationService(TicketConstants.XML_CLIENT_AUTHENTICATION);
			boolean authorizedUser = false;
			if(soapHeader != null && clientAuthenticationDTO != null) {
				String authenticationRequired = clientAuthenticationDTO.getAuthenticationRequired();
				if(TicketConstants.AUTHENTICATION_REQUIRED_FLAG.equals(authenticationRequired)){
					List<ClientDTO> clientList = clientAuthenticationDTO.getClientObjects();
					for(ClientDTO clientDTO : clientList){
						//String actualClientSecret = (String) prop.get(soapHeader.getFirstChildWithName(new QName("clientKey")).getText());
						String soapClientKey = soapHeader.getFirstChildWithName(new QName("clientKey")).getText();
						String actualClientKey =  clientDTO.getClientKey();
						if(soapClientKey != null && soapClientKey.length() > 0) {
							String soapClientSecret = soapHeader.getFirstChildWithName(new QName("clientSecret")).getText();
							String actualClientSecret =  clientDTO.getClientSecret();
							if(soapClientKey.equals(actualClientKey) && soapClientSecret.equals(actualClientSecret)) {
								authorizedUser = true;
								break;
							}else{
								authorizedUser = false;
							}
						} else {
							LOGGER.error("User Authentication Failed");
							result = TicketConstants.UNAUTHORIZED_USER;
						}
					}
					if(!authorizedUser){
						LOGGER.error("User Authentication Failed");
						result = TicketConstants.UNAUTHORIZED_USER;
					}
				}else{
					LOGGER.error("User Authentication not Required");
				}
			}
		} catch(Exception e) {
			LOGGER.error(e.getMessage(), e);
			result = TicketConstants.AUTHENTICATION_FAILED;
		}
		LOGGER.info("User Authentication Ends");
		return result;
	}

}
