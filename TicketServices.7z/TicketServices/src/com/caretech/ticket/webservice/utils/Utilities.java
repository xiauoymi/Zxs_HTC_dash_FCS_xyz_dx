package com.caretech.ticket.webservice.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Utilities {
	
	public static String getCurrentDateTime() {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		return dateFormat.format(cal.getTime());
	}
	
	public static String getCurrentDateTime(Date currentTime) {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		return dateFormat.format(currentTime.getTime());
	}
	
	public static String getTimeDifference(Date startTime, Date endTime) {
		long difference = endTime.getTime()-startTime.getTime();
		long dsecs = difference / 1000;
	    //long dminutes = difference / (60 * 1000);
		return String.valueOf(dsecs) + " Seconds";
	}

}
