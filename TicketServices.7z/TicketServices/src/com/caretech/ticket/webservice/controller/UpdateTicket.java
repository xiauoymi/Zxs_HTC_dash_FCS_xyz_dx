package com.caretech.ticket.webservice.controller;

import java.util.Date;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.caretech.ticket.webservice.exception.TicketCreationException;
import com.caretech.ticket.webservice.helper.AuthenticationHelper;
import com.caretech.ticket.webservice.helper.NotificationHelper;
import com.caretech.ticket.webservice.model.Response;
import com.caretech.ticket.webservice.model.Ticket;
import com.caretech.ticket.webservice.service.TicketService;
import com.caretech.ticket.webservice.service.impl.TicketServiceImpl;
import com.caretech.ticket.webservice.utils.Utilities;

/**
 * @author gopinathn
 *
 */
public class UpdateTicket {
	
	private Logger LOGGER = Logger.getLogger(UpdateTicket.class.getName());
	
	private NotificationHelper notificationHelper = NotificationHelper.getInstance();

	private HashMap<String, String> parameters = new HashMap<String, String>();
		
	/**
	 * Service method exposed to update ticket.
	 * @param ticket
	 * @return
	 */
	public Response updateTicket(Ticket ticket){
		
		Date startTime = new Date();
		LOGGER.info("TicketService: updateTicket call starts : "+Utilities.getCurrentDateTime(startTime));
		Response response = new Response();
		TicketService ticketService = TicketServiceImpl.getInstance();		
		try {	
			String authorizationResult = AuthenticationHelper.authenticateUser();
			if(authorizationResult != null) {
				response.setStatus("FAILED");
				response.setErrorDesc(authorizationResult);
				return response;
			}
			response = ticketService.updateTicket(ticket);			
		} catch (TicketCreationException e) {
			LOGGER.error(e.getMessage(), e);
			response.setStatus("FAILED");
			response.setErrorCode(e.getErrorCode());
			response.setErrorDesc(e.getErrorMessage());
			parameters.put("errorCode", e.getErrorCode());
			parameters.put("errorDesc", e.getErrorMessage());
			parameters.put("serviceName", "UpdateTicketOR : updateTicket");
			parameters.put("params", ticket.toString());
			notificationHelper.sendNotification(parameters);
		}
		Date endTime = new Date();
		LOGGER.info("TicketService: updateTicket call ends : "+Utilities.getCurrentDateTime(endTime));
		LOGGER.info("TicketService: updateTicket call duration :"+Utilities.getTimeDifference(startTime, endTime));
		return response;
	}
	
}
