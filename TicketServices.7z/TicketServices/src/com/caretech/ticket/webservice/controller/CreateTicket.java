package com.caretech.ticket.webservice.controller;

import java.util.Date;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.caretech.ticket.webservice.exception.TicketCreationException;
import com.caretech.ticket.webservice.helper.AuthenticationHelper;
import com.caretech.ticket.webservice.helper.NotificationHelper;
import com.caretech.ticket.webservice.model.Response;
import com.caretech.ticket.webservice.model.Ticket;
import com.caretech.ticket.webservice.model.TicketAttachment;
import com.caretech.ticket.webservice.service.TicketService;
import com.caretech.ticket.webservice.service.impl.TicketServiceImpl;
import com.caretech.ticket.webservice.utils.Utilities;

/**
 * @author gopinathn
 *
 */
public class CreateTicket {
	
	private Logger LOGGER = Logger.getLogger(CreateTicket.class.getName());
		
	private NotificationHelper notificationHelper = NotificationHelper.getInstance();
	
	private HashMap<String, String> parameters = new HashMap<String, String>();
	
	/**
	 * Service method exposed to insert ticket.
	 * @param ticket
	 * @return
	 */
	public Response insertTicket(Ticket ticket){
		Date startTime = new Date();
		LOGGER.info("TicketService: insertTicket call starts :"+Utilities.getCurrentDateTime(startTime));
		LOGGER.info("Request Data : "+ticket.toString());
		Response response = new Response();
		TicketService ticketService = TicketServiceImpl.getInstance();		
		try {	
			String authorizationResult = AuthenticationHelper.authenticateUser();
			if(authorizationResult != null) {
				response.setStatus("FAILED");
				response.setErrorDesc(authorizationResult);
				return response;
			}
			if(ticket.getDescription() != null) {
				String description = ticket.getDescription().replace("\\n", "\\r\\n");
				ticket.setDescription(description);
			}
			if(ticket.getSecure_Patient_Information() != null) {
				String patientInfo = ticket.getSecure_Patient_Information().replace("\\n", "\\r\\n");
				ticket.setSecure_Patient_Information(patientInfo);
			}
			LOGGER.info("Request Data : "+ticket.toString());
			response = ticketService.createTicket(ticket);			
		} catch (TicketCreationException e) {
			LOGGER.error(e.getMessage(), e);
			response.setStatus("FAILED");
			response.setErrorCode(e.getErrorCode());
			response.setErrorDesc(e.getErrorMessage());
			parameters.put("errorCode", e.getErrorCode());
			parameters.put("errorDesc", e.getErrorMessage());
			parameters.put("serviceName", "CreateTicketOR : insertTicket");
			parameters.put("params", ticket.toString());
			notificationHelper.sendNotification(parameters);
		}
		Date endTime = new Date();
		LOGGER.info("TicketService: insertTicket call ends :"+Utilities.getCurrentDateTime(endTime));
		LOGGER.info("TicketService: insertTicket call duration :"+Utilities.getTimeDifference(startTime, endTime));
		return response;
	}
	
	/**
	 * Service method exposed to upload attachment to the ticket.
	 * @param ticket
	 * @return
	 */
	public Response uploadAttachment(TicketAttachment attachment){
		Date startTime = new Date();
		LOGGER.info("TicketService: uploadAttachment call starts : "+Utilities.getCurrentDateTime(startTime));
		LOGGER.info("Request Data : "+attachment.toString());
		Response response = new Response();
		TicketService ticketService = TicketServiceImpl.getInstance();
		try {
			String authorizationResult = AuthenticationHelper.authenticateUser();
			if(authorizationResult != null) {
				response.setStatus("FAILED");
				response.setErrorDesc(authorizationResult);
				return response;
			}
			response = ticketService.uploadAttachment(attachment);
		} catch (TicketCreationException e) {
			LOGGER.error(e.getMessage(), e);
			response.setStatus("FAILED");
			response.setErrorCode(e.getErrorCode());
			response.setErrorDesc(e.getErrorMessage());
			parameters.put("errorCode", e.getErrorCode());
			parameters.put("errorDesc", e.getErrorMessage());
			parameters.put("serviceName", "CreateTicketOR : uploadAttachment");
			parameters.put("params", attachment.toString());
			notificationHelper.sendNotification(parameters);
		}
		Date endTime = new Date();
		LOGGER.info("TicketService: uploadAttachment call ends : "+Utilities.getCurrentDateTime(endTime));
		LOGGER.info("TicketService: uploadAttachment call duration : "+Utilities.getTimeDifference(startTime, endTime));
		return response;
	}

}
