package com.caretech.ticket.webservice.processor;

import java.util.Date;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

import com.caretech.ticket.datamapping.enums.ErrorCode;
import com.caretech.ticket.webservice.exception.TicketCreationException;
import com.caretech.ticket.webservice.model.TargetApplicationDTO;
import com.caretech.ticket.webservice.utils.Utilities;

public class WSO2Processor {
	
	private Logger LOGGER = Logger.getLogger(WSO2Processor.class.getName());
	
	private static WSO2Processor wso2Processor;
	
	private WSO2Processor(){}
	
	/**
	 * Helper method to call WSO2 service and return response string
	 * 
	 * @param targetApplication
	 * @return response string
	 * @throws TicketCreationException
	 */
	public String processWSO2Request(TargetApplicationDTO targetApplication) throws TicketCreationException {
		Date startTime = new Date();
		LOGGER.info("WSO2 Service API call starts :"+Utilities.getCurrentDateTime(startTime));
		String responseData = "";
		String incidentData = targetApplication.getRequest();
		CloseableHttpClient httpclient = HttpClients.custom().build();

		try {

			HttpPost httpPost = new HttpPost(targetApplication.getUrl());
			httpPost.setHeader("Accept", targetApplication.getContentType());
			httpPost.setHeader("Content-Type", targetApplication.getContentType());
			HttpEntity entity = new ByteArrayEntity(incidentData.getBytes("utf-8"));
			httpPost.setEntity(entity);
			// System.out.println("Executing request " +
			// httpPost.getRequestLine());
			LOGGER.info("Executing request " + httpPost.getRequestLine());
			CloseableHttpResponse response = httpclient.execute(httpPost);
			try {
				responseData = EntityUtils.toString(response.getEntity());
				// System.out.println(responseData);
			} catch (Exception e) {
				LOGGER.error(e.getMessage(), e);
				responseData = e.getLocalizedMessage();
				// e.printStackTrace();
			} finally {
				response.close();
			}
			httpclient.close();
		} catch (HttpHostConnectException e) {
			LOGGER.error(e.getMessage(), e);
			responseData = e.getLocalizedMessage();
			throw new TicketCreationException(ErrorCode.ERR_X1006.name(),
					ErrorCode.ERR_X1006.getErrorMessage());
			// e.printStackTrace();
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			responseData = e.getLocalizedMessage();
			throw new TicketCreationException(ErrorCode.ERR_X1006.name(),
					ErrorCode.ERR_X1006.getErrorMessage());
			// e.printStackTrace();
		}
		Date endTime = new Date();
		LOGGER.info("WSO2 Service API call ends :"+Utilities.getCurrentDateTime(endTime));
		LOGGER.info("WSO2 Service API call duration :"+Utilities.getTimeDifference(startTime, endTime));
		return responseData;
	}
	
	

	public static WSO2Processor getInstance() {
		if(wso2Processor == null)
			wso2Processor = new WSO2Processor();
		return wso2Processor;
	}

}
