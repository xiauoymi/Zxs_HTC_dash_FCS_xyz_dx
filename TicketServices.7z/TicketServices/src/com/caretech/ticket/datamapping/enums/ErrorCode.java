/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.caretech.ticket.datamapping.enums;

import java.text.MessageFormat;


public enum ErrorCode {

    ERR_X1001("SAX Parse Exception"),
    ERR_X1002("Data mapper XML file not found"),
    ERR_X1003("Invalid Data Mapping XML Configuration"),
    ERR_X1004("Invalid Translate Mapping XML Configuration"),
    ERR_X1005("Ticket Creation Failed"), 
    ERR_X1006("Connection to WSO2 Failed"),
    ERR_X1007("Parse Configuration Exception"), 
    ERR_X1008("File Not Found"), 
    ERR_X1009("Object to Map Conversion Error"),    
    ERR_X1010("Error while parsing the response");
    
    private String errorMessage;

    private ErrorCode(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public String getErrorMessage(String... args) {
        return MessageFormat.format(errorMessage, (Object[]) args);
    }
}
