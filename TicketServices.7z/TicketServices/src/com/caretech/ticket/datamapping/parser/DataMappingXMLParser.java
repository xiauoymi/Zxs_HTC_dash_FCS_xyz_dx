/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.caretech.ticket.datamapping.parser;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import com.caretech.ticket.datamapping.enums.ErrorCode;
import com.caretech.ticket.webservice.exception.InvalidDataMappingXMLException;
import com.caretech.ticket.webservice.model.ClientAuthenticationDTO;
import com.caretech.ticket.webservice.model.ClientMapping;
import com.caretech.ticket.webservice.model.DataMappingDTO;

public class DataMappingXMLParser {

	/**
	 * Helper method to parse the xml and return it as java object.
	 * @param dataMappingXml
	 * @return <code>DataMappingDTO</code>.
	 * @throws Exception
	 */
	public static DataMappingDTO getDataMapping(String dataMappingXml) throws InvalidDataMappingXMLException {
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(DataMappingDTO.class);
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
			DataMappingDTO dataMappingDTO = (DataMappingDTO) unmarshaller.unmarshal(new File(dataMappingXml));
			return dataMappingDTO;
		} catch (JAXBException ex) {
			ex.printStackTrace();
			throw new InvalidDataMappingXMLException(ErrorCode.ERR_X1003.name(),
					ErrorCode.ERR_X1003.getErrorMessage());
		}
	}
	
	/**
	 * Helper method to parse the xml and return it as java object.
	 * @param clientMappingXml
	 * @return <code>ClientMapping</code>.
	 * @throws Exception
	 */
	public static ClientMapping getClientMapping(String clientMappingXml) throws InvalidDataMappingXMLException {
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(ClientMapping.class);
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
			ClientMapping dataMappingDTO = (ClientMapping) unmarshaller.unmarshal(new File(clientMappingXml));
			return dataMappingDTO;
		} catch (JAXBException ex) {
			ex.printStackTrace();
			throw new InvalidDataMappingXMLException(ErrorCode.ERR_X1003.name(),
					ErrorCode.ERR_X1003.getErrorMessage());
		}
	}
	
	/**
	 * Helper method to parse the xml and return it as java object.
	 * @param dataMappingXml
	 * @return <code>DataMappingDTO</code>.
	 * @throws Exception
	 */
	public static ClientAuthenticationDTO getClientAuthenticationObject(String clientAuthenticationXml) throws InvalidDataMappingXMLException {
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(ClientAuthenticationDTO.class);
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
			ClientAuthenticationDTO clientAuthenticationDTO = (ClientAuthenticationDTO) unmarshaller.unmarshal(new File(clientAuthenticationXml));
			return clientAuthenticationDTO;
		} catch (JAXBException ex) {
			ex.printStackTrace();
			throw new InvalidDataMappingXMLException(ErrorCode.ERR_X1003.name(),
					ErrorCode.ERR_X1003.getErrorMessage());
		}
	}

}
